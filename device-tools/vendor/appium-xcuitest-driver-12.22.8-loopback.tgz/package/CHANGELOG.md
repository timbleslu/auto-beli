## [12.22.8](https://github.com/appium/appium-xcuitest-driver/compare/v12.22.7...v12.22.8) (2026-10-31)

### Miscellaneous Chores

* remove wrong docstring comment ([#3108](https://github.com/appium/appium-xcuitest-driver/issues/3108)) ([6df7cff](https://github.com/appium/appium-xcuitest-driver/commit/6df7cff8f8fb6602231e9910be6707a10f4ffe93))

## [12.22.7](https://github.com/appium/appium-xcuitest-driver/compare/v12.22.6...v12.22.7) (2026-10-30)

### Bug Fixes

* move withoutImplicitWait to utils ([#3103](https://github.com/appium/appium-xcuitest-driver/issues/3103)) ([24d1285](https://github.com/appium/appium-xcuitest-driver/commit/24d1285588d5e6584a9187b397bf53781dc6f669))

## [12.22.6](https://github.com/appium/appium-xcuitest-driver/compare/v12.22.5...v12.22.6) (2026-10-30)

### Bug Fixes

* don't wait for implicit timeout on internal native lookups ([#3101](https://github.com/appium/appium-xcuitest-driver/issues/3101)) ([c1e611e](https://github.com/appium/appium-xcuitest-driver/commit/c1e611e91ac22cbc4d3f824e87caf167c6fe2625))

## [12.22.5](https://github.com/appium/appium-xcuitest-driver/compare/v12.22.4...v12.22.5) (2026-10-29)

### Performance Improvements

* find first visible child with a single class chain query ([#3100](https://github.com/appium/appium-xcuitest-driver/issues/3100)) ([768b2af](https://github.com/appium/appium-xcuitest-driver/commit/768b2af5c6ea01afb2ce0f0e0f887e6f6d395f3a))

## [12.22.4](https://github.com/appium/appium-xcuitest-driver/compare/v12.22.3...v12.22.4) (2026-10-29)

### Bug Fixes

* make WDA the source of truth for its settings ([#3097](https://github.com/appium/appium-xcuitest-driver/issues/3097)) ([ce5a997](https://github.com/appium/appium-xcuitest-driver/commit/ce5a99708c06edce87db87b117cebbac9b58b02a))

## [12.22.3](https://github.com/appium/appium-xcuitest-driver/compare/v12.22.2...v12.22.3) (2026-10-28)

### Bug Fixes

* remove perf recording temp files when start or upload fails ([#3092](https://github.com/appium/appium-xcuitest-driver/issues/3092)) ([edc9a19](https://github.com/appium/appium-xcuitest-driver/commit/edc9a192397db0343858cb5b4e0b4defbaede681))

## [12.22.2](https://github.com/appium/appium-xcuitest-driver/compare/v12.22.1...v12.22.2) (2026-10-28)

### Bug Fixes

* stop stale remote debugger listeners when switching webview contexts ([#3089](https://github.com/appium/appium-xcuitest-driver/issues/3089)) ([e963398](https://github.com/appium/appium-xcuitest-driver/commit/e96339839225581647e0f90ea0d98d0a825db2dd))

## [12.22.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.22.0...v12.22.1) (2026-10-28)

### Miscellaneous Chores

* release to bump the dependency for shell quote ([6d988f1](https://github.com/appium/appium-xcuitest-driver/commit/6d988f1df3a6388545458bc55da75efb5309fb30))

## [12.22.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.21.0...v12.22.0) (2026-10-27)

### Features

* route Duo simulator HID controls through the host ([#3077](https://github.com/appium/appium-xcuitest-driver/issues/3077)) ([32dae67](https://github.com/appium/appium-xcuitest-driver/commit/32dae673c5b93bdee2fc5c3fe57a45c02a0295b2))

## [12.21.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.20.0...v12.21.0) (2026-10-26)

### Features

* add keyboardWaitTimeout setting ([#3073](https://github.com/appium/appium-xcuitest-driver/issues/3073)) ([7f4bcbd](https://github.com/appium/appium-xcuitest-driver/commit/7f4bcbd27209dcdad2300cd285274a8fac61f0da))

## [12.20.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.19.1...v12.20.0) (2026-10-22)

### Features

* add execute method for retrieving pressable buttons ([#3071](https://github.com/appium/appium-xcuitest-driver/issues/3071)) ([10553a0](https://github.com/appium/appium-xcuitest-driver/commit/10553a02810736493aea868d5570b39637f74ec6))

## [12.19.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.19.0...v12.19.1) (2026-10-19)

### Bug Fixes

* preserve iOS 27 webview interaction history ([#3063](https://github.com/appium/appium-xcuitest-driver/issues/3063)) ([bf36e32](https://github.com/appium/appium-xcuitest-driver/commit/bf36e32e4bcc3b78d4b0f6696d7a21b8299135bc))

## [12.19.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.18.3...v12.19.0) (2026-10-18)

### Features

* capture selected simulator displays through CoreSim fallback ([#3030](https://github.com/appium/appium-xcuitest-driver/issues/3030)) ([80b341c](https://github.com/appium/appium-xcuitest-driver/commit/80b341c929b26a3ac278089a5fd1c3af8ca9a943))

### Bug Fixes

* preserve recording padding when MJPEG frame geometry changes ([#3048](https://github.com/appium/appium-xcuitest-driver/issues/3048)) ([c860f30](https://github.com/appium/appium-xcuitest-driver/commit/c860f308b23c29e33d2bfa37773e691045c15c4c))
* retain and clean up screen recorder after stop failure ([#3049](https://github.com/appium/appium-xcuitest-driver/issues/3049)) ([a4b262a](https://github.com/appium/appium-xcuitest-driver/commit/a4b262a642da4e5f9a6a83a99959bdba9f7dce8c))

## [12.18.3](https://github.com/appium/appium-xcuitest-driver/compare/v12.18.2...v12.18.3) (2026-10-18)

### Bug Fixes

* preserve calibrated scale and viewport origin for native web taps ([#3046](https://github.com/appium/appium-xcuitest-driver/issues/3046)) ([e62b338](https://github.com/appium/appium-xcuitest-driver/commit/e62b338a21f6f8ce401d93c81801e42e26047a45))

## [12.18.2](https://github.com/appium/appium-xcuitest-driver/compare/v12.18.1...v12.18.2) (2026-10-18)

### Bug Fixes

* resolve WDA downloads from the monorepo release ([#3050](https://github.com/appium/appium-xcuitest-driver/issues/3050)) ([0e990dc](https://github.com/appium/appium-xcuitest-driver/commit/0e990dcf45fddcb2b635bd9dad7cd278c066f735))

## [12.18.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.18.0...v12.18.1) (2026-10-13)

### Bug Fixes

* capture the whole element in web element screenshots ([#3040](https://github.com/appium/appium-xcuitest-driver/issues/3040)) ([5614339](https://github.com/appium/appium-xcuitest-driver/commit/561433953b5bfa940702917c9089bc1a5a6e1db8))

## [12.18.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.17.3...v12.18.0) (2026-10-13)

### Features

* add asAppUnderTest flag in mobile: launchApp command ([#3004](https://github.com/appium/appium-xcuitest-driver/issues/3004)) ([7d1d611](https://github.com/appium/appium-xcuitest-driver/commit/7d1d6115cc1bb046071c792f47997d0deeb389cb))

## [12.17.3](https://github.com/appium/appium-xcuitest-driver/compare/v12.17.2...v12.17.3) (2026-10-12)

### Bug Fixes

* make tunnel-creation exit on Ctrl+C ([#3033](https://github.com/appium/appium-xcuitest-driver/issues/3033)) ([1dde1ec](https://github.com/appium/appium-xcuitest-driver/commit/1dde1ec4589b416205729d943c7cf5ab9d286617))

## [12.17.2](https://github.com/appium/appium-xcuitest-driver/compare/v12.17.1...v12.17.2) (2026-10-12)

### Bug Fixes

* track Apple TV tunnels by pair record UDID ([#3032](https://github.com/appium/appium-xcuitest-driver/issues/3032)) ([10e7d17](https://github.com/appium/appium-xcuitest-driver/commit/10e7d17f8eddc0ab9915987a8ebee75644e799bd))

## [12.17.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.17.0...v12.17.1) (2026-10-10)

### Bug Fixes

* preserve recording aspect ratio and input frame rate ([#3010](https://github.com/appium/appium-xcuitest-driver/issues/3010)) ([caabeb3](https://github.com/appium/appium-xcuitest-driver/commit/caabeb39658bc9e7e13c6378cf76167e30b8e473))

## [12.17.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.16.1...v12.17.0) (2026-10-10)

### Features

* add multi-display discovery and safe screenshot routing for Duo support ([#3013](https://github.com/appium/appium-xcuitest-driver/issues/3013)) ([0fac1ec](https://github.com/appium/appium-xcuitest-driver/commit/0fac1ecfcf3f1b11775d2a0785571caf26817eb1))

## [12.16.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.16.0...v12.16.1) (2026-10-10)

### Bug Fixes

* pass value and maxAttempts of mobile selectPickerWheelValue to WDA ([#3017](https://github.com/appium/appium-xcuitest-driver/issues/3017)) ([ba9e634](https://github.com/appium/appium-xcuitest-driver/commit/ba9e6340b7a29b6430a9a2efc5260494cce20d62))

## [12.16.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.15.2...v12.16.0) (2026-10-08)

### Features

* add simulated Duo hinge angle command ([#3001](https://github.com/appium/appium-xcuitest-driver/issues/3001)) ([3f4d513](https://github.com/appium/appium-xcuitest-driver/commit/3f4d513737d2583e333b27127a67c98c586b17fe))

### Bug Fixes

* refresh display geometry for viewport screenshots ([#3007](https://github.com/appium/appium-xcuitest-driver/issues/3007)) ([68d3103](https://github.com/appium/appium-xcuitest-driver/commit/68d3103bdfd892123922a506a4e6d6d125125b3a))

## [12.15.2](https://github.com/appium/appium-xcuitest-driver/compare/v12.15.1...v12.15.2) (2026-10-07)

### Bug Fixes

* preserve app iframe selection after native tap calibration ([#3015](https://github.com/appium/appium-xcuitest-driver/issues/3015)) ([9de5422](https://github.com/appium/appium-xcuitest-driver/commit/9de5422ec99291e04566eba39b28a4f968721f8b))

## [12.15.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.15.0...v12.15.1) (2026-10-07)

### Bug Fixes

* honor explicit MJPEG screenshot orientation correction ([#3008](https://github.com/appium/appium-xcuitest-driver/issues/3008)) ([4205137](https://github.com/appium/appium-xcuitest-driver/commit/42051377b3420655dc0f9b3b762df84bcf0e4c66))
* include native geometry in web calibration cache ([#3009](https://github.com/appium/appium-xcuitest-driver/issues/3009)) ([c73578f](https://github.com/appium/appium-xcuitest-driver/commit/c73578fac918e8e3e1dadff8f0d62b8f3404a761))

## [12.15.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.14.1...v12.15.0) (2026-10-03)

### Features

* support launching WDA on Duo ([#3000](https://github.com/appium/appium-xcuitest-driver/issues/3000)) ([a097de0](https://github.com/appium/appium-xcuitest-driver/commit/a097de0798995ffff1ee40882bab6a0e6eb430dd))

## [12.14.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.14.0...v12.14.1) (2026-10-03)

### Bug Fixes

* merge tunnel and legacy device discovery ([#2991](https://github.com/appium/appium-xcuitest-driver/issues/2991)) ([77b451f](https://github.com/appium/appium-xcuitest-driver/commit/77b451fe482cf383b802ffde5068ee01f50e1cfd))

## [12.14.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.13.3...v12.14.0) (2026-10-03)

### Features

* support simulatorPasteboardAutomaticSync and connect hardware preference for Device Hub ([#2999](https://github.com/appium/appium-xcuitest-driver/issues/2999)) ([3cda6b2](https://github.com/appium/appium-xcuitest-driver/commit/3cda6b203eaa9e497bc998748506ba75bc9e51f3))

## [12.13.3](https://github.com/appium/appium-xcuitest-driver/compare/v12.13.2...v12.13.3) (2026-09-28)

### Bug Fixes

* bump WDA for package creation with Xcode 26+ ([#2996](https://github.com/appium/appium-xcuitest-driver/issues/2996)) ([b9750ba](https://github.com/appium/appium-xcuitest-driver/commit/b9750ba58bb490895bc0e1f5f0f9c027617c30b2))

## [12.13.2](https://github.com/appium/appium-xcuitest-driver/compare/v12.13.1...v12.13.2) (2026-09-23)

### Bug Fixes

* grepFile error handling ([#2989](https://github.com/appium/appium-xcuitest-driver/issues/2989)) ([79b387b](https://github.com/appium/appium-xcuitest-driver/commit/79b387bbd9c8e265851fae91d555b798b528eb3e))

## [12.13.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.13.0...v12.13.1) (2026-09-20)

### Bug Fixes

* **opts:** pass `ActivateSuspended: true` to host opts for backgrounding WDA ([#2980](https://github.com/appium/appium-xcuitest-driver/issues/2980)) ([78361a2](https://github.com/appium/appium-xcuitest-driver/commit/78361a2cad2e66a34f64272113f519a35ce24407))

## [12.13.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.12.6...v12.13.0) (2026-09-20)

### Features

* Bump appium-ios-simulator major version ([#2979](https://github.com/appium/appium-xcuitest-driver/issues/2979)) ([af42a33](https://github.com/appium/appium-xcuitest-driver/commit/af42a3339e3b79ece2513f5bca6d6f84ad706e33))

## [12.12.6](https://github.com/appium/appium-xcuitest-driver/compare/v12.12.5...v12.12.6) (2026-09-19)

### Bug Fixes

* match udid capabilities case-insensitively across remaining device/simulator lookups ([#2981](https://github.com/appium/appium-xcuitest-driver/issues/2981)) ([4451076](https://github.com/appium/appium-xcuitest-driver/commit/4451076f82d2e0f241e848c3be1498bc751d0573))

## [12.12.5](https://github.com/appium/appium-xcuitest-driver/compare/v12.12.4...v12.12.5) (2026-09-18)

### Bug Fixes

* match explicit udid capability against connected devices case-insensitively ([#2977](https://github.com/appium/appium-xcuitest-driver/issues/2977)) ([f1f8b15](https://github.com/appium/appium-xcuitest-driver/commit/f1f8b158ccfa55c796c8d1a5ec89366b5ae44e94))

## [12.12.4](https://github.com/appium/appium-xcuitest-driver/compare/v12.12.3...v12.12.4) (2026-09-14)

### Bug Fixes

* forward the network event method name to the Safari network log listener ([#2975](https://github.com/appium/appium-xcuitest-driver/issues/2975)) ([96b0fc8](https://github.com/appium/appium-xcuitest-driver/commit/96b0fc8e37ee92dfd40d2e2d2ae334c7e207a5be))

## [12.12.3](https://github.com/appium/appium-xcuitest-driver/compare/v12.12.2...v12.12.3) (2026-09-12)

### Miscellaneous Chores

* **ci:** publish via bundled dependencies instead of npm-shrinkwrap ([#2972](https://github.com/appium/appium-xcuitest-driver/issues/2972)) ([eb94173](https://github.com/appium/appium-xcuitest-driver/commit/eb941732aa9fa5a3e79a3cada0d4f1494b0b2e37))

## [12.12.2](https://github.com/appium/appium-xcuitest-driver/compare/v12.12.1...v12.12.2) (2026-09-12)

### Bug Fixes

* resolve nested .ipa paths when downloading a remote .zip on real devices ([#2974](https://github.com/appium/appium-xcuitest-driver/issues/2974)) ([5b7f643](https://github.com/appium/appium-xcuitest-driver/commit/5b7f643358006907dd6847aac5d65b07897ef234))

## [12.12.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.12.0...v12.12.1) (2026-09-11)

### Bug Fixes

* do not zip the host temp dir when pulling a container root on real devices ([#2971](https://github.com/appium/appium-xcuitest-driver/issues/2971)) ([ec787a2](https://github.com/appium/appium-xcuitest-driver/commit/ec787a2be7b655f111431d634a3dabc5097f83ce))

## [12.12.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.11.1...v12.12.0) (2026-09-10)

### Features

* own the context/contexts legacy MJSONWP routes ([#2973](https://github.com/appium/appium-xcuitest-driver/issues/2973)) ([15dce63](https://github.com/appium/appium-xcuitest-driver/commit/15dce6320d94bc66d0cfc255f48ff38c9f6022d5))

## [12.11.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.11.0...v12.11.1) (2026-09-08)

### Bug Fixes

* refuse to delete the Simulator root in mobile: deleteFile ([#2968](https://github.com/appium/appium-xcuitest-driver/issues/2968)) ([ed7dc6b](https://github.com/appium/appium-xcuitest-driver/commit/ed7dc6bbf25716b7f9d3b68bbff009f5bf83fcae))

## [12.11.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.10.0...v12.11.0) (2026-09-08)

### Features

* update supported HID and protected resource values ([#2967](https://github.com/appium/appium-xcuitest-driver/issues/2967)) ([a053cb3](https://github.com/appium/appium-xcuitest-driver/commit/a053cb3aae8deec90dfc77b41ec97a0a2a6c7d84))

## [12.10.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.9.1...v12.10.0) (2026-09-03)

### Features

* resolve web element origins to native coordinates in W3C actions ([#2966](https://github.com/appium/appium-xcuitest-driver/issues/2966)) ([988c54c](https://github.com/appium/appium-xcuitest-driver/commit/988c54c2a555e60dbb9d3f64c796fb489e0b22b9))

## [12.9.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.9.0...v12.9.1) (2026-09-02)

### Miscellaneous Chores

* bump support-related dependencies ([#2965](https://github.com/appium/appium-xcuitest-driver/issues/2965)) ([b4da83a](https://github.com/appium/appium-xcuitest-driver/commit/b4da83a70cfb761ba162f133223f264d1f4959f3))

## [12.9.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.8.3...v12.9.0) (2026-09-02)

### Features

* Add native Safari automation support ([#2962](https://github.com/appium/appium-xcuitest-driver/issues/2962)) ([3f43f95](https://github.com/appium/appium-xcuitest-driver/commit/3f43f9583bf9bee3bc611b8f83d325120c34ceed))

## [12.8.3](https://github.com/appium/appium-xcuitest-driver/compare/v12.8.2...v12.8.3) (2026-08-31)

### Bug Fixes

* stop using deprecated appium/support imageUtil, rely on local sharp ([#2963](https://github.com/appium/appium-xcuitest-driver/issues/2963)) ([8a913a1](https://github.com/appium/appium-xcuitest-driver/commit/8a913a1defbf34a117a717671fbf4c944b302398))

## [12.8.2](https://github.com/appium/appium-xcuitest-driver/compare/v12.8.1...v12.8.2) (2026-08-26)

### Bug Fixes

* route refresh/getUrl/title through waitForAtom for alert detection ([#2959](https://github.com/appium/appium-xcuitest-driver/issues/2959)) ([0fa28a3](https://github.com/appium/appium-xcuitest-driver/commit/0fa28a30cfa1a0a28919c888e60d4d7815beb7de))

## [12.8.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.8.0...v12.8.1) (2026-08-26)

### Bug Fixes

* log the real error when session creation fails ([#2958](https://github.com/appium/appium-xcuitest-driver/issues/2958)) ([280d6d5](https://github.com/appium/appium-xcuitest-driver/commit/280d6d5fca1c69d2d9ca1cc987fc85e24bf08d50))

## [12.8.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.7.0...v12.8.0) (2026-08-24)

### Features

* bump appium-webdriveragent to 16.8.0 and document accessibilityDeadline ([#2957](https://github.com/appium/appium-xcuitest-driver/issues/2957)) ([2e68d58](https://github.com/appium/appium-xcuitest-driver/commit/2e68d5827d0845655936fb0c64b7a9c45bcc493f))

### Code Refactoring

* Split some driver methods ([#2956](https://github.com/appium/appium-xcuitest-driver/issues/2956)) ([ec4dc7e](https://github.com/appium/appium-xcuitest-driver/commit/ec4dc7e2fb8f7db94551466e7c5b293f9b5d133f))

## [12.7.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.6.0...v12.7.0) (2026-08-21)

### Features

* add mobile: rotateDigitalCrown and mobile: performHandGesture for watchOS ([#2953](https://github.com/appium/appium-xcuitest-driver/issues/2953)) ([db6877c](https://github.com/appium/appium-xcuitest-driver/commit/db6877cd743981a8d16f579d224dcae127668e1f))

## [12.6.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.5.1...v12.6.0) (2026-08-20)

### Features

* wire watchOS support into the TS driver ([#2952](https://github.com/appium/appium-xcuitest-driver/issues/2952)) ([4075323](https://github.com/appium/appium-xcuitest-driver/commit/407532359115c1467b666a28b26a5e6c05b40e8a))

## [12.5.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.5.0...v12.5.1) (2026-08-20)

### Bug Fixes

* disable devicectl launch fallback for preinstalled WDA on iOS/tvOS 27+ ([#2949](https://github.com/appium/appium-xcuitest-driver/issues/2949)) ([2ecb946](https://github.com/appium/appium-xcuitest-driver/commit/2ecb9461ebc8ba81fccab94dbe5d47e92a09e9e3))

## [12.5.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.4.0...v12.5.0) (2026-08-17)

### Features

* support native web tap inside same-origin iframes, bump remote-debugger ([#2950](https://github.com/appium/appium-xcuitest-driver/issues/2950)) ([6f91d47](https://github.com/appium/appium-xcuitest-driver/commit/6f91d47349484742e05d9da56148a8c4d264f9a2))

## [12.4.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.3.4...v12.4.0) (2026-08-17)

### Features

* replace native web tap heuristics with automatic coordinate calibration ([#2948](https://github.com/appium/appium-xcuitest-driver/issues/2948)) ([9fd2107](https://github.com/appium/appium-xcuitest-driver/commit/9fd21077a6fda9a162713438edc635b9a7677361))

### Code Refactoring

* tighten typing in web commands and dedupe web-context guards ([#2947](https://github.com/appium/appium-xcuitest-driver/issues/2947)) ([96299f3](https://github.com/appium/appium-xcuitest-driver/commit/96299f38145d2fe7ba9624212933e71044c44039))

## [12.3.4](https://github.com/appium/appium-xcuitest-driver/compare/v12.3.3...v12.3.4) (2026-08-14)

### Bug Fixes

* honor implicit wait for findElements in web contexts ([#2946](https://github.com/appium/appium-xcuitest-driver/issues/2946)) ([c575cd2](https://github.com/appium/appium-xcuitest-driver/commit/c575cd2bad05e7101e29668cda96c270c0f3e9f3))

## [12.3.3](https://github.com/appium/appium-xcuitest-driver/compare/v12.3.2...v12.3.3) (2026-08-13)

### Bug Fixes

* force-kill hung performance recordings and restore device e2e tests ([#2945](https://github.com/appium/appium-xcuitest-driver/issues/2945)) ([36b4f8a](https://github.com/appium/appium-xcuitest-driver/commit/36b4f8a6b86d3d3f73fc448a27b332f78453a654))

## [12.3.2](https://github.com/appium/appium-xcuitest-driver/compare/v12.3.1...v12.3.2) (2026-08-12)

### Miscellaneous Chores

* Bump appium-remote-debugger ([#2942](https://github.com/appium/appium-xcuitest-driver/issues/2942)) ([0dfe915](https://github.com/appium/appium-xcuitest-driver/commit/0dfe9153f2e49a441a08fa3f607bf08b757c73e4))

## [12.3.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.3.0...v12.3.1) (2026-08-10)

### Miscellaneous Chores

* Bump appium-remote-debugger to v17 ([#2940](https://github.com/appium/appium-xcuitest-driver/issues/2940)) ([d5522ea](https://github.com/appium/appium-xcuitest-driver/commit/d5522ea68e5f0faf70b9b3e744f327346529c20f))

## [12.3.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.2.1...v12.3.0) (2026-08-08)

### Features

* Add customizable exponential backoff for tunnel reconnect retries ([#2936](https://github.com/appium/appium-xcuitest-driver/issues/2936)) ([84ed39d](https://github.com/appium/appium-xcuitest-driver/commit/84ed39dcaf274368f28fed85c980cf7d23ce470e))

## [12.2.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.2.0...v12.2.1) (2026-08-07)

### Miscellaneous Chores

* Drop chai ([#2935](https://github.com/appium/appium-xcuitest-driver/issues/2935)) ([d31bba4](https://github.com/appium/appium-xcuitest-driver/commit/d31bba46420d816098de8acc4bb0a27060c80b81))
* rename safe occurrences of JWProxy ([#2937](https://github.com/appium/appium-xcuitest-driver/issues/2937)) ([b479f7b](https://github.com/appium/appium-xcuitest-driver/commit/b479f7b12ceb32eba97e08f0b6a1eb44b9652b81))

## [12.2.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.1.4...v12.2.0) (2026-08-04)

### Features

* Add mobile extensions for DVT sysmontap system monitoring ([#2933](https://github.com/appium/appium-xcuitest-driver/issues/2933)) ([7ee1ba0](https://github.com/appium/appium-xcuitest-driver/commit/7ee1ba03862e2018488827d7bda0ce2eb1c79045))

## [12.1.4](https://github.com/appium/appium-xcuitest-driver/compare/v12.1.3...v12.1.4) (2026-08-01)

### Miscellaneous Chores

* Drop esmock ([#2932](https://github.com/appium/appium-xcuitest-driver/issues/2932)) ([d9798bd](https://github.com/appium/appium-xcuitest-driver/commit/d9798bd727f85d9a40e3313ffa243408e2c92760))

## [12.1.3](https://github.com/appium/appium-xcuitest-driver/compare/v12.1.2...v12.1.3) (2026-07-31)

### Bug Fixes

* Make closeWindow return remaining window handles per W3C spec ([#2931](https://github.com/appium/appium-xcuitest-driver/issues/2931)) ([4687938](https://github.com/appium/appium-xcuitest-driver/commit/46879386d3d2b06bba1992db412ba73e2ee3b391))

## [12.1.2](https://github.com/appium/appium-xcuitest-driver/compare/v12.1.1...v12.1.2) (2026-07-30)

### Miscellaneous Chores

* Harden MJPEG frame parsing and stream startup ([#2927](https://github.com/appium/appium-xcuitest-driver/issues/2927)) ([36bf6a0](https://github.com/appium/appium-xcuitest-driver/commit/36bf6a00f63265cd54b561e71ddc2bdae25da91e))

## [12.1.1](https://github.com/appium/appium-xcuitest-driver/compare/v12.1.0...v12.1.1) (2026-07-29)

### Miscellaneous Chores

* Integrate oxc and release configs ([#2925](https://github.com/appium/appium-xcuitest-driver/issues/2925)) ([6711a34](https://github.com/appium/appium-xcuitest-driver/commit/6711a34419402894d25cae00811da25cef6cc4ae))

## [12.1.0](https://github.com/appium/appium-xcuitest-driver/compare/v12.0.0...v12.1.0) (2026-07-24)

### Features

* Add codegraph support ([#2916](https://github.com/appium/appium-xcuitest-driver/issues/2916)) ([d23ae2c](https://github.com/appium/appium-xcuitest-driver/commit/d23ae2c451fa0d55da0489a2487d36dcb54ea570))

### Code Refactoring

* Isolate MJPEG helpers in the driver ([#2915](https://github.com/appium/appium-xcuitest-driver/issues/2915)) ([6fb7426](https://github.com/appium/appium-xcuitest-driver/commit/6fb7426c3948a91bec712bfff47bdb1b8ed35ab1))

## [12.0.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.17.7...v12.0.0) (2026-07-23)

### ⚠ BREAKING CHANGES

* Consumers using require('appium-xcuitest-driver') must switch to import/dynamic import() — the package no longer ships a CommonJS entry point.
* start is no longer callable as driver.start(...).
* stop is no longer callable as driver.stop(...).
* runReset is no longer callable as driver.runReset(...).
* configureApp is no longer callable as driver.configureApp(...).
* determineDevice is no longer callable as driver.determineDevice(...).
* setInitialOrientation is no longer callable as driver.setInitialOrientation(...).
* resetIos is no longer callable as driver.resetIos(...).
* mergeCliArgsToOpts is no longer callable as driver.mergeCliArgsToOpts(...).
* handleMjpegOptions is no longer callable as driver.handleMjpegOptions(...).
* allocateMjpegServerPort is no longer callable as driver.allocateMjpegServerPort(...).
* getDefaultUrl is no longer callable as driver.getDefaultUrl(...).
* onSettingsUpdate is no longer callable as driver.onSettingsUpdate(...).
* isXcodebuildNeeded is no longer callable as driver.isXcodebuildNeeded(...).
* createSim has been removed; it was already deprecated.
* startWdaSession is no longer callable as driver.startWdaSession(...).
* installAUT is no longer callable as driver.installAUT(...).
* installOtherApps is no longer callable as driver.installOtherApps(...).

### Features

* Migrate the package to ESM ([#2914](https://github.com/appium/appium-xcuitest-driver/issues/2914)) ([045f205](https://github.com/appium/appium-xcuitest-driver/commit/045f205056b8563b06ed59226329360590e63c60))

## [11.17.7](https://github.com/appium/appium-xcuitest-driver/compare/v11.17.6...v11.17.7) (2026-07-15)

### Miscellaneous Chores

* apply formatter ([08ec9db](https://github.com/appium/appium-xcuitest-driver/commit/08ec9db13fd4d4108aec35697975261c7c43dd07))

## [11.17.6](https://github.com/appium/appium-xcuitest-driver/compare/v11.17.5...v11.17.6) (2026-07-12)

### Bug Fixes

* bump WDA to include the mjpegScalingFactor fix ([6009729](https://github.com/appium/appium-xcuitest-driver/commit/60097297352f50485537c0023a3b95b2be44b6c9))

## [11.17.5](https://github.com/appium/appium-xcuitest-driver/compare/v11.17.4...v11.17.5) (2026-07-12)

### Bug Fixes

* bump WDA to fix lock screen behavior for iOS 27 ([ec326c6](https://github.com/appium/appium-xcuitest-driver/commit/ec326c66e60a6004baf92295c8d9b7323cc519f6))

## [11.17.4](https://github.com/appium/appium-xcuitest-driver/compare/v11.17.3...v11.17.4) (2026-07-10)

### Miscellaneous Chores

* Ditch mocha ([#2907](https://github.com/appium/appium-xcuitest-driver/issues/2907)) ([ae7cd09](https://github.com/appium/appium-xcuitest-driver/commit/ae7cd097c0592e87762a5960de51838c2c574b81))

## [11.17.3](https://github.com/appium/appium-xcuitest-driver/compare/v11.17.2...v11.17.3) (2026-07-08)

### Miscellaneous Chores

* Migrate moment to dayjs ([#2902](https://github.com/appium/appium-xcuitest-driver/issues/2902)) ([58d573e](https://github.com/appium/appium-xcuitest-driver/commit/58d573e9697f5af91153c8708a4fd0f59de35fbd))

## [11.17.2](https://github.com/appium/appium-xcuitest-driver/compare/v11.17.1...v11.17.2) (2026-07-08)

### Miscellaneous Chores

* Switch to oxfmt ([#2901](https://github.com/appium/appium-xcuitest-driver/issues/2901)) ([0eedd97](https://github.com/appium/appium-xcuitest-driver/commit/0eedd97d99af764cd16694dc9f996ab844b1a295))

## [11.17.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.17.0...v11.17.1) (2026-07-01)

### Miscellaneous Chores

* downgrade conventional-changelog-conventionalcommits to v9 ([#2896](https://github.com/appium/appium-xcuitest-driver/issues/2896)) ([f2c0355](https://github.com/appium/appium-xcuitest-driver/commit/f2c0355c0d2c132fb5315c9aa7148584330a44ad))

## [11.17.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.16.3...v11.17.0) (2026-07-01)

### Features

* Extend `mobile: getClipboard` and `mobile: setClipboard` APIs ([#2895](https://github.com/appium/appium-xcuitest-driver/issues/2895)) ([4505068](https://github.com/appium/appium-xcuitest-driver/commit/450506893aabdb7487e5dd9c6a1bd13fbe9de9a4))

## [11.16.3](https://github.com/appium/appium-xcuitest-driver/compare/v11.16.2...v11.16.3) (2026-06-29)

### Miscellaneous Chores

* **deps-dev:** remove unused mocha-junit-reporter ([#2892](https://github.com/appium/appium-xcuitest-driver/issues/2892)) ([55fb952](https://github.com/appium/appium-xcuitest-driver/commit/55fb952a8999ecaa65ca28c6eec089e11e41f578))

## [11.16.2](https://github.com/appium/appium-xcuitest-driver/compare/v11.16.1...v11.16.2) (2026-06-29)

### Miscellaneous Chores

* fix format ([#2893](https://github.com/appium/appium-xcuitest-driver/issues/2893)) ([3eabb5f](https://github.com/appium/appium-xcuitest-driver/commit/3eabb5f5592cdfb077d100b90200c487bf4bbc05))

## [11.16.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.16.0...v11.16.1) (2026-06-27)

### Miscellaneous Chores

* Replace the deprecated getDerivedDataPath usages on wda instance ([#2890](https://github.com/appium/appium-xcuitest-driver/issues/2890)) ([cadd653](https://github.com/appium/appium-xcuitest-driver/commit/cadd653138ed64b464a6f2886aa810c9bdd08aae))

### Code Refactoring

* Reorganize simulator commands into its own module ([#2889](https://github.com/appium/appium-xcuitest-driver/issues/2889)) ([9f894a1](https://github.com/appium/appium-xcuitest-driver/commit/9f894a1d75b9f1ae58d866d9604b0d378569023e))

## [11.16.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.15.0...v11.16.0) (2026-06-27)

### Features

* Tighten driver startup logic based on the host platform ([#2888](https://github.com/appium/appium-xcuitest-driver/issues/2888)) ([47060e1](https://github.com/appium/appium-xcuitest-driver/commit/47060e178d1de55f2ee4a63f5c4786daba7621a8))

## [11.15.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.14.1...v11.15.0) (2026-06-26)

### Features

* Add `mobile: performIndigoHidEvent` extension method ([#2887](https://github.com/appium/appium-xcuitest-driver/issues/2887)) ([7293917](https://github.com/appium/appium-xcuitest-driver/commit/7293917f6e7b0b87646b31e30c8944f7a6809489))

## [11.14.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.14.0...v11.14.1) (2026-06-24)

### Bug Fixes

* Only assert root after arguments parsing is finished ([#2886](https://github.com/appium/appium-xcuitest-driver/issues/2886)) ([6d9f317](https://github.com/appium/appium-xcuitest-driver/commit/6d9f317e8864d7161404a15c8a841e1b95815f26))

## [11.14.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.13.0...v11.14.0) (2026-06-23)

### Features

* Support platform abstraction in WDA ([#2884](https://github.com/appium/appium-xcuitest-driver/issues/2884)) ([98a585e](https://github.com/appium/appium-xcuitest-driver/commit/98a585eb176640a9ce876c757ae794aab94e236e))

## [11.13.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.12.2...v11.13.0) (2026-06-20)

### Features

* Make Apple TV discovery timeout configurable ([#2882](https://github.com/appium/appium-xcuitest-driver/issues/2882)) ([e9e006b](https://github.com/appium/appium-xcuitest-driver/commit/e9e006b5de99930e41602dc5e540ad0d3a375244))

## [11.12.2](https://github.com/appium/appium-xcuitest-driver/compare/v11.12.1...v11.12.2) (2026-06-19)

### Bug Fixes

* Make sure the tunnel process exits after an unexpected error ([#2878](https://github.com/appium/appium-xcuitest-driver/issues/2878)) ([a31696c](https://github.com/appium/appium-xcuitest-driver/commit/a31696cee1da738c4aff49b6ef2d07c40a8761a1))

## [11.12.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.12.0...v11.12.1) (2026-06-19)

### Miscellaneous Chores

* Improve tunnel creation logging ([#2879](https://github.com/appium/appium-xcuitest-driver/issues/2879)) ([85fd331](https://github.com/appium/appium-xcuitest-driver/commit/85fd3317c58d93c3c38d08e6bee6da73ad28c8b7))

## [11.12.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.11.2...v11.12.0) (2026-06-19)

### Features

* Bump appium-ios-remotexpc to ^5.0.0 ([#2874](https://github.com/appium/appium-xcuitest-driver/issues/2874)) ([5b767f3](https://github.com/appium/appium-xcuitest-driver/commit/5b767f3b8bb33a53ef263566bcfba3db04b4e32e))

## [11.11.2](https://github.com/appium/appium-xcuitest-driver/compare/v11.11.1...v11.11.2) (2026-06-11)

### Miscellaneous Chores

* bump appium-ios-simulator ([#2872](https://github.com/appium/appium-xcuitest-driver/issues/2872)) ([f7f7ae4](https://github.com/appium/appium-xcuitest-driver/commit/f7f7ae492da67a6cbf5cd533b28e87d61b38830c))

## [11.11.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.11.0...v11.11.1) (2026-06-10)

### Miscellaneous Chores

* Bump appium-ios-remotexpc ([#2870](https://github.com/appium/appium-xcuitest-driver/issues/2870)) ([932193b](https://github.com/appium/appium-xcuitest-driver/commit/932193b194831f5f15e7bb4f99563fe0ca1582db))

## [11.11.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.10.0...v11.11.0) (2026-06-10)

### Features

* Add VoiceOver mobile wrappers ([#2869](https://github.com/appium/appium-xcuitest-driver/issues/2869)) ([5c84ae7](https://github.com/appium/appium-xcuitest-driver/commit/5c84ae7e96dc6f68774fbdbf8c196710068af133))

## [11.10.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.9.1...v11.10.0) (2026-06-09)

### Features

* bump WDA to 14 for Xcode 27 build support ([#2865](https://github.com/appium/appium-xcuitest-driver/issues/2865)) ([fad5172](https://github.com/appium/appium-xcuitest-driver/commit/fad5172c03565417061dfb1196dc1f2d6270d824))

## [11.9.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.9.0...v11.9.1) (2026-06-08)

### Miscellaneous Chores

* Refactor css locator transformer ([#2864](https://github.com/appium/appium-xcuitest-driver/issues/2864)) ([74c6765](https://github.com/appium/appium-xcuitest-driver/commit/74c67655048d15f83053e17736d3f8a459d0cf67))

## [11.9.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.8.1...v11.9.0) (2026-06-03)

### Features

* Automatically terminate obsolete sessions using device id to be claimed by the current one ([#2863](https://github.com/appium/appium-xcuitest-driver/issues/2863)) ([2d82163](https://github.com/appium/appium-xcuitest-driver/commit/2d8216386d40f6c5a4f5382a9179b6306165c1d2))

## [11.8.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.8.0...v11.8.1) (2026-06-03)

### Bug Fixes

* Video attachments path for Xcode 26.5+ ([#2862](https://github.com/appium/appium-xcuitest-driver/issues/2862)) ([174ff70](https://github.com/appium/appium-xcuitest-driver/commit/174ff707cba80217197d81f9ee917e9abf66f973))

## [11.8.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.7.7...v11.8.0) (2026-06-02)

### Features

* **app:** use zip_conduit service for IPA installation/upgrade ([#2860](https://github.com/appium/appium-xcuitest-driver/issues/2860)) ([308ccfd](https://github.com/appium/appium-xcuitest-driver/commit/308ccfd1851a7bad1e0ae709aef617b32e07c922))

## [11.7.7](https://github.com/appium/appium-xcuitest-driver/compare/v11.7.6...v11.7.7) (2026-06-01)

### Miscellaneous Chores

* Tune AFC performance logging ([#2858](https://github.com/appium/appium-xcuitest-driver/issues/2858)) ([03a9145](https://github.com/appium/appium-xcuitest-driver/commit/03a91454a8db7571e401bd9dc6d42aae4552133a))

## [11.7.6](https://github.com/appium/appium-xcuitest-driver/compare/v11.7.5...v11.7.6) (2026-05-31)

### Miscellaneous Chores

* Add performance logging to real device app install ([#2857](https://github.com/appium/appium-xcuitest-driver/issues/2857)) ([3b460e6](https://github.com/appium/appium-xcuitest-driver/commit/3b460e68ba775c09abddbadf51abc61938730c8f))

## [11.7.5](https://github.com/appium/appium-xcuitest-driver/compare/v11.7.4...v11.7.5) (2026-05-31)

### Miscellaneous Chores

* Bump appium-ios-remotexpc version ([5183a86](https://github.com/appium/appium-xcuitest-driver/commit/5183a8625a70517b5a04e0773a3ad4fa3d25539a))

## [11.7.4](https://github.com/appium/appium-xcuitest-driver/compare/v11.7.3...v11.7.4) (2026-05-28)

### Miscellaneous Chores

* Tune error handling related to tunnels availability ([#2855](https://github.com/appium/appium-xcuitest-driver/issues/2855)) ([3670647](https://github.com/appium/appium-xcuitest-driver/commit/367064740da5812f3926dedcb9ebad4fd91d5629))

## [11.7.3](https://github.com/appium/appium-xcuitest-driver/compare/v11.7.2...v11.7.3) (2026-05-26)

### Miscellaneous Chores

* Document new WDA XPath lookup features ([#2852](https://github.com/appium/appium-xcuitest-driver/issues/2852)) ([78c3578](https://github.com/appium/appium-xcuitest-driver/commit/78c3578679cb53316429e16eb207afcb1079f2de))

## [11.7.2](https://github.com/appium/appium-xcuitest-driver/compare/v11.7.1...v11.7.2) (2026-05-26)

### Miscellaneous Chores

* Bump appium-ios-remotexpc to ^2.2.0 ([#2851](https://github.com/appium/appium-xcuitest-driver/issues/2851)) ([d2d3ec6](https://github.com/appium/appium-xcuitest-driver/commit/d2d3ec661ac748df3a18e6da8317a433ef213923))

## [11.7.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.7.0...v11.7.1) (2026-05-24)

### Bug Fixes

* Tune WDA cleanup ([#2849](https://github.com/appium/appium-xcuitest-driver/issues/2849)) ([417f7d4](https://github.com/appium/appium-xcuitest-driver/commit/417f7d473234e629e9e2886f730e945dbf8165fd))

## [11.7.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.6.1...v11.7.0) (2026-05-23)

### Features

* Ditch lodash ([#2846](https://github.com/appium/appium-xcuitest-driver/issues/2846)) ([daa3eb0](https://github.com/appium/appium-xcuitest-driver/commit/daa3eb0936a6552c0163c6e16065ed400e3a021f))

## [11.6.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.6.0...v11.6.1) (2026-05-22)

### Bug Fixes

* Embed app icon into Runner.app error in WDA build ([#2848](https://github.com/appium/appium-xcuitest-driver/issues/2848)) ([c8ce387](https://github.com/appium/appium-xcuitest-driver/commit/c8ce387baa7858edf43e4f06c7cca8f16c07d95c))

## [11.6.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.5.1...v11.6.0) (2026-05-21)

### Features

* Incorporate RSD isolation after remotexpc bump ([#2841](https://github.com/appium/appium-xcuitest-driver/issues/2841)) ([d1abfa0](https://github.com/appium/appium-xcuitest-driver/commit/d1abfa08c7c3f056183cdaa669167f6d0644def6))

## [11.5.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.5.0...v11.5.1) (2026-05-20)

### Bug Fixes

* barrel export loop ([#2844](https://github.com/appium/appium-xcuitest-driver/issues/2844)) ([d3a7576](https://github.com/appium/appium-xcuitest-driver/commit/d3a7576c2a1fc06a1cfbea219fa9d7b1220f26c6))

## [11.5.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.4.2...v11.5.0) (2026-05-19)

### Features

* Bump WDA to ^13.0.0 ([#2842](https://github.com/appium/appium-xcuitest-driver/issues/2842)) ([49b90f2](https://github.com/appium/appium-xcuitest-driver/commit/49b90f2f4734050260c7a1bab9f455a8d564346f))

## [11.4.2](https://github.com/appium/appium-xcuitest-driver/compare/v11.4.1...v11.4.2) (2026-05-15)

### Miscellaneous Chores

* Refactor wda signer code ([#2839](https://github.com/appium/appium-xcuitest-driver/issues/2839)) ([3aafb36](https://github.com/appium/appium-xcuitest-driver/commit/3aafb3600a103a129d4b9dd4452e4c9c4e1223b1))

## [11.4.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.4.0...v11.4.1) (2026-05-15)

### Bug Fixes

* prevent ECONNRESET by removing redundant RSD connections in AfcClient ([#2840](https://github.com/appium/appium-xcuitest-driver/issues/2840)) ([9ce708b](https://github.com/appium/appium-xcuitest-driver/commit/9ce708b768d1a2d88fec930ac01755637590e7a2))

## [11.4.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.3.1...v11.4.0) (2026-05-13)

### Features

* add resign task ([#2836](https://github.com/appium/appium-xcuitest-driver/issues/2836)) ([7dfca62](https://github.com/appium/appium-xcuitest-driver/commit/7dfca6298a0dd17b016d71793e465425bb04e59a))

## [11.3.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.3.0...v11.3.1) (2026-05-12)

### Miscellaneous Chores

* bump remotexpc to 1.1.8 ([#2838](https://github.com/appium/appium-xcuitest-driver/issues/2838)) ([46fc046](https://github.com/appium/appium-xcuitest-driver/commit/46fc046c47202b8c17c8d3cd2f6cee75b350e436))

## [11.3.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.2.4...v11.3.0) (2026-05-09)

### Features

* add download-wda command ([#2835](https://github.com/appium/appium-xcuitest-driver/issues/2835)) ([1f568b4](https://github.com/appium/appium-xcuitest-driver/commit/1f568b4823a75ede182afdc7c82b73193f554765))

## [11.2.4](https://github.com/appium/appium-xcuitest-driver/compare/v11.2.3...v11.2.4) (2026-05-08)

### Bug Fixes

* Tunnels cleanup ([#2834](https://github.com/appium/appium-xcuitest-driver/issues/2834)) ([e17218c](https://github.com/appium/appium-xcuitest-driver/commit/e17218c49111c500bef98aeee8d3739aafdfeb24))

## [11.2.3](https://github.com/appium/appium-xcuitest-driver/compare/v11.2.2...v11.2.3) (2026-05-07)

### Miscellaneous Chores

* Bump appium-ios-device ([#2833](https://github.com/appium/appium-xcuitest-driver/issues/2833)) ([b3549bc](https://github.com/appium/appium-xcuitest-driver/commit/b3549bcc5e5e6809b0e7c1f19604c5a2d71693ad))

## [11.2.2](https://github.com/appium/appium-xcuitest-driver/compare/v11.2.1...v11.2.2) (2026-05-07)

### Bug Fixes

* linter ([#2832](https://github.com/appium/appium-xcuitest-driver/issues/2832)) ([0c88d79](https://github.com/appium/appium-xcuitest-driver/commit/0c88d79db9b835891edc7dc21ef6109dc266a95d))

### Miscellaneous Chores

* Improve logging in RemotexpcPortForwarder ([#2830](https://github.com/appium/appium-xcuitest-driver/issues/2830)) ([c0369db](https://github.com/appium/appium-xcuitest-driver/commit/c0369dbfcc16b18e396e65816fe76344c4ce39f0))

## [11.2.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.2.0...v11.2.1) (2026-05-04)

### Miscellaneous Chores

* bump remotexpc to 1.1.2 ([#2828](https://github.com/appium/appium-xcuitest-driver/issues/2828)) ([aac9442](https://github.com/appium/appium-xcuitest-driver/commit/aac94425a032f8b6df757d112f11e249f375aca8))

## [11.2.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.1.0...v11.2.0) (2026-05-04)

### Features

* Drop bluebird usage ([#2827](https://github.com/appium/appium-xcuitest-driver/issues/2827)) ([2a10f32](https://github.com/appium/appium-xcuitest-driver/commit/2a10f32682ac562a321cd44ca366b4425c9b04f6))

## [11.1.0](https://github.com/appium/appium-xcuitest-driver/compare/v11.0.4...v11.1.0) (2026-05-01)

### Features

* Add mobile wrappers for start/stop screen recording ([#2825](https://github.com/appium/appium-xcuitest-driver/issues/2825)) ([2f3fece](https://github.com/appium/appium-xcuitest-driver/commit/2f3fececfbe91c3b54eb032afddb3e95ba05e065))

## [11.0.4](https://github.com/appium/appium-xcuitest-driver/compare/v11.0.3...v11.0.4) (2026-04-30)

### Bug Fixes

* Linter warnings ([#2823](https://github.com/appium/appium-xcuitest-driver/issues/2823)) ([208f56b](https://github.com/appium/appium-xcuitest-driver/commit/208f56bb4546d2d276a467c325c9192e0fe409e9))

## [11.0.3](https://github.com/appium/appium-xcuitest-driver/compare/v11.0.2...v11.0.3) (2026-04-29)

### Bug Fixes

* Log a warning instead of throwing an error on attachment deletion ([#2822](https://github.com/appium/appium-xcuitest-driver/issues/2822)) ([5a8ffd7](https://github.com/appium/appium-xcuitest-driver/commit/5a8ffd7e1e67432110b14e6efc17699b1f787e53))

## [11.0.2](https://github.com/appium/appium-xcuitest-driver/compare/v11.0.1...v11.0.2) (2026-04-29)

### Bug Fixes

* handle EPIPE for bsdtar ([#2821](https://github.com/appium/appium-xcuitest-driver/issues/2821)) ([63524d4](https://github.com/appium/appium-xcuitest-driver/commit/63524d4deaa8bf53d20212ea89fbd4ec1e6764d7))

## [11.0.1](https://github.com/appium/appium-xcuitest-driver/compare/v11.0.0...v11.0.1) (2026-04-24)

### Miscellaneous Chores

* Bump remotexpc version to ^1.0.0 ([#2818](https://github.com/appium/appium-xcuitest-driver/issues/2818)) ([63a02b8](https://github.com/appium/appium-xcuitest-driver/commit/63a02b87c7390fee0f98a9f4fcda81bf002cc3c1))

## [11.0.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.43.1...v11.0.0) (2026-04-14)

### ⚠ BREAKING CHANGES

* Drop appium-idb and the py-ios-device client. Remove
appium:launchWithIDB, mobile:startPcap / mobile:stopPcap, and
mobile:listXCTestsInTestBundle. XCTest mobile helpers are limited to real
devices on iOS/tvOS 18+ with appium-ios-remotexpc; logic XCTests and bare
.xctest install via old stacks are unsupported. Certificate and crash-report
paths on real devices require the same RemoteXPC setup.
* Remove capabilities appInstallStrategy, calendarAccessAuthorized,
useSimpleBuildTest, and waitForQuiescence (WDA quiescence is fixed; tune idle
behavior with appium:waitForIdleTimeout).
* Remove POST .../receive_async_response and the JWP-style
async callback flow. Async atoms use the remote debugger promise + waitForAtom
only; drop AsyncPromise from driver state.
* Stop emitting the legacy BiDi method appium.contextUpdated;
only appium:xcuitest.contextUpdated is emitted on context changes.
* Removed support for appium:simpleIsVisibleCheck and related WDA visibility-detection wiring because WebDriverAgent v12 no longer supports shouldUseTestManagerForVisibilityDetection/includeNonModalElements.

### Features

* Deprecate legacy features ([#2805](https://github.com/appium/appium-xcuitest-driver/issues/2805)) ([238552b](https://github.com/appium/appium-xcuitest-driver/commit/238552bf15a91bf51bcf3cc0674af9b6a331cc5f))

## [10.43.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.43.0...v10.43.1) (2026-04-10)

### Miscellaneous Chores

* **deps-dev:** bump typescript from 5.9.3 to 6.0.2 ([#2772](https://github.com/appium/appium-xcuitest-driver/issues/2772)) ([8fd6509](https://github.com/appium/appium-xcuitest-driver/commit/8fd6509b097373393b5b1c14d49fe9dda8e1ffd1))

### Code Refactoring

* Reduce unnecessary duplication in remotexpc utils ([#2798](https://github.com/appium/appium-xcuitest-driver/issues/2798)) ([3514d30](https://github.com/appium/appium-xcuitest-driver/commit/3514d305f57c78c997de0e115444f1dca5d477fa))

## [10.43.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.42.0...v10.43.0) (2026-04-06)

### Features

* Add a dedicated script for stale native videos cleanup on real devices ([#2796](https://github.com/appium/appium-xcuitest-driver/issues/2796)) ([2711d09](https://github.com/appium/appium-xcuitest-driver/commit/2711d09171dacb7325e41dc53accdbf51b8438ba))

## [10.42.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.41.0...v10.42.0) (2026-04-06)

### Features

* Use remotexpc to delete stale native video recordings ([#2795](https://github.com/appium/appium-xcuitest-driver/issues/2795)) ([2efb765](https://github.com/appium/appium-xcuitest-driver/commit/2efb7656cce9fb5e625b2076ca834b021996d87a))

## [10.41.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.40.2...v10.41.0) (2026-04-02)

### Features

* add appinfo and  for listapps `mobile: simctl` ([#2790](https://github.com/appium/appium-xcuitest-driver/issues/2790)) ([7fd8677](https://github.com/appium/appium-xcuitest-driver/commit/7fd867786a0209e87fe637c5fdc8c8b7016d1783))

## [10.40.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.40.1...v10.40.2) (2026-04-02)

### Miscellaneous Chores

* Mark `mobile: listXCTestsInTestBundle` as deprecated ([#2791](https://github.com/appium/appium-xcuitest-driver/issues/2791)) ([ad926eb](https://github.com/appium/appium-xcuitest-driver/commit/ad926eb8fdfd8f8e1550a1cf6d12fa8bb335e21c))

## [10.40.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.40.0...v10.40.1) (2026-04-02)

### Miscellaneous Chores

* Isolate legacy idb xctest helpers ([#2788](https://github.com/appium/appium-xcuitest-driver/issues/2788)) ([9ea03d5](https://github.com/appium/appium-xcuitest-driver/commit/9ea03d53815e2071610ec655b6db0a2b51961efe))

## [10.40.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.39.2...v10.40.0) (2026-04-02)

### Features

* Add a possibility to request multiple tunnels at once ([#2786](https://github.com/appium/appium-xcuitest-driver/issues/2786)) ([e9682ee](https://github.com/appium/appium-xcuitest-driver/commit/e9682eea5578d7c4c1d586f2fc18211b68cdeb46))

## [10.39.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.39.1...v10.39.2) (2026-04-01)

### Miscellaneous Chores

* Ensure pairing and tunnel creation scripts are running as root ([#2789](https://github.com/appium/appium-xcuitest-driver/issues/2789)) ([f252d91](https://github.com/appium/appium-xcuitest-driver/commit/f252d91d7b8ec2fae95dde4003bf504cf1a0de86))

## [10.39.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.39.0...v10.39.1) (2026-04-01)

### Miscellaneous Chores

* Isolate app termination logic for real devices ([#2787](https://github.com/appium/appium-xcuitest-driver/issues/2787)) ([ffbf88b](https://github.com/appium/appium-xcuitest-driver/commit/ffbf88bad32d4c84e1186a5c2dba33d69940c062))

## [10.39.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.38.0...v10.39.0) (2026-04-01)

### Features

* **xctest:** use remotexpc for xctest bundle execution ([#2775](https://github.com/appium/appium-xcuitest-driver/issues/2775)) ([1bb39ec](https://github.com/appium/appium-xcuitest-driver/commit/1bb39ec82da3da7d82a477819aa9447098c9a2b6))

## [10.38.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.37.0...v10.38.0) (2026-04-01)

### Features

* Add watchdog logic to the tunnel creation script ([#2785](https://github.com/appium/appium-xcuitest-driver/issues/2785)) ([8c3cf6b](https://github.com/appium/appium-xcuitest-driver/commit/8c3cf6bb527d69488f2ef53175b1a374c4b77c9f))

## [10.37.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.36.4...v10.37.0) (2026-04-01)

### Features

* Add extensions for listening to device network events ([#2781](https://github.com/appium/appium-xcuitest-driver/issues/2781)) ([68ce1ee](https://github.com/appium/appium-xcuitest-driver/commit/68ce1eea2d13e2f093f1e5c99cc081e04ca8b17d))

## [10.36.4](https://github.com/appium/appium-xcuitest-driver/compare/v10.36.3...v10.36.4) (2026-03-30)

### Bug Fixes

* fix cleanup immediately at the end of tunnel-creation ([#2784](https://github.com/appium/appium-xcuitest-driver/issues/2784)) ([9a42781](https://github.com/appium/appium-xcuitest-driver/commit/9a42781a6f25ac4396bfc31c8bc60c7b0b95b6ac))

## [10.36.3](https://github.com/appium/appium-xcuitest-driver/compare/v10.36.2...v10.36.3) (2026-03-30)

### Bug Fixes

* Install certificate using remotexpc as the main option ([#2780](https://github.com/appium/appium-xcuitest-driver/issues/2780)) ([42fba35](https://github.com/appium/appium-xcuitest-driver/commit/42fba35c54ab8be55d6faf40231389d938042311))

## [10.36.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.36.1...v10.36.2) (2026-03-29)

### Miscellaneous Chores

* Isolate internal condition inducer client logic ([#2778](https://github.com/appium/appium-xcuitest-driver/issues/2778)) ([38f9f9c](https://github.com/appium/appium-xcuitest-driver/commit/38f9f9c9dea45e5dda0990f985fc7235dad9f187))

## [10.36.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.36.0...v10.36.1) (2026-03-28)

### Miscellaneous Chores

* Refactor location helpers to isolate appium-ios-device usage ([#2777](https://github.com/appium/appium-xcuitest-driver/issues/2777)) ([9499e2c](https://github.com/appium/appium-xcuitest-driver/commit/9499e2c38100e302e07a5a8d493164c0452fc6dd))

## [10.36.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.35.0...v10.36.0) (2026-03-28)

### Features

* Prefer remotexpc for port forwarding ([#2776](https://github.com/appium/appium-xcuitest-driver/issues/2776)) ([717c9d6](https://github.com/appium/appium-xcuitest-driver/commit/717c9d6a2ad9154186b9e532460f44233ad643a5))

## [10.35.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.34.0...v10.35.0) (2026-03-27)

### Features

* Retrieve platform version from remotexpc ([#2774](https://github.com/appium/appium-xcuitest-driver/issues/2774)) ([b65ff7f](https://github.com/appium/appium-xcuitest-driver/commit/b65ff7f3a9116e8b9bb94a6de68d4d325709697a))

## [10.34.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.33.0...v10.34.0) (2026-03-27)

### Features

* Use remote-xpc for fetching device info ([#2773](https://github.com/appium/appium-xcuitest-driver/issues/2773)) ([4258b5a](https://github.com/appium/appium-xcuitest-driver/commit/4258b5ab2cbe9d1c10569866e60b1f2603a46c60))

## [10.33.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.32.1...v10.33.0) (2026-03-22)

### Features

* Add a helper script to list connected real devices ([#2769](https://github.com/appium/appium-xcuitest-driver/issues/2769)) ([ea7d11e](https://github.com/appium/appium-xcuitest-driver/commit/ea7d11e05a355d2750b7848f49b52bd9d5af5f07))

## [10.32.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.32.0...v10.32.1) (2026-03-17)

### Bug Fixes

* Strongbox usage in the tunnel creation script ([#2762](https://github.com/appium/appium-xcuitest-driver/issues/2762)) ([3bac69b](https://github.com/appium/appium-xcuitest-driver/commit/3bac69b53ff0a1edf965cbe4144d822204807f27))

## [10.32.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.31.0...v10.32.0) (2026-03-16)

### Features

* **device-log:** implement shim syslog ([#2760](https://github.com/appium/appium-xcuitest-driver/issues/2760)) ([3ee206f](https://github.com/appium/appium-xcuitest-driver/commit/3ee206fc3fbf7efe7bfc8a066f8d5cabbea0b6e5))

## [10.31.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.30.1...v10.31.0) (2026-03-16)

### Features

* Fetch connected devices from tunnels along with the legacy algorithm ([#2758](https://github.com/appium/appium-xcuitest-driver/issues/2758)) ([a4565a8](https://github.com/appium/appium-xcuitest-driver/commit/a4565a860ad9b2890e3716407f6b18ef6203c691))

## [10.30.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.30.0...v10.30.1) (2026-03-15)

### Bug Fixes

* force kill tunnells if still running ([#2759](https://github.com/appium/appium-xcuitest-driver/issues/2759)) ([d4e21e6](https://github.com/appium/appium-xcuitest-driver/commit/d4e21e6c9883185f2571fd89fbe58559d4d51c3f))

## [10.30.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.29.0...v10.30.0) (2026-03-14)

### Features

* Add wireless Apple TV  devices to created tunnels ([#2755](https://github.com/appium/appium-xcuitest-driver/issues/2755)) ([07911a7](https://github.com/appium/appium-xcuitest-driver/commit/07911a72199402f6163df201b909d5f3fc544641))

## [10.29.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.28.1...v10.29.0) (2026-03-14)

### Features

* Add script for pairing AppleTV over WiFi ([#2754](https://github.com/appium/appium-xcuitest-driver/issues/2754)) ([1912dd9](https://github.com/appium/appium-xcuitest-driver/commit/1912dd9549c303574100cb43b9732b3ebc84d16a))

## [10.28.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.28.0...v10.28.1) (2026-03-13)

### Bug Fixes

* Update cleanup logic in the tunnel creation script ([#2751](https://github.com/appium/appium-xcuitest-driver/issues/2751)) ([2ba43d4](https://github.com/appium/appium-xcuitest-driver/commit/2ba43d4a8cb16a5a2cedcda642386d8aa6ae418a))

## [10.28.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.27.0...v10.28.0) (2026-03-13)

### Features

* Add doctor checks for remotexpc ([#2748](https://github.com/appium/appium-xcuitest-driver/issues/2748)) ([94c3a19](https://github.com/appium/appium-xcuitest-driver/commit/94c3a197a13ff4a5b33490e0c2ef421f60729c5b))

## [10.27.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.26.0...v10.27.0) (2026-03-12)

### Features

* **appium-remote-debugger:** bump appium-remote-debugger to 15.6.0 to add shim web inspector support ([#2750](https://github.com/appium/appium-xcuitest-driver/issues/2750)) ([f0d85ab](https://github.com/appium/appium-xcuitest-driver/commit/f0d85ab5fe38214e33aea5f210d34ee7f4f09ae5))

## [10.26.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.25.0...v10.26.0) (2026-03-08)

### Features

* add snapshotMaxChildren settings ([#2745](https://github.com/appium/appium-xcuitest-driver/issues/2745)) ([7b97129](https://github.com/appium/appium-xcuitest-driver/commit/7b97129bce6eda30c206c812fc46bcfff99e37ce))

## [10.25.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.24.2...v10.25.0) (2026-03-05)

### Features

* add 2 iOS & 6 tvOS buttons for `mobile: pressButton` ([#2744](https://github.com/appium/appium-xcuitest-driver/issues/2744)) ([b591272](https://github.com/appium/appium-xcuitest-driver/commit/b5912728d93eaff6806da1fd87794e2c03bf2e5a))

## [10.24.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.24.1...v10.24.2) (2026-03-01)

### Bug Fixes

* send mobile scroll distance only for direction strategy ([#2741](https://github.com/appium/appium-xcuitest-driver/issues/2741)) ([ddcf4bc](https://github.com/appium/appium-xcuitest-driver/commit/ddcf4bc8b50ddde369bd3ebc1ec86a7d9a267f81))

## [10.24.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.24.0...v10.24.1) (2026-02-23)

### Bug Fixes

* make remote debugger options explicit ([#2739](https://github.com/appium/appium-xcuitest-driver/issues/2739)) ([1939ff5](https://github.com/appium/appium-xcuitest-driver/commit/1939ff5b0c34a6842d110c3dccd2a01698bfb686))

## [10.24.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.23.3...v10.24.0) (2026-02-23)

### Features

* add appium:ignoredWebviewBundleIds capability ([#2734](https://github.com/appium/appium-xcuitest-driver/issues/2734)) ([610ff18](https://github.com/appium/appium-xcuitest-driver/commit/610ff18ef5bd8a3df4aa390f8e2adbfc13aabf1c))

## [10.23.3](https://github.com/appium/appium-xcuitest-driver/compare/v10.23.2...v10.23.3) (2026-02-19)

### Bug Fixes

* Replace the deprecated url.parse with `new URL` ([#2735](https://github.com/appium/appium-xcuitest-driver/issues/2735)) ([4ea4537](https://github.com/appium/appium-xcuitest-driver/commit/4ea453728f8a7de1cb82afd406755bdf77229a89))

## [10.23.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.23.1...v10.23.2) (2026-02-18)

### Miscellaneous Chores

* Bump remote debugger ([#2733](https://github.com/appium/appium-xcuitest-driver/issues/2733)) ([a57c625](https://github.com/appium/appium-xcuitest-driver/commit/a57c62537e8ce6fa3fde721dbcf8fc0cc74cbf4c))

## [10.23.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.23.0...v10.23.1) (2026-02-17)

### Miscellaneous Chores

* Restore the legacy method of killing a process ([#2731](https://github.com/appium/appium-xcuitest-driver/issues/2731)) ([395e8bc](https://github.com/appium/appium-xcuitest-driver/commit/395e8bc6225742b1b584b4a3341c47a6222158af))

## [10.23.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.22.0...v10.23.0) (2026-02-17)

### Features

* Simplify terminateApp logic ([#2730](https://github.com/appium/appium-xcuitest-driver/issues/2730)) ([530a5be](https://github.com/appium/appium-xcuitest-driver/commit/530a5bea43d28d7cf178e4ac6cf343828a4a47ae))

## [10.22.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.21.3...v10.22.0) (2026-02-16)

### Features

* **process-control:** use remotexpc for `terminateApp` ([#2727](https://github.com/appium/appium-xcuitest-driver/issues/2727)) ([e89b9e3](https://github.com/appium/appium-xcuitest-driver/commit/e89b9e39a72680c27095ab8261fe8337a9cea335))

## [10.21.3](https://github.com/appium/appium-xcuitest-driver/compare/v10.21.2...v10.21.3) (2026-02-16)

### Bug Fixes

* format ([#2729](https://github.com/appium/appium-xcuitest-driver/issues/2729)) ([e32dd68](https://github.com/appium/appium-xcuitest-driver/commit/e32dd68ed2a255eadd8ae70c2382ba3b3a09a5b7))

## [10.21.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.21.1...v10.21.2) (2026-02-10)

### Bug Fixes

* fix type error for RemoteDebugger ([#2726](https://github.com/appium/appium-xcuitest-driver/issues/2726)) ([7d8d3d0](https://github.com/appium/appium-xcuitest-driver/commit/7d8d3d0282420cc04162c4e81290f958bdb9e592))

## [10.21.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.21.0...v10.21.1) (2026-02-07)

### Miscellaneous Chores

* Remove redundant typescript ignores ([#2725](https://github.com/appium/appium-xcuitest-driver/issues/2725)) ([812dbd3](https://github.com/appium/appium-xcuitest-driver/commit/812dbd3614c1221ee0ebf15172f1e90909f718df))

## [10.21.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.20.0...v10.21.0) (2026-02-05)

### Features

* **installation-proxy:** support retrieving specific attributes in `listApps` ([#2724](https://github.com/appium/appium-xcuitest-driver/issues/2724)) ([8631eec](https://github.com/appium/appium-xcuitest-driver/commit/8631eec6df2c4f12bae8a933e46915c577b417bb))

## [10.20.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.19.1...v10.20.0) (2026-02-04)

### Features

* **installation-proxy:** use remotexpc when iOS>=18 ([#2714](https://github.com/appium/appium-xcuitest-driver/issues/2714)) ([3e5ecc8](https://github.com/appium/appium-xcuitest-driver/commit/3e5ecc82346d2463ac62a74f5ca1b73192f186fd))

## [10.19.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.19.0...v10.19.1) (2026-02-01)

### Miscellaneous Chores

* **deps-dev:** bump @appium/eslint-config-appium-ts from 2.0.5 to 3.0.0 ([#2721](https://github.com/appium/appium-xcuitest-driver/issues/2721)) ([ab6a5b9](https://github.com/appium/appium-xcuitest-driver/commit/ab6a5b94f81bd2da28dfbe80f33abb3a65e2afd5))

## [10.19.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.18.2...v10.19.0) (2026-02-01)

### Features

* **notification:** implement shim notification proxy and unified notification client ([#2722](https://github.com/appium/appium-xcuitest-driver/issues/2722)) ([c286824](https://github.com/appium/appium-xcuitest-driver/commit/c2868241b25c62e379e55997d4a491420786852f))

## [10.18.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.18.1...v10.18.2) (2026-01-27)

### Miscellaneous Chores

* **deps:** bump asyncbox from 4.1.1 to 6.0.1 ([#2719](https://github.com/appium/appium-xcuitest-driver/issues/2719)) ([2861cdc](https://github.com/appium/appium-xcuitest-driver/commit/2861cdc989f8c41bedce2a62f3f5b81dc2454297))

## [10.18.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.18.0...v10.18.1) (2026-01-23)

### Miscellaneous Chores

* Exclude tests from the published dist ([38e02c0](https://github.com/appium/appium-xcuitest-driver/commit/38e02c07af337b1f3c9388c9d8e3c4e1e84c3317))

## [10.18.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.17.1...v10.18.0) (2026-01-23)

### Features

* use `isIos18OrNewer` to check version instead of ios-device util ([#2716](https://github.com/appium/appium-xcuitest-driver/issues/2716)) ([0af4cc4](https://github.com/appium/appium-xcuitest-driver/commit/0af4cc4f92fe6d48f078061bacab0e72ddec0c7c))

## [10.17.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.17.0...v10.17.1) (2026-01-21)

### Miscellaneous Chores

* Update minimum appium-webdriveragent version to 11.1.1 ([2b8fa1e](https://github.com/appium/appium-xcuitest-driver/commit/2b8fa1ee63c4fe4d7175d142577ba6c2abb6e74d))

## [10.17.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.16.2...v10.17.0) (2026-01-20)

### Features

* **crash-reports:** use remotexpc when iOS>=18 ([#2712](https://github.com/appium/appium-xcuitest-driver/issues/2712)) ([3dfe6cb](https://github.com/appium/appium-xcuitest-driver/commit/3dfe6cb4bb7d4d2a556d61c02078a96150be4282))

## [10.16.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.16.1...v10.16.2) (2026-01-20)

### Bug Fixes

* Real device app installation ([#2715](https://github.com/appium/appium-xcuitest-driver/issues/2715)) ([f457d66](https://github.com/appium/appium-xcuitest-driver/commit/f457d6630432abcf6b213477000e1ff31aaece8b))

## [10.16.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.16.0...v10.16.1) (2026-01-19)

### Miscellaneous Chores

* Remove unnecessary duplication upon certificate client creation ([#2713](https://github.com/appium/appium-xcuitest-driver/issues/2713)) ([9189cfe](https://github.com/appium/appium-xcuitest-driver/commit/9189cfed1ce60e746f85853f4e33408a43e622b7))

## [10.16.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.15.0...v10.16.0) (2026-01-19)

### Features

* **certificate:** implement shim functionality ([#2698](https://github.com/appium/appium-xcuitest-driver/issues/2698)) ([7b94dca](https://github.com/appium/appium-xcuitest-driver/commit/7b94dca389395ce0573808a04872215bfc09862e))

## [10.15.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.13...v10.15.0) (2026-01-17)

### Features

* migrate afc and house arrest to use remotexpc when iOS>=18 ([#2696](https://github.com/appium/appium-xcuitest-driver/issues/2696)) ([3ba9fbf](https://github.com/appium/appium-xcuitest-driver/commit/3ba9fbf0e381afcec7c1f6e2daf24690cb0e58e2))

## [10.14.13](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.12...v10.14.13) (2026-01-16)

### Miscellaneous Chores

* include scripts to run type checks ([#2711](https://github.com/appium/appium-xcuitest-driver/issues/2711)) ([b00f289](https://github.com/appium/appium-xcuitest-driver/commit/b00f289d4e087d49e148f7518251f17bf67236da))

## [10.14.12](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.11...v10.14.12) (2026-01-16)

### Reverts

* Revert "chore: remove unused getUserInstalledBundleIdsByBundleName API" ([#2710](https://github.com/appium/appium-xcuitest-driver/issues/2710)) ([a800d88](https://github.com/appium/appium-xcuitest-driver/commit/a800d885275ee07e5ab9d18638e4eed0b6f1e392))

## [10.14.11](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.10...v10.14.11) (2026-01-15)

### Bug Fixes

* remove removed xcode version arg from build-wda and convert it to mjs ([#2706](https://github.com/appium/appium-xcuitest-driver/issues/2706)) ([b4a40d8](https://github.com/appium/appium-xcuitest-driver/commit/b4a40d8e560bcaa7aea88aa1459b02d9e289a520))

### Code Refactoring

* centralize remoteXPC initialization  ([#2703](https://github.com/appium/appium-xcuitest-driver/issues/2703)) ([c9ec568](https://github.com/appium/appium-xcuitest-driver/commit/c9ec5684413164e2df14cd4b4dcd48aff0c5a369))
* Incapsulate condition inducer implementation details ([#2704](https://github.com/appium/appium-xcuitest-driver/issues/2704)) ([d5f4064](https://github.com/appium/appium-xcuitest-driver/commit/d5f40648aee2a334b79335c3181ac0610d17a38b))

## [10.14.10](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.9...v10.14.10) (2026-01-12)

### Bug Fixes

* fallback to existing method ([#2701](https://github.com/appium/appium-xcuitest-driver/issues/2701)) ([20658dd](https://github.com/appium/appium-xcuitest-driver/commit/20658ddc3229594cabdeaf24b0804d430ccba234))

## [10.14.9](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.8...v10.14.9) (2026-01-12)

### Miscellaneous Chores

* remove unused getUserInstalledBundleIdsByBundleName API ([821596d](https://github.com/appium/appium-xcuitest-driver/commit/821596d800ce328bea834c6ca57b795db8c6e583))

## [10.14.8](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.7...v10.14.8) (2026-01-12)

### Miscellaneous Chores

* Unify real device and simulator requirement checks ([#2700](https://github.com/appium/appium-xcuitest-driver/issues/2700)) ([0e5c98a](https://github.com/appium/appium-xcuitest-driver/commit/0e5c98a259cd4365148fa7b8152cd45e8788ea4c))

## [10.14.7](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.6...v10.14.7) (2026-01-08)

### Miscellaneous Chores

* Migrate index to typescript ([#2699](https://github.com/appium/appium-xcuitest-driver/issues/2699)) ([bb4c7ff](https://github.com/appium/appium-xcuitest-driver/commit/bb4c7ffb4cff23461c2f2e63ff626749972c3d65))

## [10.14.6](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.5...v10.14.6) (2026-01-07)

### Miscellaneous Chores

* Migrate the rest of commands to typescript (part 10) ([#2697](https://github.com/appium/appium-xcuitest-driver/issues/2697)) ([73a5cde](https://github.com/appium/appium-xcuitest-driver/commit/73a5cdee66df6df5d78e4518c603d4dad2b780d7))

## [10.14.5](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.4...v10.14.5) (2026-01-06)

### Miscellaneous Chores

* Migrate various commands to typescript (part 9) ([#2695](https://github.com/appium/appium-xcuitest-driver/issues/2695)) ([615b21f](https://github.com/appium/appium-xcuitest-driver/commit/615b21f166ad967e9cb6b3962c9dfed1c7b267e3))

## [10.14.4](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.3...v10.14.4) (2026-01-05)

### Miscellaneous Chores

* Migrate various commands to typescript (part 8) ([#2694](https://github.com/appium/appium-xcuitest-driver/issues/2694)) ([a8438e3](https://github.com/appium/appium-xcuitest-driver/commit/a8438e3d3bd497ba5c3c8b11c03927463a364213))

## [10.14.3](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.2...v10.14.3) (2026-01-04)

### Miscellaneous Chores

* Migrate various command modules to typescript (part 7) ([#2693](https://github.com/appium/appium-xcuitest-driver/issues/2693)) ([1286364](https://github.com/appium/appium-xcuitest-driver/commit/128636475c1eac6ea5c73da3dcebb2eb9d539c4d))

## [10.14.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.1...v10.14.2) (2026-01-01)

### Miscellaneous Chores

* Migrate various command modules to typescript (part 6) ([#2692](https://github.com/appium/appium-xcuitest-driver/issues/2692)) ([3736824](https://github.com/appium/appium-xcuitest-driver/commit/37368246181f2e4096ce80ae76e3d458ea39c711))

## [10.14.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.14.0...v10.14.1) (2025-12-31)

### Miscellaneous Chores

* Migrate various command modules to typescript (part 5) ([#2691](https://github.com/appium/appium-xcuitest-driver/issues/2691)) ([0cd46fd](https://github.com/appium/appium-xcuitest-driver/commit/0cd46fdc6fb62df5ee61e8008f53a65f1aec4c5d))

## [10.14.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.13.4...v10.14.0) (2025-12-30)

### Features

* add documentation for customActions ([#2690](https://github.com/appium/appium-xcuitest-driver/issues/2690)) ([c8a0473](https://github.com/appium/appium-xcuitest-driver/commit/c8a04730a62353752a5142dab04115e3afe155db))

## [10.13.4](https://github.com/appium/appium-xcuitest-driver/compare/v10.13.3...v10.13.4) (2025-12-30)

### Miscellaneous Chores

* Migrate various command modules to typescript (part 4) ([#2689](https://github.com/appium/appium-xcuitest-driver/issues/2689)) ([e7da99b](https://github.com/appium/appium-xcuitest-driver/commit/e7da99b79461927b785ec518475ee604c163fdc9))

## [10.13.3](https://github.com/appium/appium-xcuitest-driver/compare/v10.13.2...v10.13.3) (2025-12-28)

### Miscellaneous Chores

* Migrate various command modules to typescript ([#2688](https://github.com/appium/appium-xcuitest-driver/issues/2688)) ([43489ba](https://github.com/appium/appium-xcuitest-driver/commit/43489ba00eef50c1e026ba878c31859de63849e9))

## [10.13.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.13.1...v10.13.2) (2025-12-23)

### Miscellaneous Chores

* Migrate various command modules (part 2) ([#2687](https://github.com/appium/appium-xcuitest-driver/issues/2687)) ([3b47a66](https://github.com/appium/appium-xcuitest-driver/commit/3b47a664379bf5b1d20472ce83c74ce34ab7a661))

## [10.13.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.13.0...v10.13.1) (2025-12-23)

### Bug Fixes

* prevent raising error in safari session ([#2686](https://github.com/appium/appium-xcuitest-driver/issues/2686)) ([7c7f5cb](https://github.com/appium/appium-xcuitest-driver/commit/7c7f5cbe6d27634ce52d9024b40673973be0289c))

## [10.13.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.12.2...v10.13.0) (2025-12-23)

### Features

* Migrate various command modules to typescript (part 1) ([#2683](https://github.com/appium/appium-xcuitest-driver/issues/2683)) ([c0b53ba](https://github.com/appium/appium-xcuitest-driver/commit/c0b53ba8fd212ce09f9d4c4d45f869a7c3f40fd2))

## [10.12.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.12.1...v10.12.2) (2025-12-22)

### Miscellaneous Chores

* **deps:** bump teen_process from 3.0.6 to 4.0.4 ([#2684](https://github.com/appium/appium-xcuitest-driver/issues/2684)) ([005e984](https://github.com/appium/appium-xcuitest-driver/commit/005e9846229fc2d4bcb468758f4e653a295599e6))

## [10.12.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.12.0...v10.12.1) (2025-12-22)

### Miscellaneous Chores

* Bump major appium-webdriveragent version to 11 ([#2682](https://github.com/appium/appium-xcuitest-driver/issues/2682)) ([c70e413](https://github.com/appium/appium-xcuitest-driver/commit/c70e4138a151932b4cd5a81b020660b0220f70f3))

## [10.12.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.11.0...v10.12.0) (2025-12-18)

### Features

* Add `enforceCustomSnapshots` setting ([#2680](https://github.com/appium/appium-xcuitest-driver/issues/2680)) ([6758bee](https://github.com/appium/appium-xcuitest-driver/commit/6758beea9d8580d8e4d983b213b07cb96c5e63de))

### Miscellaneous Chores

* **deps:** bump asyncbox from 3.0.0 to 4.0.1 ([#2681](https://github.com/appium/appium-xcuitest-driver/issues/2681)) ([6998151](https://github.com/appium/appium-xcuitest-driver/commit/6998151da802a57276e2149eb21844e087f0430a))

## [10.11.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.10.1...v10.11.0) (2025-12-13)

### Features

* Migrate various modules to typescript ([#2672](https://github.com/appium/appium-xcuitest-driver/issues/2672)) ([b8c86a9](https://github.com/appium/appium-xcuitest-driver/commit/b8c86a969419326d48f37510b0e7c4819b9fe851))

## [10.10.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.10.0...v10.10.1) (2025-12-11)

### Miscellaneous Chores

* **deps-dev:** bump @types/node from 24.10.3 to 25.0.0 ([#2671](https://github.com/appium/appium-xcuitest-driver/issues/2671)) ([a176bf2](https://github.com/appium/appium-xcuitest-driver/commit/a176bf21c146919f6ba666240c3241eceb605957))

## [10.10.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.9.2...v10.10.0) (2025-12-11)

### Features

* add APPIUM_XCUITEST_PREFER_DEVICECTL for app installed check also ([#2669](https://github.com/appium/appium-xcuitest-driver/issues/2669)) ([5900a9c](https://github.com/appium/appium-xcuitest-driver/commit/5900a9c769c43fe8e65a7fcfafb9aeeac1a74d36))

## [10.9.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.9.1...v10.9.2) (2025-12-11)

### Miscellaneous Chores

* **deps:** remove `source-map-support` ([#2670](https://github.com/appium/appium-xcuitest-driver/issues/2670)) ([539801a](https://github.com/appium/appium-xcuitest-driver/commit/539801a688848c91e67b999cbdc54b0536046929))

## [10.9.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.9.0...v10.9.1) (2025-12-07)

### Miscellaneous Chores

* Ditch usage of @appium/test-support ([#2668](https://github.com/appium/appium-xcuitest-driver/issues/2668)) ([bcc4772](https://github.com/appium/appium-xcuitest-driver/commit/bcc4772a2f8d6074c5e248904a8ac6e1cf101567))

## [10.9.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.8.4...v10.9.0) (2025-11-29)

### Features

* Migrate driver module to typescript ([#2666](https://github.com/appium/appium-xcuitest-driver/issues/2666)) ([619c679](https://github.com/appium/appium-xcuitest-driver/commit/619c67916bffd98fd4b00cbca58159ec27bd6c4c))

## [10.8.4](https://github.com/appium/appium-xcuitest-driver/compare/v10.8.3...v10.8.4) (2025-11-27)

### Miscellaneous Chores

* Migrate device helpers to typescript ([#2664](https://github.com/appium/appium-xcuitest-driver/issues/2664)) ([34590b9](https://github.com/appium/appium-xcuitest-driver/commit/34590b92cc749b4a30cd2132bf9a6877ac1346fc))

## [10.8.3](https://github.com/appium/appium-xcuitest-driver/compare/v10.8.2...v10.8.3) (2025-11-26)

### Miscellaneous Chores

* Mark 'launchWithIDB' capability as deprecated ([#2663](https://github.com/appium/appium-xcuitest-driver/issues/2663)) ([c5a541c](https://github.com/appium/appium-xcuitest-driver/commit/c5a541ca72f51d40fc6512c619306b75a8551933))

## [10.8.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.8.1...v10.8.2) (2025-11-26)

### Miscellaneous Chores

* Strip the obsolete translateDeviceName helper ([#2662](https://github.com/appium/appium-xcuitest-driver/issues/2662)) ([9ee20c5](https://github.com/appium/appium-xcuitest-driver/commit/9ee20c52af0fda84ba11e9b387a6b464919d9454))

## [10.8.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.8.0...v10.8.1) (2025-11-25)

### Bug Fixes

* Update mobile: resetLocationService endpoint ([#2661](https://github.com/appium/appium-xcuitest-driver/issues/2661)) ([c361c08](https://github.com/appium/appium-xcuitest-driver/commit/c361c08896f99839f2441a8e669f58d7ca6a0052))

## [10.8.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.7.0...v10.8.0) (2025-11-22)

### Features

* add support for condition inducer DVT service via remotexpc ([#2657](https://github.com/appium/appium-xcuitest-driver/issues/2657)) ([98abbb8](https://github.com/appium/appium-xcuitest-driver/commit/98abbb8232698b8bc4d3dd70a132b769a46c29f8))

## [10.7.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.6.0...v10.7.0) (2025-11-22)

### Features

* Bump ios-simulator ([#2658](https://github.com/appium/appium-xcuitest-driver/issues/2658)) ([0384e5d](https://github.com/appium/appium-xcuitest-driver/commit/0384e5dd0db6a005a4ed0e68060b5839a08730c8))

## [10.6.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.5.1...v10.6.0) (2025-11-22)

### Features

* add context for BiDi LogEntrySource ([#2656](https://github.com/appium/appium-xcuitest-driver/issues/2656)) ([daa0a56](https://github.com/appium/appium-xcuitest-driver/commit/daa0a56adcca9b237939b989299553f7a7a2415d))

## [10.5.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.5.0...v10.5.1) (2025-11-15)

### Miscellaneous Chores

* publish via trusted publisher ([#2653](https://github.com/appium/appium-xcuitest-driver/issues/2653)) ([7c208a1](https://github.com/appium/appium-xcuitest-driver/commit/7c208a14525b46b19c08ae05d6e8ae4e6efd7421))

## [10.5.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.4.3...v10.5.0) (2025-11-11)

### Features

* Bump appium-remote-debugger for iOS 26.2 beta webview ([#2652](https://github.com/appium/appium-xcuitest-driver/issues/2652)) ([20c5591](https://github.com/appium/appium-xcuitest-driver/commit/20c55917cc35faf287e49fd2f6a321af4e7e2215))

## [10.4.3](https://github.com/appium/appium-xcuitest-driver/compare/v10.4.2...v10.4.3) (2025-11-03)

### Miscellaneous Chores

* update webdriveragent to 10.2.1 ([#2645](https://github.com/appium/appium-xcuitest-driver/issues/2645)) ([899842a](https://github.com/appium/appium-xcuitest-driver/commit/899842a7ceb9a4a66f4c25be36fbc3408fb28e95))

## [10.4.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.4.1...v10.4.2) (2025-11-03)

### Bug Fixes

* Use devicectl while listing available device udids ([#2648](https://github.com/appium/appium-xcuitest-driver/issues/2648)) ([5953a97](https://github.com/appium/appium-xcuitest-driver/commit/5953a979ef7f2b15b415ddb819ccb4bfd26680dd))

## [10.4.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.4.0...v10.4.1) (2025-11-03)

### Miscellaneous Chores

* Ditch unused cookie-related functions ([#2647](https://github.com/appium/appium-xcuitest-driver/issues/2647)) ([f068585](https://github.com/appium/appium-xcuitest-driver/commit/f0685855a9014b6ee7d4281e77fe67563848ddd0))

## [10.4.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.3.0...v10.4.0) (2025-11-02)

### Features

* Make command exports more straightforward ([#2646](https://github.com/appium/appium-xcuitest-driver/issues/2646)) ([254bc04](https://github.com/appium/appium-xcuitest-driver/commit/254bc0468bba9cee4437286495ba7c0273ddd16e))

## [10.3.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.2.2...v10.3.0) (2025-11-02)

### Features

* Switch to devicectl module usage ([#2644](https://github.com/appium/appium-xcuitest-driver/issues/2644)) ([7e7e642](https://github.com/appium/appium-xcuitest-driver/commit/7e7e64263a225e90bf48d1e14b7fd961acba9ede))

## [10.2.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.2.1...v10.2.2) (2025-10-17)

### Miscellaneous Chores

* **deps-dev:** bump semantic-release from 24.2.9 to 25.0.0 ([#2642](https://github.com/appium/appium-xcuitest-driver/issues/2642)) ([059aabc](https://github.com/appium/appium-xcuitest-driver/commit/059aabc38d33cebd448b314320318be09228317e))

## [10.2.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.2.0...v10.2.1) (2025-10-10)

### Miscellaneous Chores

* Migrate doctor checks to typescript ([#2640](https://github.com/appium/appium-xcuitest-driver/issues/2640)) ([1bd49a7](https://github.com/appium/appium-xcuitest-driver/commit/1bd49a74a2e7789efd2cc52527b4559e9c91aa64))

## [10.2.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.1.7...v10.2.0) (2025-10-10)

### Features

* Add optional simulator doctor check ([#2639](https://github.com/appium/appium-xcuitest-driver/issues/2639)) ([201d451](https://github.com/appium/appium-xcuitest-driver/commit/201d4519d051546dfd3b9f94f87e19a7914b7932))

## [10.1.7](https://github.com/appium/appium-xcuitest-driver/compare/v10.1.6...v10.1.7) (2025-10-10)

### Miscellaneous Chores

* Improve some doctor messaging ([#2638](https://github.com/appium/appium-xcuitest-driver/issues/2638)) ([701b083](https://github.com/appium/appium-xcuitest-driver/commit/701b0839fe0cd9fa899a6fa7a1bc06a0e9dc5689))

## [10.1.6](https://github.com/appium/appium-xcuitest-driver/compare/v10.1.5...v10.1.6) (2025-10-06)

### Miscellaneous Chores

* Migrate open-wda script to ESM ([#2637](https://github.com/appium/appium-xcuitest-driver/issues/2637)) ([f441b88](https://github.com/appium/appium-xcuitest-driver/commit/f441b88cfac77829eed4b59214ff8475bd876738))

## [10.1.5](https://github.com/appium/appium-xcuitest-driver/compare/v10.1.4...v10.1.5) (2025-10-05)

### Miscellaneous Chores

* Update ESM script imports ([#2636](https://github.com/appium/appium-xcuitest-driver/issues/2636)) ([6cafc44](https://github.com/appium/appium-xcuitest-driver/commit/6cafc44468f0f20ce53ca2ca4c4d9b267911eb9f))

## [10.1.4](https://github.com/appium/appium-xcuitest-driver/compare/v10.1.3...v10.1.4) (2025-10-03)

### Miscellaneous Chores

* Bump remote debugger ([#2635](https://github.com/appium/appium-xcuitest-driver/issues/2635)) ([387f2df](https://github.com/appium/appium-xcuitest-driver/commit/387f2dfdcc39ac209d126207134d9920717bc660))

## [10.1.3](https://github.com/appium/appium-xcuitest-driver/compare/v10.1.2...v10.1.3) (2025-10-01)

### Miscellaneous Chores

* Unlock winston ([9649bd1](https://github.com/appium/appium-xcuitest-driver/commit/9649bd1de0c045813751f8f4d5eb4af0a0e1f271))

## [10.1.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.1.1...v10.1.2) (2025-09-16)

### Miscellaneous Chores

* Bump remote debugger ([#2626](https://github.com/appium/appium-xcuitest-driver/issues/2626)) ([4ef1a50](https://github.com/appium/appium-xcuitest-driver/commit/4ef1a50bdd003680b40a4529200d49c26c4286fc))

## [10.1.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.1.0...v10.1.1) (2025-09-15)

### Miscellaneous Chores

* **deps-dev:** remove type-fest dependency ([#2624](https://github.com/appium/appium-xcuitest-driver/issues/2624)) ([8dd7dab](https://github.com/appium/appium-xcuitest-driver/commit/8dd7dabd0e58d815e7a8c47f27aa1e86a2ca856a))
* **deps:** bump appium-ios-remotexpc from 0.3.3 to 0.x ([#2625](https://github.com/appium/appium-xcuitest-driver/issues/2625)) ([555262b](https://github.com/appium/appium-xcuitest-driver/commit/555262b7634620bf6465d186c5a3c68f5b054992))

## [10.1.0](https://github.com/appium/appium-xcuitest-driver/compare/v10.0.6...v10.1.0) (2025-09-08)

### Features

* Bump remote debugger ([#2621](https://github.com/appium/appium-xcuitest-driver/issues/2621)) ([04d48ab](https://github.com/appium/appium-xcuitest-driver/commit/04d48ab2e37b089db3d8834d856dbf4193e1bdb1))

## [10.0.6](https://github.com/appium/appium-xcuitest-driver/compare/v10.0.5...v10.0.6) (2025-09-05)

### Bug Fixes

* add TypeScript declarations to npm package files ([#2620](https://github.com/appium/appium-xcuitest-driver/issues/2620)) ([15c0798](https://github.com/appium/appium-xcuitest-driver/commit/15c079840ce2c91552bc3110d49a0f9bf12c406d))

## [10.0.5](https://github.com/appium/appium-xcuitest-driver/compare/v10.0.4...v10.0.5) (2025-09-03)

### Miscellaneous Chores

* Bump WDA ([#2619](https://github.com/appium/appium-xcuitest-driver/issues/2619)) ([280b1bc](https://github.com/appium/appium-xcuitest-driver/commit/280b1bc6bb0e612eb08c3242648c83bb42e38973))

## [10.0.4](https://github.com/appium/appium-xcuitest-driver/compare/v10.0.3...v10.0.4) (2025-08-29)

### Miscellaneous Chores

* Bump remote debugger ([#2618](https://github.com/appium/appium-xcuitest-driver/issues/2618)) ([5167d1b](https://github.com/appium/appium-xcuitest-driver/commit/5167d1bc1d2baed85dd2564aa24a28cf00bb1a0f))

## [10.0.3](https://github.com/appium/appium-xcuitest-driver/compare/v10.0.2...v10.0.3) (2025-08-27)

### Miscellaneous Chores

* bump appium-ios-remotexpc to publish with latest ([#2616](https://github.com/appium/appium-xcuitest-driver/issues/2616)) ([67487f5](https://github.com/appium/appium-xcuitest-driver/commit/67487f50a65a17f9ccebe01091441dfdcf95ff32))

## [10.0.2](https://github.com/appium/appium-xcuitest-driver/compare/v10.0.1...v10.0.2) (2025-08-24)

### Miscellaneous Chores

* **deps:** bump lru-cache from 10.4.3 to 11.1.0 ([#2539](https://github.com/appium/appium-xcuitest-driver/issues/2539)) ([ed46fbd](https://github.com/appium/appium-xcuitest-driver/commit/ed46fbdc975c08998cd41689f8b886cf3158561e))

## [10.0.1](https://github.com/appium/appium-xcuitest-driver/compare/v10.0.0...v10.0.1) (2025-08-23)

### Miscellaneous Chores

* **deps-dev:** bump chai from 5.3.2 to 6.0.0 ([#2612](https://github.com/appium/appium-xcuitest-driver/issues/2612)) ([66db332](https://github.com/appium/appium-xcuitest-driver/commit/66db332bca5f16ca68bbfc6ced2dcd72c9c51d1a))

## [10.0.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.10.5...v10.0.0) (2025-08-19)

### ⚠ BREAKING CHANGES

* Required Node.js version has been bumped to ^20.19.0 || ^22.12.0 || >=24.0.0
* Required npm version has been bumped to >=10
* Required Appium server version has been bumped to >=3.0.0-rc.2

### Features

* Update server compatibility for Appium 3 ([#2590](https://github.com/appium/appium-xcuitest-driver/issues/2590)) ([313578a](https://github.com/appium/appium-xcuitest-driver/commit/313578ac565d54b402ade9fd542f6138ac928594))

## [9.10.5](https://github.com/appium/appium-xcuitest-driver/compare/v9.10.4...v9.10.5) (2025-08-17)

### Miscellaneous Chores

* drop rimraf deps from dev deps as no references ([#2607](https://github.com/appium/appium-xcuitest-driver/issues/2607)) ([0dc17bd](https://github.com/appium/appium-xcuitest-driver/commit/0dc17bd86e6fafdcb76aeee44d64388ea6ab6d58))

## [9.10.4](https://github.com/appium/appium-xcuitest-driver/compare/v9.10.3...v9.10.4) (2025-08-06)

### Bug Fixes

* Make sure session id is set before cleaning up socket handlers ([#2604](https://github.com/appium/appium-xcuitest-driver/issues/2604)) ([3c73836](https://github.com/appium/appium-xcuitest-driver/commit/3c738363c1c7bb6106d6b2584558a0891dd8a47c))

## [9.10.3](https://github.com/appium/appium-xcuitest-driver/compare/v9.10.2...v9.10.3) (2025-08-04)

### Miscellaneous Chores

* bump appium-ios-device to 2.9.0 ([#2603](https://github.com/appium/appium-xcuitest-driver/issues/2603)) ([69a6ca9](https://github.com/appium/appium-xcuitest-driver/commit/69a6ca95391b9dce74d8130fd818705a20ac073e))

## [9.10.2](https://github.com/appium/appium-xcuitest-driver/compare/v9.10.1...v9.10.2) (2025-08-03)

### Miscellaneous Chores

* leave wda version info or debugging ([#2602](https://github.com/appium/appium-xcuitest-driver/issues/2602)) ([b683532](https://github.com/appium/appium-xcuitest-driver/commit/b68353263eb7a8fb814a6dcbb8b532df3a40a799))

## [9.10.1](https://github.com/appium/appium-xcuitest-driver/compare/v9.10.0...v9.10.1) (2025-07-26)

### Miscellaneous Chores

* make  appium-ios-remotexpc optional deps ([#2600](https://github.com/appium/appium-xcuitest-driver/issues/2600)) ([5d956cf](https://github.com/appium/appium-xcuitest-driver/commit/5d956cf1653e48d5f5dc699ae63a70c67c2499ed))

## [9.10.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.9.6...v9.10.0) (2025-07-25)

### Features

* Added support for fetching batteryInformation from shim service ([#2592](https://github.com/appium/appium-xcuitest-driver/issues/2592)) ([8dce773](https://github.com/appium/appium-xcuitest-driver/commit/8dce77333b7c7c719492c03268a50de7631d8c79)), closes [#2593](https://github.com/appium/appium-xcuitest-driver/issues/2593)

## [9.9.6](https://github.com/appium/appium-xcuitest-driver/compare/v9.9.5...v9.9.6) (2025-07-13)

### Miscellaneous Chores

* Improve atom execution timeout error message ([#2598](https://github.com/appium/appium-xcuitest-driver/issues/2598)) ([34c5ac4](https://github.com/appium/appium-xcuitest-driver/commit/34c5ac421ef333f5af298bb7723d9ac1be42d2d2))

## [9.9.5](https://github.com/appium/appium-xcuitest-driver/compare/v9.9.4...v9.9.5) (2025-07-10)

### Miscellaneous Chores

* Bump remote debugger ([#2596](https://github.com/appium/appium-xcuitest-driver/issues/2596)) ([a10b91d](https://github.com/appium/appium-xcuitest-driver/commit/a10b91dc16213527f0c7f57f247e8cb70c211b40))

## [9.9.4](https://github.com/appium/appium-xcuitest-driver/compare/v9.9.3...v9.9.4) (2025-07-04)

### Bug Fixes

* Safari network logging ([#2594](https://github.com/appium/appium-xcuitest-driver/issues/2594)) ([c2afe9e](https://github.com/appium/appium-xcuitest-driver/commit/c2afe9e773c23ac624a6a1638a2b1eecfd13e2ec))

## [9.9.3](https://github.com/appium/appium-xcuitest-driver/compare/v9.9.2...v9.9.3) (2025-07-03)

### Miscellaneous Chores

* bump remote debugger ([7540f38](https://github.com/appium/appium-xcuitest-driver/commit/7540f3875367bc7c739334a60ddbddb699112d0b))

## [9.9.2](https://github.com/appium/appium-xcuitest-driver/compare/v9.9.1...v9.9.2) (2025-07-03)

### Miscellaneous Chores

* Bump remote debugger ([edab935](https://github.com/appium/appium-xcuitest-driver/commit/edab935a5964aa4a6033e92e69db18b00493976a))

## [9.9.1](https://github.com/appium/appium-xcuitest-driver/compare/v9.9.0...v9.9.1) (2025-06-28)

### Bug Fixes

* add @ temporary fix ([#2588](https://github.com/appium/appium-xcuitest-driver/issues/2588)) ([f0ffbf6](https://github.com/appium/appium-xcuitest-driver/commit/f0ffbf6133458c3c3bcf69a1dbefc992c1ad599e))

## [9.9.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.8.1...v9.9.0) (2025-06-26)

### Features

* add download-wda-sim to download prebuilt WDA for Sim ([#2587](https://github.com/appium/appium-xcuitest-driver/issues/2587)) ([c1fb5a4](https://github.com/appium/appium-xcuitest-driver/commit/c1fb5a4df52cc8d8816c0a362916570d8236275d))

## [9.8.1](https://github.com/appium/appium-xcuitest-driver/compare/v9.8.0...v9.8.1) (2025-06-25)

### Miscellaneous Chores

* **deps-dev:** bump sinon from 20.0.0 to 21.0.0 ([#2579](https://github.com/appium/appium-xcuitest-driver/issues/2579)) ([c5100ed](https://github.com/appium/appium-xcuitest-driver/commit/c5100eda36750640c5c2e8aaf6d459b7951477ca))

## [9.8.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.7.0...v9.8.0) (2025-06-24)

### Features

* Save tunnel registry using strong box ([#2585](https://github.com/appium/appium-xcuitest-driver/issues/2585)) ([8868b1a](https://github.com/appium/appium-xcuitest-driver/commit/8868b1aba093d996d41cc47b17e4ae077457f2b7))

## [9.7.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.6.1...v9.7.0) (2025-06-15)

### Features

* add iosSyslogFile as a capability ([#2582](https://github.com/appium/appium-xcuitest-driver/issues/2582)) ([43448b4](https://github.com/appium/appium-xcuitest-driver/commit/43448b4a924a5304c947501b7e79a472a2ab6e74))

## [9.6.1](https://github.com/appium/appium-xcuitest-driver/compare/v9.6.0...v9.6.1) (2025-06-12)

### Miscellaneous Chores

* **deps-dev:** bump @types/node from 22.15.31 to 24.0.1 ([#2578](https://github.com/appium/appium-xcuitest-driver/issues/2578)) ([c0cfd0e](https://github.com/appium/appium-xcuitest-driver/commit/c0cfd0e7c427bb8eb7e2f08cb97f9488ece98577))

## [9.6.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.5.0...v9.6.0) (2025-06-10)

### Features

* Hardware Acceleration for Video Decode, Encode and Scaling ([#2559](https://github.com/appium/appium-xcuitest-driver/issues/2559)) ([d21345a](https://github.com/appium/appium-xcuitest-driver/commit/d21345a1b8e34d136033550937298c6f2e08111b))

## [9.5.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.4.0...v9.5.0) (2025-06-10)

### Features

* add documentation with min/max value ([#2576](https://github.com/appium/appium-xcuitest-driver/issues/2576)) ([c296411](https://github.com/appium/appium-xcuitest-driver/commit/c2964111ea1924baf0594e8d3f7a0aa22c22b50a))
* add focused attribute to element representation in XML source tree ([#2575](https://github.com/appium/appium-xcuitest-driver/issues/2575)) ([14ccdce](https://github.com/appium/appium-xcuitest-driver/commit/14ccdce9b80a2f06c121fd6f0adef83c06567082))

## [9.4.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.3.2...v9.4.0) (2025-06-04)

### Features

* add documentation for new appium setting: includeHittableInPageSource ([#2571](https://github.com/appium/appium-xcuitest-driver/issues/2571)) ([de310a3](https://github.com/appium/appium-xcuitest-driver/commit/de310a39a64f835e534ee9f5453539487a5bbe79))

### Code Refactoring

* use an object spread instead of Object.assign ([#2570](https://github.com/appium/appium-xcuitest-driver/issues/2570)) ([16bae3a](https://github.com/appium/appium-xcuitest-driver/commit/16bae3acb0e3cee456218d09db9f6b8846f336d4))

## [9.3.2](https://github.com/appium/appium-xcuitest-driver/compare/v9.3.1...v9.3.2) (2025-05-31)

### Miscellaneous Chores

* fix typos ([#2568](https://github.com/appium/appium-xcuitest-driver/issues/2568)) ([a1f5842](https://github.com/appium/appium-xcuitest-driver/commit/a1f5842402c189e91a09ba5b7250a584d434f56e))
* use optional chain for better readability ([#2569](https://github.com/appium/appium-xcuitest-driver/issues/2569)) ([035efc0](https://github.com/appium/appium-xcuitest-driver/commit/035efc0c8cf435ffbaf2355e0054bd589969af58))

## [9.3.1](https://github.com/appium/appium-xcuitest-driver/compare/v9.3.0...v9.3.1) (2025-05-29)

### Miscellaneous Chores

* Add geolocation endpoints to the method map ([#2567](https://github.com/appium/appium-xcuitest-driver/issues/2567)) ([95a0be7](https://github.com/appium/appium-xcuitest-driver/commit/95a0be784d516b7880c5f546f6ccd63b62379d3f))

## [9.3.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.2.5...v9.3.0) (2025-05-28)

### Features

* Add traits attributes ([#2566](https://github.com/appium/appium-xcuitest-driver/issues/2566)) ([73429cd](https://github.com/appium/appium-xcuitest-driver/commit/73429cd7b9a2e9054dc35ae87be5d2c0e1c62d56))

## [9.2.5](https://github.com/appium/appium-xcuitest-driver/compare/v9.2.4...v9.2.5) (2025-05-21)

### Miscellaneous Chores

* **deps-dev:** bump conventional-changelog-conventionalcommits ([#2564](https://github.com/appium/appium-xcuitest-driver/issues/2564)) ([5d98175](https://github.com/appium/appium-xcuitest-driver/commit/5d98175ddc71bff3d38bedbf3cf18ca5d859a665))

## [9.2.4](https://github.com/appium/appium-xcuitest-driver/compare/v9.2.3...v9.2.4) (2025-05-01)

### Miscellaneous Chores

* bump WDA to 9.6.2 ([59a8ffc](https://github.com/appium/appium-xcuitest-driver/commit/59a8ffccdd12fb3e66c72750d650a81b6c4fa88d))

## [9.2.3](https://github.com/appium/appium-xcuitest-driver/compare/v9.2.2...v9.2.3) (2025-04-23)

### Miscellaneous Chores

* add deprecated marks in lib/method-map.js ([#2554](https://github.com/appium/appium-xcuitest-driver/issues/2554)) ([73c83c0](https://github.com/appium/appium-xcuitest-driver/commit/73c83c0c083f683fad0631b251fa8bd69c325870))

## [9.2.2](https://github.com/appium/appium-xcuitest-driver/compare/v9.2.1...v9.2.2) (2025-04-23)

### Bug Fixes

* update mjpegScalingFactor data type settings.md with WDA 9.6.1 ([#2556](https://github.com/appium/appium-xcuitest-driver/issues/2556)) ([7eaff7b](https://github.com/appium/appium-xcuitest-driver/commit/7eaff7b3bac7d4659689f75e0687db17075dfd07))

## [9.2.1](https://github.com/appium/appium-xcuitest-driver/compare/v9.2.0...v9.2.1) (2025-04-20)

### Bug Fixes

* Missing text in long text for get text/value ([#2553](https://github.com/appium/appium-xcuitest-driver/issues/2553)) ([95d8c6d](https://github.com/appium/appium-xcuitest-driver/commit/95d8c6dbcf5790e7ebb704786581453103c7dbec))

## [9.2.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.1.4...v9.2.0) (2025-04-10)

### Features

* Bump WDA to enable the autoClickAlertSelector setting ([#2550](https://github.com/appium/appium-xcuitest-driver/issues/2550)) ([3136cbe](https://github.com/appium/appium-xcuitest-driver/commit/3136cbedb4a172eb3d782be3e20853a6b174cf2c))

## [9.1.4](https://github.com/appium/appium-xcuitest-driver/compare/v9.1.3...v9.1.4) (2025-04-05)

### Miscellaneous Chores

* bump appium-ios-simulator to include a fix for applesimutils usage ([49d401e](https://github.com/appium/appium-xcuitest-driver/commit/49d401eacba45a14e22bc01c4da9ab80a4985379))

## [9.1.3](https://github.com/appium/appium-xcuitest-driver/compare/v9.1.2...v9.1.3) (2025-04-02)

### Miscellaneous Chores

* Bump WDA ([2a59ee5](https://github.com/appium/appium-xcuitest-driver/commit/2a59ee573303c5ee7e0c8a323e1de08da505f10a))

## [9.1.2](https://github.com/appium/appium-xcuitest-driver/compare/v9.1.1...v9.1.2) (2025-03-31)

### Miscellaneous Chores

* **deps-dev:** bump sinon from 19.0.5 to 20.0.0 ([#2540](https://github.com/appium/appium-xcuitest-driver/issues/2540)) ([96e30a9](https://github.com/appium/appium-xcuitest-driver/commit/96e30a95027b8f5beab5cd32d888a654ab3f2fdc))

## [9.1.1](https://github.com/appium/appium-xcuitest-driver/compare/v9.1.0...v9.1.1) (2025-03-31)

### Bug Fixes

* bind this ([#2543](https://github.com/appium/appium-xcuitest-driver/issues/2543)) ([c9adc42](https://github.com/appium/appium-xcuitest-driver/commit/c9adc421f72124dc4243cb0f2df73c620c6554b5))

## [9.1.0](https://github.com/appium/appium-xcuitest-driver/compare/v9.0.2...v9.1.0) (2025-03-31)

### Features

* add skipDocumentsContainerCheck settings to apply [#2541](https://github.com/appium/appium-xcuitest-driver/issues/2541) change ([#2542](https://github.com/appium/appium-xcuitest-driver/issues/2542)) ([abf13cf](https://github.com/appium/appium-xcuitest-driver/commit/abf13cfe1d4acf723a0bd7873bf63bfa8b8673bd))

## [9.0.2](https://github.com/appium/appium-xcuitest-driver/compare/v9.0.1...v9.0.2) (2025-03-27)

### Miscellaneous Chores

* Bump WDA ([fe7cce1](https://github.com/appium/appium-xcuitest-driver/commit/fe7cce11931893bfa193f7128169a5986d882f4f))

## [9.0.1](https://github.com/appium/appium-xcuitest-driver/compare/v9.0.0...v9.0.1) (2025-03-26)

### Miscellaneous Chores

* Bump WDA ([9c0341e](https://github.com/appium/appium-xcuitest-driver/commit/9c0341eaeb80b8e19212348d8125efaec1661d6c))

## [9.0.0](https://github.com/appium/appium-xcuitest-driver/compare/v8.4.3...v9.0.0) (2025-03-24)

### ⚠ BREAKING CHANGES

* The following deprecated driver methods were removed:
- getWindowSizeWeb
- getWindowSizeNative

### Features

* Switch size retrieval to use the W3C window/rect endpoint ([#2538](https://github.com/appium/appium-xcuitest-driver/issues/2538)) ([cdc421f](https://github.com/appium/appium-xcuitest-driver/commit/cdc421f70dba0ad907d180fc23f4719724fe0bcf))

## [8.4.3](https://github.com/appium/appium-xcuitest-driver/compare/v8.4.2...v8.4.3) (2025-03-14)

### Miscellaneous Chores

* Bump WDA ([#2535](https://github.com/appium/appium-xcuitest-driver/issues/2535)) ([7a20be7](https://github.com/appium/appium-xcuitest-driver/commit/7a20be72c3b5c45d056d1a2bba28088a4caba19d))

## [8.4.2](https://github.com/appium/appium-xcuitest-driver/compare/v8.4.1...v8.4.2) (2025-03-13)

### Bug Fixes

* Make sure a proper file names encoding is used while unzipping files from app bundles ([#2534](https://github.com/appium/appium-xcuitest-driver/issues/2534)) ([cb4034a](https://github.com/appium/appium-xcuitest-driver/commit/cb4034a86924578119a8639452268230ae0f1f71))

## [8.4.1](https://github.com/appium/appium-xcuitest-driver/compare/v8.4.0...v8.4.1) (2025-03-13)

### Miscellaneous Chores

* Bump remote debugger ([0272eee](https://github.com/appium/appium-xcuitest-driver/commit/0272eee54a5c88c2a87cb81213620062dfc7de82))

## [8.4.0](https://github.com/appium/appium-xcuitest-driver/compare/v8.3.3...v8.4.0) (2025-03-09)

### Features

* add placeholderValue explicitly as an element attribute ([#2529](https://github.com/appium/appium-xcuitest-driver/issues/2529)) ([5c4aee5](https://github.com/appium/appium-xcuitest-driver/commit/5c4aee50ee661fdceeda920c8008c761ec91323d))

## [8.3.3](https://github.com/appium/appium-xcuitest-driver/compare/v8.3.2...v8.3.3) (2025-02-25)

### Miscellaneous Chores

* Bump remote debugger ([9b7c329](https://github.com/appium/appium-xcuitest-driver/commit/9b7c329ff9fef4acc140ac3836c10410cd4f0b96))

## [8.3.2](https://github.com/appium/appium-xcuitest-driver/compare/v8.3.1...v8.3.2) (2025-02-21)

### Bug Fixes

* Pass reqBasePath proxy option ([#2527](https://github.com/appium/appium-xcuitest-driver/issues/2527)) ([234c16c](https://github.com/appium/appium-xcuitest-driver/commit/234c16ce00096e83ad2156c69d236bf2c297c353))

## [8.3.1](https://github.com/appium/appium-xcuitest-driver/compare/v8.3.0...v8.3.1) (2025-02-06)

### Miscellaneous Chores

* bump wda version to 9.0.3 ([b645987](https://github.com/appium/appium-xcuitest-driver/commit/b64598758ee5040d98ff9bda6872d8b5a0ff125e))

## [8.3.0](https://github.com/appium/appium-xcuitest-driver/compare/v8.2.0...v8.3.0) (2025-01-30)

### Features

* always use vendContainer to add files without extra app permissions ([#2522](https://github.com/appium/appium-xcuitest-driver/issues/2522)) ([6f3e7b5](https://github.com/appium/appium-xcuitest-driver/commit/6f3e7b5b30f7f5c438cd0cc0fce1f2aa7a3f4f3b))

## [8.2.0](https://github.com/appium/appium-xcuitest-driver/compare/v8.1.0...v8.2.0) (2025-01-29)

### Features

* add increase contrast and content size commands ([#2520](https://github.com/appium/appium-xcuitest-driver/issues/2520)) ([a3fc183](https://github.com/appium/appium-xcuitest-driver/commit/a3fc18322fcded1842acf7ce7d56ad82cb4312ca))

## [8.1.0](https://github.com/appium/appium-xcuitest-driver/compare/v8.0.0...v8.1.0) (2025-01-21)

### Features

* create port forward when mjpegServerPort is provided in caps ([#2517](https://github.com/appium/appium-xcuitest-driver/issues/2517)) ([ed4c9cf](https://github.com/appium/appium-xcuitest-driver/commit/ed4c9cfa55c988b69140c08dcec01edde7b6b371))

## [8.0.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.35.1...v8.0.0) (2025-01-17)

### ⚠ BREAKING CHANGES

* Removed the customSnapshotTimeout setting as a result of WDA upgrade to v9

### Features

* Bump WDA to v9 ([#2511](https://github.com/appium/appium-xcuitest-driver/issues/2511)) ([3067ae5](https://github.com/appium/appium-xcuitest-driver/commit/3067ae5f75520b750925e4a9671a8441a05ffdf8))

## [7.35.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.35.0...v7.35.1) (2025-01-03)

### Miscellaneous Chores

* Bump eslint version ([#2508](https://github.com/appium/appium-xcuitest-driver/issues/2508)) ([565e6bc](https://github.com/appium/appium-xcuitest-driver/commit/565e6bc345f07678e77134f9b84182fa996b1853))

## [7.35.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.34.2...v7.35.0) (2024-12-23)

### Features

* Bump appium-ios-device to support USBMUXD_SOCKET_ADDRESS ([#2507](https://github.com/appium/appium-xcuitest-driver/issues/2507)) ([a8adca8](https://github.com/appium/appium-xcuitest-driver/commit/a8adca87556d1b42265ba5b2474b7e4d23050c84))

## [7.34.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.34.1...v7.34.2) (2024-12-19)

### Bug Fixes

* Adjust log level for BiDi events ([#2505](https://github.com/appium/appium-xcuitest-driver/issues/2505)) ([1a73fcd](https://github.com/appium/appium-xcuitest-driver/commit/1a73fcd0c879f2bb70e0c431e110c8d601ff754d))

## [7.34.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.34.0...v7.34.1) (2024-12-14)

### Miscellaneous Chores

* Tune contextUpdated event generation ([#2503](https://github.com/appium/appium-xcuitest-driver/issues/2503)) ([8ee8fcf](https://github.com/appium/appium-xcuitest-driver/commit/8ee8fcfd0898c7a38c4bb5064d18360d2eb45451))

## [7.34.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.33.1...v7.34.0) (2024-12-13)

### Features

* extend to handle critical notification elements in respectSystemAlerts settings ([#2502](https://github.com/appium/appium-xcuitest-driver/issues/2502)) ([b4fcccb](https://github.com/appium/appium-xcuitest-driver/commit/b4fcccb1c79f0d6b3dcc4041267893b849c2f557))

## [7.33.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.33.0...v7.33.1) (2024-12-12)

### Miscellaneous Chores

* Replace occurrences of the deprecated errorAndThrow API ([#2501](https://github.com/appium/appium-xcuitest-driver/issues/2501)) ([d2122eb](https://github.com/appium/appium-xcuitest-driver/commit/d2122ebb86e82026ede34803c33a5234e4111982))

## [7.33.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.32.1...v7.33.0) (2024-12-09)

### Features

* Screenshooting of web elements ([#2499](https://github.com/appium/appium-xcuitest-driver/issues/2499)) ([b12e4dd](https://github.com/appium/appium-xcuitest-driver/commit/b12e4dd449895d5d4a4909c0b74df5a401013b69))

## [7.32.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.32.0...v7.32.1) (2024-12-03)

### Miscellaneous Chores

* **deps-dev:** bump mocha from 10.8.2 to 11.0.1 ([#2497](https://github.com/appium/appium-xcuitest-driver/issues/2497)) ([4e9eabc](https://github.com/appium/appium-xcuitest-driver/commit/4e9eabc43fcc537b0dcda246fadfb263555046be))

## [7.32.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.31.0...v7.32.0) (2024-11-16)

### Features

* Add a BiDi event upon context change ([#2494](https://github.com/appium/appium-xcuitest-driver/issues/2494)) ([09c824d](https://github.com/appium/appium-xcuitest-driver/commit/09c824d357b62574d8c89da76735e58756964442))

## [7.31.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.30.0...v7.31.0) (2024-11-12)

### Features

* Add support for excluded_attributes to source api with json format ([#2493](https://github.com/appium/appium-xcuitest-driver/issues/2493)) ([85eed0a](https://github.com/appium/appium-xcuitest-driver/commit/85eed0aed39650b95bc4b82e05c3834dbc270b5c))

## [7.30.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.29.1...v7.30.0) (2024-11-12)

### Features

* Return default native window handle in native context ([#2491](https://github.com/appium/appium-xcuitest-driver/issues/2491)) ([0a545e0](https://github.com/appium/appium-xcuitest-driver/commit/0a545e0e63f67c3d57ca551f8eff163fceff35b4))

## [7.29.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.29.0...v7.29.1) (2024-11-11)

### Bug Fixes

* Tune simulator app architecture validation ([#2492](https://github.com/appium/appium-xcuitest-driver/issues/2492)) ([0738ae9](https://github.com/appium/appium-xcuitest-driver/commit/0738ae9a6db8da8a47fe08c6d9e2d463c1c17591))

## [7.29.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.28.3...v7.29.0) (2024-11-11)

### Features

* add useClearTextShortcut to setting api ([#2490](https://github.com/appium/appium-xcuitest-driver/issues/2490)) ([f54a157](https://github.com/appium/appium-xcuitest-driver/commit/f54a1570da5ca791ccb1f3f7402dafd1b9860c1b))

## [7.28.3](https://github.com/appium/appium-xcuitest-driver/compare/v7.28.2...v7.28.3) (2024-10-23)

### Bug Fixes

* Add accessible attribute to the xml tree in case of useJSONSource ([#2484](https://github.com/appium/appium-xcuitest-driver/issues/2484)) ([e25ac81](https://github.com/appium/appium-xcuitest-driver/commit/e25ac81dcba287362c49c5768fcc4ab0c09de18c))

## [7.28.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.28.1...v7.28.2) (2024-10-23)

### Bug Fixes

* typo in .npmrc ([#2483](https://github.com/appium/appium-xcuitest-driver/issues/2483)) ([8b09ef0](https://github.com/appium/appium-xcuitest-driver/commit/8b09ef08c5eb39800c3f31cba15256fe1b69d4b3))

## [7.28.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.28.0...v7.28.1) (2024-10-18)

### Bug Fixes

* bump WDA to fix transient overlay windows handling when respectSystemAlerts is enabled ([#2482](https://github.com/appium/appium-xcuitest-driver/issues/2482)) ([e504a6d](https://github.com/appium/appium-xcuitest-driver/commit/e504a6dc6fca4a4d5480a4a37d47b2f26cdee243))

## [7.28.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.27.1...v7.28.0) (2024-10-17)

### Features

* Add 'simulatorLogLevel' capability ([#2479](https://github.com/appium/appium-xcuitest-driver/issues/2479)) ([b75f5ec](https://github.com/appium/appium-xcuitest-driver/commit/b75f5ecbc87d2245a330e043b8ca5aac96f8cac1))

## [7.27.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.27.0...v7.27.1) (2024-10-09)

### Bug Fixes

* use lipo -info instead of file for architecture detection ([#2478](https://github.com/appium/appium-xcuitest-driver/issues/2478)) ([993aa3a](https://github.com/appium/appium-xcuitest-driver/commit/993aa3a13fe257a636293b78aa5fa757601dcc09))

## [7.27.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.26.4...v7.27.0) (2024-09-25)

### Features

* build-wda script parameters ([#2475](https://github.com/appium/appium-xcuitest-driver/issues/2475)) ([b8bdfad](https://github.com/appium/appium-xcuitest-driver/commit/b8bdfad3c86efd2d351e99fd53c879d7e6e4b082))

## [7.26.4](https://github.com/appium/appium-xcuitest-driver/compare/v7.26.3...v7.26.4) (2024-09-17)

### Miscellaneous Chores

* **deps-dev:** bump sinon from 18.0.1 to 19.0.2 ([#2469](https://github.com/appium/appium-xcuitest-driver/issues/2469)) ([e737dde](https://github.com/appium/appium-xcuitest-driver/commit/e737dde53880b70536440cec84037ad58ed7f4ab))

## [7.26.3](https://github.com/appium/appium-xcuitest-driver/compare/v7.26.2...v7.26.3) (2024-09-13)

### Bug Fixes

* Strip colors from server logs ([#2466](https://github.com/appium/appium-xcuitest-driver/issues/2466)) ([661f9d3](https://github.com/appium/appium-xcuitest-driver/commit/661f9d3f0fcb0d483de137fc542de141f077b1dc))

## [7.26.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.26.1...v7.26.2) (2024-09-07)

### Miscellaneous Chores

* Set static event realm ([a08ce4f](https://github.com/appium/appium-xcuitest-driver/commit/a08ce4ffb3e73e21fed4d7a28d0004bcaa899bde))

## [7.26.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.26.0...v7.26.1) (2024-09-06)

### Bug Fixes

* safari process management will be done by WDA for real devices ([#2464](https://github.com/appium/appium-xcuitest-driver/issues/2464)) ([18eddc3](https://github.com/appium/appium-xcuitest-driver/commit/18eddc3c48a8361182511a14e46915d6db71cda2))

## [7.26.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.25.0...v7.26.0) (2024-09-05)

### Features

* Publish different log types over BiDi ([#2458](https://github.com/appium/appium-xcuitest-driver/issues/2458)) ([29e9d5e](https://github.com/appium/appium-xcuitest-driver/commit/29e9d5e18c9fe2523dd586d7a32fdce870a81ff0))

## [7.25.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.18...v7.25.0) (2024-08-31)

### Features

* add mobile:simctl to run listed simctl subcommands ([#2461](https://github.com/appium/appium-xcuitest-driver/issues/2461)) ([6aac043](https://github.com/appium/appium-xcuitest-driver/commit/6aac043d6882137e23f44da2ce2773657df3378c))

## [7.24.18](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.17...v7.24.18) (2024-08-26)

### Miscellaneous Chores

* Bump appium-ios-device ([d67869e](https://github.com/appium/appium-xcuitest-driver/commit/d67869ef2243d1a7f0bd4780062e9370ab87d6c8))

## [7.24.17](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.16...v7.24.17) (2024-08-22)

### Miscellaneous Chores

* **deps-dev:** bump webdriverio from 8.40.3 to 9.0.6 ([#2457](https://github.com/appium/appium-xcuitest-driver/issues/2457)) ([4d9ba89](https://github.com/appium/appium-xcuitest-driver/commit/4d9ba8937746b8fa354fc019af3ebfe439e72dee))

## [7.24.16](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.15...v7.24.16) (2024-08-16)

### Miscellaneous Chores

* Improve web view detection error messages ([#2452](https://github.com/appium/appium-xcuitest-driver/issues/2452)) ([efd5fa3](https://github.com/appium/appium-xcuitest-driver/commit/efd5fa3732bd7a5a74091f4b79991d8e18b56f69))

## [7.24.15](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.14...v7.24.15) (2024-08-09)

### Miscellaneous Chores

* Bump WDA ([#2451](https://github.com/appium/appium-xcuitest-driver/issues/2451)) ([c1a6413](https://github.com/appium/appium-xcuitest-driver/commit/c1a64138db210e52a54c49e5a654793a282cfc2c))

## [7.24.14](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.13...v7.24.14) (2024-08-08)

### Miscellaneous Chores

* Bump remote debugger ([#2450](https://github.com/appium/appium-xcuitest-driver/issues/2450)) ([c705a36](https://github.com/appium/appium-xcuitest-driver/commit/c705a3603d206127b805df6b6fb052c47a466e2a))

## [7.24.13](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.12...v7.24.13) (2024-08-08)

### Miscellaneous Chores

* Try to open the initial URL with WDA if no active pages are found ([#2449](https://github.com/appium/appium-xcuitest-driver/issues/2449)) ([08cad3e](https://github.com/appium/appium-xcuitest-driver/commit/08cad3e0d3f2faac6495effb3974ed05a3b7e6cd))

## [7.24.12](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.11...v7.24.12) (2024-08-04)

### Miscellaneous Chores

* Bump remote debugger to v12 ([#2446](https://github.com/appium/appium-xcuitest-driver/issues/2446)) ([093d4d4](https://github.com/appium/appium-xcuitest-driver/commit/093d4d44b438d8f05b4e5efe231c4f304f80f98c))

## [7.24.11](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.10...v7.24.11) (2024-08-02)

### Miscellaneous Chores

* Make remote debugger-related messages more useful ([#2443](https://github.com/appium/appium-xcuitest-driver/issues/2443)) ([65a5ce1](https://github.com/appium/appium-xcuitest-driver/commit/65a5ce11d6e69e7be042e571489f3530647f98a4))

## [7.24.10](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.9...v7.24.10) (2024-08-02)

### Miscellaneous Chores

* Replace fancy-log dependency with appium logger ([#2442](https://github.com/appium/appium-xcuitest-driver/issues/2442)) ([9911b4e](https://github.com/appium/appium-xcuitest-driver/commit/9911b4e315a13ca27d9f1831bec7e2012bfde8b4))

## [7.24.9](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.8...v7.24.9) (2024-08-01)

### Bug Fixes

* Streamline page selection ([#2440](https://github.com/appium/appium-xcuitest-driver/issues/2440)) ([2564829](https://github.com/appium/appium-xcuitest-driver/commit/2564829b05aa4a1d784b65ddb4b3792734320489))

## [7.24.8](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.7...v7.24.8) (2024-08-01)

### Bug Fixes

* Pyidevice ctor invocations with options object ([#2441](https://github.com/appium/appium-xcuitest-driver/issues/2441)) ([7de0d95](https://github.com/appium/appium-xcuitest-driver/commit/7de0d9535c4def80f4a91e81fa1fa948e58a550c))

## [7.24.7](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.6...v7.24.7) (2024-08-01)

### Miscellaneous Chores

* Improve typing on webview commands ([#2439](https://github.com/appium/appium-xcuitest-driver/issues/2439)) ([eab9498](https://github.com/appium/appium-xcuitest-driver/commit/eab9498ca783f6f5001f5dad63445d2fba30349c))

## [7.24.6](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.5...v7.24.6) (2024-07-31)

### Miscellaneous Chores

* **deps-dev:** bump @types/node from 20.14.13 to 22.0.0 ([#2436](https://github.com/appium/appium-xcuitest-driver/issues/2436)) ([6775f45](https://github.com/appium/appium-xcuitest-driver/commit/6775f45792ba4eef61aa688f42e5feb8c1aa1146))

## [7.24.5](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.4...v7.24.5) (2024-07-31)

### Miscellaneous Chores

* Set the default webview connect timeout ([#2438](https://github.com/appium/appium-xcuitest-driver/issues/2438)) ([a63856d](https://github.com/appium/appium-xcuitest-driver/commit/a63856dfe279f187fc8e5a949feed48fb864c40d))

## [7.24.4](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.3...v7.24.4) (2024-07-30)

### Miscellaneous Chores

* Tune webview connection timeouts ([#2437](https://github.com/appium/appium-xcuitest-driver/issues/2437)) ([02af8e2](https://github.com/appium/appium-xcuitest-driver/commit/02af8e2f6a909471f2ebcec6425b51d5dd242d59))

## [7.24.3](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.2...v7.24.3) (2024-07-26)

### Miscellaneous Chores

* Raise more helpful error if a W3C action contains a web element ([#2435](https://github.com/appium/appium-xcuitest-driver/issues/2435)) ([5d80cd8](https://github.com/appium/appium-xcuitest-driver/commit/5d80cd8ce24ab9a6cd8c6a5c5bdc8c23a7af3362))

## [7.24.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.1...v7.24.2) (2024-07-25)

### Miscellaneous Chores

* Make remote debugger typed ([#2433](https://github.com/appium/appium-xcuitest-driver/issues/2433)) ([f643c16](https://github.com/appium/appium-xcuitest-driver/commit/f643c16e5bd22f3f9d6b2f3c7a30d2f24ab4ea8f))

## [7.24.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.24.0...v7.24.1) (2024-07-20)

### Bug Fixes

* no actions in w3c actions case ([#2432](https://github.com/appium/appium-xcuitest-driver/issues/2432)) ([8bd2bd6](https://github.com/appium/appium-xcuitest-driver/commit/8bd2bd6f4e9c60622b20d5c2af7323630ea1b731))

## [7.24.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.23.2...v7.24.0) (2024-07-15)

### Features

* Emit an event on syslog startup ([#2430](https://github.com/appium/appium-xcuitest-driver/issues/2430)) ([157b05e](https://github.com/appium/appium-xcuitest-driver/commit/157b05e134a075e7c3c481725ecd6c39e55c76a7))

## [7.23.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.23.1...v7.23.2) (2024-07-13)

### Bug Fixes

* Filter out other simulators properly for shutdown ([#2429](https://github.com/appium/appium-xcuitest-driver/issues/2429)) ([b7a9ad7](https://github.com/appium/appium-xcuitest-driver/commit/b7a9ad7ea8fe698a0d8cbbf0871e4b59eef91f5d))

## [7.23.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.23.0...v7.23.1) (2024-07-09)

### Miscellaneous Chores

* Remove extra import ([ab07082](https://github.com/appium/appium-xcuitest-driver/commit/ab070823f7287111a085cacf63ab6d77c2d2f031))

## [7.23.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.22.1...v7.23.0) (2024-07-04)

### Features

* Rewrite py-ios-device client and crash reports logger into typescript ([#2423](https://github.com/appium/appium-xcuitest-driver/issues/2423)) ([8d405e8](https://github.com/appium/appium-xcuitest-driver/commit/8d405e8081eb0c4a09217717eb380ab4076a9736))

## [7.22.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.22.0...v7.22.1) (2024-07-03)

### Miscellaneous Chores

* Simplify subprocess output analysis ([#2422](https://github.com/appium/appium-xcuitest-driver/issues/2422)) ([c6b9be8](https://github.com/appium/appium-xcuitest-driver/commit/c6b9be8d5120b8097880bef49f67dc06a8bc548e))

## [7.22.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.21.2...v7.22.0) (2024-07-02)

### Features

* Update console and network log handlers ([#2421](https://github.com/appium/appium-xcuitest-driver/issues/2421)) ([3c72721](https://github.com/appium/appium-xcuitest-driver/commit/3c727219577c51d941d6fab68feda62eaf7bf774))

## [7.21.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.21.1...v7.21.2) (2024-07-01)

### Miscellaneous Chores

* Rewrite logging-related classes to typescript ([#2420](https://github.com/appium/appium-xcuitest-driver/issues/2420)) ([9789575](https://github.com/appium/appium-xcuitest-driver/commit/97895755c41a3a729a8f4fd972c0f900a41f383a))

## [7.21.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.21.0...v7.21.1) (2024-06-30)

### Miscellaneous Chores

* Streamline logging helpers ([#2419](https://github.com/appium/appium-xcuitest-driver/issues/2419)) ([d469237](https://github.com/appium/appium-xcuitest-driver/commit/d469237304d507feb1f59b07fd6a76d51f63fe19))

## [7.21.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.20.2...v7.21.0) (2024-06-27)

### Features

* Add mobile: wrappers for the clipboard API ([#2418](https://github.com/appium/appium-xcuitest-driver/issues/2418)) ([3b41576](https://github.com/appium/appium-xcuitest-driver/commit/3b41576b5cb51f6b4c296e48c799c069cae50f63))

## [7.20.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.20.1...v7.20.2) (2024-06-27)

### Miscellaneous Chores

* Bump chai and chai-as-promised ([#2414](https://github.com/appium/appium-xcuitest-driver/issues/2414)) ([6ba1b5e](https://github.com/appium/appium-xcuitest-driver/commit/6ba1b5e4ba192da6b8d7a0370cd3fa79947c540e))

## [7.20.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.20.0...v7.20.1) (2024-06-26)

### Bug Fixes

* Apply the default exec timeout if not provided explicitly ([#2416](https://github.com/appium/appium-xcuitest-driver/issues/2416)) ([9a793b1](https://github.com/appium/appium-xcuitest-driver/commit/9a793b10a7cbbe317d6b2f85b25162e64a614dee))
* Respect the remote port capability for real devices ([#2417](https://github.com/appium/appium-xcuitest-driver/issues/2417)) ([f2d80da](https://github.com/appium/appium-xcuitest-driver/commit/f2d80da102b8fb3333b97a768bafe463553704cc))

## [7.20.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.19.0...v7.20.0) (2024-06-25)

### Features

* Introduce the `webScreenshotMode` setting ([#2415](https://github.com/appium/appium-xcuitest-driver/issues/2415)) ([c9d9d44](https://github.com/appium/appium-xcuitest-driver/commit/c9d9d4475bcb8d394ae0ba5f3c0a80bea40d1eed))

## [7.19.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.18.0...v7.19.0) (2024-06-25)

### Features

* take viewport screenshot using safari remote debugger ([#2413](https://github.com/appium/appium-xcuitest-driver/issues/2413)) ([4402c29](https://github.com/appium/appium-xcuitest-driver/commit/4402c294333e6084c854d63b4a8387a3b3cbe9ff))

## [7.18.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.17.6...v7.18.0) (2024-06-20)

### Features

* add pageLoadStrategy for Safari/WebView ([#2411](https://github.com/appium/appium-xcuitest-driver/issues/2411)) ([2517bf7](https://github.com/appium/appium-xcuitest-driver/commit/2517bf75d0de0fd00937c4c12c6ca890a49ef218))

## [7.17.6](https://github.com/appium/appium-xcuitest-driver/compare/v7.17.5...v7.17.6) (2024-06-18)

### Bug Fixes

* relax the max of recording limitation to 4200 sec as timeLimit ([#2410](https://github.com/appium/appium-xcuitest-driver/issues/2410)) ([42bc4f9](https://github.com/appium/appium-xcuitest-driver/commit/42bc4f9a373126b0025fa5cec60ee2107d101d53))

## [7.17.5](https://github.com/appium/appium-xcuitest-driver/compare/v7.17.4...v7.17.5) (2024-06-12)

### Bug Fixes

* stream end after write in a file push ([#2409](https://github.com/appium/appium-xcuitest-driver/issues/2409)) ([b2f57b7](https://github.com/appium/appium-xcuitest-driver/commit/b2f57b7fd7cce340969f522203d9375d3b120cdc))

## [7.17.4](https://github.com/appium/appium-xcuitest-driver/compare/v7.17.3...v7.17.4) (2024-06-07)

### Bug Fixes

* Add proper timestamps to server logs ([#2406](https://github.com/appium/appium-xcuitest-driver/issues/2406)) ([28a75ef](https://github.com/appium/appium-xcuitest-driver/commit/28a75efb63e699bf62c73710a6eb8c34abb59d0d))

## [7.17.3](https://github.com/appium/appium-xcuitest-driver/compare/v7.17.2...v7.17.3) (2024-06-05)

### Bug Fixes

* system prompt for Apple ID sign translation for simulators ([#2405](https://github.com/appium/appium-xcuitest-driver/issues/2405)) ([453fe68](https://github.com/appium/appium-xcuitest-driver/commit/453fe680e0da7988821e50d9779bbec2763371fc))

## [7.17.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.17.1...v7.17.2) (2024-06-04)

### Miscellaneous Chores

* **deps-dev:** bump semantic-release from 23.1.1 to 24.0.0 and conventional-changelog-conventionalcommits to 8.0.0 ([#2403](https://github.com/appium/appium-xcuitest-driver/issues/2403)) ([4058b4c](https://github.com/appium/appium-xcuitest-driver/commit/4058b4c33687b11bdc90b3a22acd67330aaab46c))

## [7.17.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.17.0...v7.17.1) (2024-06-03)


### Miscellaneous Chores

* **deps-dev:** bump sinon from 17.0.2 to 18.0.0 ([#2398](https://github.com/appium/appium-xcuitest-driver/issues/2398)) ([e05b63a](https://github.com/appium/appium-xcuitest-driver/commit/e05b63ae68bab6beca808f66d814db6c4e6ba7d8))

## [7.17.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.16.2...v7.17.0) (2024-06-02)


### Features

* Document respectSystemAlerts setting ([#2402](https://github.com/appium/appium-xcuitest-driver/issues/2402)) ([acf37dd](https://github.com/appium/appium-xcuitest-driver/commit/acf37dd4ee20745908ff87ea48d83d4e143d63d3))

## [7.16.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.16.1...v7.16.2) (2024-05-22)


### Miscellaneous Chores

* add note about .app naming finding for future reference ([#2400](https://github.com/appium/appium-xcuitest-driver/issues/2400)) ([aab83d5](https://github.com/appium/appium-xcuitest-driver/commit/aab83d5924b4df606bd50b395dde1898d097f7f7))

## [7.16.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.16.0...v7.16.1) (2024-05-21)


### Bug Fixes

* Update plist detection pattern ([385ed99](https://github.com/appium/appium-xcuitest-driver/commit/385ed99afec1795940d8aba408ac448d73585a59))

## [7.16.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.15.3...v7.16.0) (2024-05-21)


### Features

* add maxTypingFrequency to settings api ([#2399](https://github.com/appium/appium-xcuitest-driver/issues/2399)) ([c1810c3](https://github.com/appium/appium-xcuitest-driver/commit/c1810c362ecc46e98b0cd01a196211017457c2ac))

## [7.15.3](https://github.com/appium/appium-xcuitest-driver/compare/v7.15.2...v7.15.3) (2024-05-16)


### Miscellaneous Chores

* Update dev dependencies ([b6f02b9](https://github.com/appium/appium-xcuitest-driver/commit/b6f02b9caf3b7fd2bb89b5309234281368207cd5))

## [7.15.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.15.1...v7.15.2) (2024-05-07)


### Bug Fixes

* Properly cache manifests for .ipa bundles containing multiple apps ([#2394](https://github.com/appium/appium-xcuitest-driver/issues/2394)) ([ffd3bbb](https://github.com/appium/appium-xcuitest-driver/commit/ffd3bbbe8ef3e9ef80c2b9af327d88be6e0f367a))

## [7.15.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.15.0...v7.15.1) (2024-04-27)


### Bug Fixes

* Update caching logic for extracted app bundles ([#2389](https://github.com/appium/appium-xcuitest-driver/issues/2389)) ([0424193](https://github.com/appium/appium-xcuitest-driver/commit/04241937414ee6fa986be8719fbb690046b63a56))

## [7.15.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.14.0...v7.15.0) (2024-04-26)


### Features

* Avoid unzipping of real device .ipa bundles ([#2388](https://github.com/appium/appium-xcuitest-driver/issues/2388)) ([520168a](https://github.com/appium/appium-xcuitest-driver/commit/520168aa7d8c230a44da136b9e8d21971c4ef8f8))

## [7.14.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.13.0...v7.14.0) (2024-04-23)


### Features

* Perform bundles extraction in stream ([#2387](https://github.com/appium/appium-xcuitest-driver/issues/2387)) ([b04cebd](https://github.com/appium/appium-xcuitest-driver/commit/b04cebd99418b0e6d55d3c1813700779248e6541))

## [7.13.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.12.0...v7.13.0) (2024-04-18)


### Features

* add sendKeyStrategy for React to type input one by one in Web context ([#2386](https://github.com/appium/appium-xcuitest-driver/issues/2386)) ([50749cf](https://github.com/appium/appium-xcuitest-driver/commit/50749cfc11e39c34c8df9138a06539f865347082))

## [7.12.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.11.4...v7.12.0) (2024-04-17)


### Features

* update Atoms in remtoe debugger to selenium 4.19.0 basis ([#2385](https://github.com/appium/appium-xcuitest-driver/issues/2385)) ([0c45843](https://github.com/appium/appium-xcuitest-driver/commit/0c458437240ea2ab367e2aa2915aa053fb01481b))

## [7.11.4](https://github.com/appium/appium-xcuitest-driver/compare/v7.11.3...v7.11.4) (2024-04-15)


### Miscellaneous Chores

* deprecated useSimpleBuildTest, waitForQuiescence and calendarAccessAuthorized ([#2383](https://github.com/appium/appium-xcuitest-driver/issues/2383)) ([090c615](https://github.com/appium/appium-xcuitest-driver/commit/090c615682bb82745174865982eb0bcc5e5b2922))

## [7.11.3](https://github.com/appium/appium-xcuitest-driver/compare/v7.11.2...v7.11.3) (2024-04-12)


### Bug Fixes

* Tune appPushTimeout capability ([#2384](https://github.com/appium/appium-xcuitest-driver/issues/2384)) ([0c42d55](https://github.com/appium/appium-xcuitest-driver/commit/0c42d557d459f8ec25277dc1c2672a0045b16329))

## [7.11.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.11.1...v7.11.2) (2024-04-09)


### Miscellaneous Chores

* Remove extra imports ([2104b7a](https://github.com/appium/appium-xcuitest-driver/commit/2104b7a9a58630ab7bf058f5db7990cc275cf588))

## [7.11.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.11.0...v7.11.1) (2024-04-08)


### Bug Fixes

* update real device check condition ([9255e7c](https://github.com/appium/appium-xcuitest-driver/commit/9255e7c932d20967b0c7860df14015c5b4a63d15))

## [7.11.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.10.0...v7.11.0) (2024-04-08)


### Features

* export doctor used in xcuitest driver ([#2381](https://github.com/appium/appium-xcuitest-driver/issues/2381)) ([e8fd02e](https://github.com/appium/appium-xcuitest-driver/commit/e8fd02e00dc6be595d2bef253c00ab75783504e5))

## [7.10.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.9.3...v7.10.0) (2024-04-08)


### Features

* Add `appTimeZone` capability ([#2379](https://github.com/appium/appium-xcuitest-driver/issues/2379)) ([a06931f](https://github.com/appium/appium-xcuitest-driver/commit/a06931fca03ef4f3de0ea65eb7814660dcb08117))

## [7.9.3](https://github.com/appium/appium-xcuitest-driver/compare/v7.9.2...v7.9.3) (2024-04-07)


### Bug Fixes

* Added platformVersion to capabilities ([#2378](https://github.com/appium/appium-xcuitest-driver/issues/2378)) ([e75cd2c](https://github.com/appium/appium-xcuitest-driver/commit/e75cd2c127b0b2d1206cbd4d7b22923ee553798c))
* Update various type declarations ([#2380](https://github.com/appium/appium-xcuitest-driver/issues/2380)) ([1e18b2f](https://github.com/appium/appium-xcuitest-driver/commit/1e18b2f7c859f915aa353716add65d0a404c0fa7))

## [7.9.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.9.1...v7.9.2) (2024-04-07)


### Bug Fixes

* Properly match simulator udid if webDriverAgentUrl is provided ([#2377](https://github.com/appium/appium-xcuitest-driver/issues/2377)) ([bc71415](https://github.com/appium/appium-xcuitest-driver/commit/bc7141569f6148a8de77dc1989c2400a10a6c3f8))

## [7.9.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.9.0...v7.9.1) (2024-03-31)


### Miscellaneous Chores

* bump wda ([a777b93](https://github.com/appium/appium-xcuitest-driver/commit/a777b93a5953dfd59e54f40817d198307f72289f))

## [7.9.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.8.2...v7.9.0) (2024-03-31)


### Features

* Enable Safari settings modification for real devices ([#2373](https://github.com/appium/appium-xcuitest-driver/issues/2373)) ([2bf1dc5](https://github.com/appium/appium-xcuitest-driver/commit/2bf1dc56d80ec712c6a7691ca24192df6fc6f4eb))

## [7.8.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.8.1...v7.8.2) (2024-03-29)


### Miscellaneous Chores

* bump WDA ([1c3d68b](https://github.com/appium/appium-xcuitest-driver/commit/1c3d68b13a60513b4da9179351831ab05ca14bf3))

## [7.8.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.8.0...v7.8.1) (2024-03-29)


### Miscellaneous Chores

* left a comment for future work ([#2372](https://github.com/appium/appium-xcuitest-driver/issues/2372)) ([3f13c62](https://github.com/appium/appium-xcuitest-driver/commit/3f13c624ab2c89c8ff89dd07b2fdcaf33f5d5265))

## [7.8.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.7.2...v7.8.0) (2024-03-28)


### Features

* Add 'appLaunchStateTimeoutSec' capability support ([#2371](https://github.com/appium/appium-xcuitest-driver/issues/2371)) ([c0514e4](https://github.com/appium/appium-xcuitest-driver/commit/c0514e4050c7ab19d3e83a0026a81fa83e8218c4))

## [7.7.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.7.1...v7.7.2) (2024-03-28)


### Bug Fixes

* Address various typing errors ([#2369](https://github.com/appium/appium-xcuitest-driver/issues/2369)) ([e5d7001](https://github.com/appium/appium-xcuitest-driver/commit/e5d70010bd777c8e5fc94da412e0d2cc902c64de))

## [7.7.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.7.0...v7.7.1) (2024-03-28)


### Miscellaneous Chores

* tune error handling with usePreinstalledWDA ([#2368](https://github.com/appium/appium-xcuitest-driver/issues/2368)) ([1a5aafd](https://github.com/appium/appium-xcuitest-driver/commit/1a5aafd738352e4b7e73c7006668f37ac9f6812e))

## [7.7.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.6.1...v7.7.0) (2024-03-27)


### Features

* Add the `device` property to the driver ([#2364](https://github.com/appium/appium-xcuitest-driver/issues/2364)) ([92148aa](https://github.com/appium/appium-xcuitest-driver/commit/92148aae6088297162a884516ed8a471b3eeb113))

## [7.6.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.6.0...v7.6.1) (2024-03-27)


### Bug Fixes

* set bundle id at the end to make arguments work properly in Devicectl[#launch](https://github.com/appium/appium-xcuitest-driver/issues/launch)App ([#2366](https://github.com/appium/appium-xcuitest-driver/issues/2366)) ([1d3fd28](https://github.com/appium/appium-xcuitest-driver/commit/1d3fd28e57bb72db421dde11eda2d9a10809d06e))

## [7.6.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.5.5...v7.6.0) (2024-03-26)


### Features

* add updatedWDABundleIdSuffix for usePreinstalledWDA usage ([#2358](https://github.com/appium/appium-xcuitest-driver/issues/2358)) ([b8291cb](https://github.com/appium/appium-xcuitest-driver/commit/b8291cbbc6d0a843427906cb810e9adff29c18a1))

## [7.5.5](https://github.com/appium/appium-xcuitest-driver/compare/v7.5.4...v7.5.5) (2024-03-26)


### Miscellaneous Chores

* add launchApp via devicectl ([#2354](https://github.com/appium/appium-xcuitest-driver/issues/2354)) ([3907455](https://github.com/appium/appium-xcuitest-driver/commit/3907455d84519709e07d683ac26ef2047ede9d59))

## [7.5.4](https://github.com/appium/appium-xcuitest-driver/compare/v7.5.3...v7.5.4) (2024-03-25)


### Bug Fixes

* uncaughtException: maxObjectCount exceeded in listApplications ([#2355](https://github.com/appium/appium-xcuitest-driver/issues/2355)) ([6bfc5c5](https://github.com/appium/appium-xcuitest-driver/commit/6bfc5c5e501f14f770d17d3cbea04850451ed2d2))

## [7.5.3](https://github.com/appium/appium-xcuitest-driver/compare/v7.5.2...v7.5.3) (2024-03-25)


### Bug Fixes

* build error ([#2356](https://github.com/appium/appium-xcuitest-driver/issues/2356)) ([5c5ebc3](https://github.com/appium/appium-xcuitest-driver/commit/5c5ebc3fe1f22568b61ba7bc96dcdedae3bcb247))
* typo by [#2351](https://github.com/appium/appium-xcuitest-driver/issues/2351) ([63589a1](https://github.com/appium/appium-xcuitest-driver/commit/63589a1c8f6f83356347a4d085e619f70ee79283))


### Miscellaneous Chores

* include devicectl in IOSDeploy object ([#2352](https://github.com/appium/appium-xcuitest-driver/issues/2352)) ([6c5abd1](https://github.com/appium/appium-xcuitest-driver/commit/6c5abd1eb35cc5089c8a8cb112b6fc708548c1a4))

## [7.5.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.5.1...v7.5.2) (2024-03-24)


### Miscellaneous Chores

* rename IosDeploy obhect to RealDevice to make the object meaning actual usage ([#2353](https://github.com/appium/appium-xcuitest-driver/issues/2353)) ([b3b7349](https://github.com/appium/appium-xcuitest-driver/commit/b3b734913bc5ef824b6cde58bfe0b389bb87abac))

## [7.5.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.5.0...v7.5.1) (2024-03-24)


### Miscellaneous Chores

* skip connected device check if the caps had webDriverAgentUrl ([#2351](https://github.com/appium/appium-xcuitest-driver/issues/2351)) ([407ad58](https://github.com/appium/appium-xcuitest-driver/commit/407ad58e8df03b700152f9c9bf41546e65afac4f))

## [7.5.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.4.2...v7.5.0) (2024-03-24)


### Features

* add appium:usePreinstalledWDA for real iOS 17 devices ([#2350](https://github.com/appium/appium-xcuitest-driver/issues/2350)) ([ec5a1f7](https://github.com/appium/appium-xcuitest-driver/commit/ec5a1f73f06763da47c06386aac729e8ee75d990))

## [7.4.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.4.1...v7.4.2) (2024-03-23)


### Miscellaneous Chores

* do not print unrelated logs ([#2346](https://github.com/appium/appium-xcuitest-driver/issues/2346)) ([ee5d83e](https://github.com/appium/appium-xcuitest-driver/commit/ee5d83ec73b9113d4876880dea36d107ecadeaaa))

## [7.4.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.4.0...v7.4.1) (2024-03-22)


### Bug Fixes

* Pass valid arg into terminateApp ([#2348](https://github.com/appium/appium-xcuitest-driver/issues/2348)) ([e2e6a6f](https://github.com/appium/appium-xcuitest-driver/commit/e2e6a6faf4f86d9fab63e026c2820fb839a0e98c))

## [7.4.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.3.1...v7.4.0) (2024-03-22)


### Features

* Support usePreinstalledWDA on simulators ([#2345](https://github.com/appium/appium-xcuitest-driver/issues/2345)) ([2eb4c81](https://github.com/appium/appium-xcuitest-driver/commit/2eb4c81a4de670d3bf6d9fc062ec827b05519f25))

## [7.3.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.3.0...v7.3.1) (2024-03-14)


### Bug Fixes

* respect defaultActiveApplication settings in activeApplication selection ([#2343](https://github.com/appium/appium-xcuitest-driver/issues/2343)) ([1837991](https://github.com/appium/appium-xcuitest-driver/commit/18379912c542ff619304476680005d4656f94de4))

## [7.3.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.2.0...v7.3.0) (2024-03-08)


### Features

* Video recording using native XCTest backend ([#2339](https://github.com/appium/appium-xcuitest-driver/issues/2339)) ([e17e88b](https://github.com/appium/appium-xcuitest-driver/commit/e17e88bb471500a1251a380ace91ee351f9e152b))


### Bug Fixes

* Update the default timeout for the recent webview detection ([#2337](https://github.com/appium/appium-xcuitest-driver/issues/2337)) ([8d7750c](https://github.com/appium/appium-xcuitest-driver/commit/8d7750c63348d116990cd856ecd9e6853421a42f))


### Miscellaneous Chores

* bump typescript ([40d5f5d](https://github.com/appium/appium-xcuitest-driver/commit/40d5f5dc5e1593d072750ece22e251768259b0c7))

## [7.2.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.1.2...v7.2.0) (2024-02-28)


### Features

* add webviewAtomWaitTimeout to control timeout for the atom execution ([#2335](https://github.com/appium/appium-xcuitest-driver/issues/2335)) ([255671d](https://github.com/appium/appium-xcuitest-driver/commit/255671d6328cdbc96abd46785865a758474ac100))

## [7.1.2](https://github.com/appium/appium-xcuitest-driver/compare/v7.1.1...v7.1.2) (2024-02-23)


### Bug Fixes

* Properly handle WDA session startup errors ([#2331](https://github.com/appium/appium-xcuitest-driver/issues/2331)) ([f4ca5ee](https://github.com/appium/appium-xcuitest-driver/commit/f4ca5ee2c542479e6acc990f551c4740d3ddd197))

## [7.1.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.1.0...v7.1.1) (2024-02-23)


### Miscellaneous Chores

* Bump WDA ([3374b7b](https://github.com/appium/appium-xcuitest-driver/commit/3374b7b779ed956c86344b5ed9f8c92beb142de0))

## [7.1.0](https://github.com/appium/appium-xcuitest-driver/compare/v7.0.1...v7.1.0) (2024-02-18)


### Features

* return the result of getGeoLocation if available for ios 17+ ([#2329](https://github.com/appium/appium-xcuitest-driver/issues/2329)) ([fc0ba2c](https://github.com/appium/appium-xcuitest-driver/commit/fc0ba2c285cccef6f4f229dc5d27b5b2d0d78569))

## [7.0.1](https://github.com/appium/appium-xcuitest-driver/compare/v7.0.0...v7.0.1) (2024-02-14)


### Miscellaneous Chores

* Bump remote debugger version ([#2328](https://github.com/appium/appium-xcuitest-driver/issues/2328)) ([d12132b](https://github.com/appium/appium-xcuitest-driver/commit/d12132b4c2d0c770e681bdfd339339c23c6f3933))

## [7.0.0](https://github.com/appium/appium-xcuitest-driver/compare/v6.2.0...v7.0.0) (2024-02-12)


### ⚠ BREAKING CHANGES

* Removed the following obsolete APIs:
- performTouch
- performMultiAction

### Features

* Remove obsolete MJSONWP touch actions ([#2325](https://github.com/appium/appium-xcuitest-driver/issues/2325)) ([0e7267a](https://github.com/appium/appium-xcuitest-driver/commit/0e7267a971bc7ff1af3840ee1ea97de1f2773be0))

## [6.2.0](https://github.com/appium/appium-xcuitest-driver/compare/v6.1.0...v6.2.0) (2024-02-11)


### Features

* Add the `appium:initialDeeplinkUrl` capabilility ([#2324](https://github.com/appium/appium-xcuitest-driver/issues/2324)) ([167c268](https://github.com/appium/appium-xcuitest-driver/commit/167c2688a21eab0d340d685c13db6681e0e0a265))

## [6.1.0](https://github.com/appium/appium-xcuitest-driver/compare/v6.0.3...v6.1.0) (2024-02-09)


### Features

* add checkVersion option for mobile:installApp ([#2322](https://github.com/appium/appium-xcuitest-driver/issues/2322)) ([dcc96a9](https://github.com/appium/appium-xcuitest-driver/commit/dcc96a9a4cbc3a650c77dcabdf9a3d48b29f124d))

## [6.0.3](https://github.com/appium/appium-xcuitest-driver/compare/v6.0.2...v6.0.3) (2024-02-08)


### Miscellaneous Chores

* add a guide for the simulated location ([#2321](https://github.com/appium/appium-xcuitest-driver/issues/2321)) ([fe6d965](https://github.com/appium/appium-xcuitest-driver/commit/fe6d96569eebf284c2ab7ecdc8b6e7f9e279ce7f))

## [6.0.2](https://github.com/appium/appium-xcuitest-driver/compare/v6.0.1...v6.0.2) (2024-02-06)


### Miscellaneous Chores

* Add validation of Simulator binary architecture ([#2320](https://github.com/appium/appium-xcuitest-driver/issues/2320)) ([967f712](https://github.com/appium/appium-xcuitest-driver/commit/967f71241787728d9b192e3e02d4a568d4dc701f))

## [6.0.1](https://github.com/appium/appium-xcuitest-driver/compare/v6.0.0...v6.0.1) (2024-02-02)


### Miscellaneous Chores

* Paralelize log collection startup ([#2318](https://github.com/appium/appium-xcuitest-driver/issues/2318)) ([ad452c9](https://github.com/appium/appium-xcuitest-driver/commit/ad452c9da9f39671c8e36adbcedbf5fcc92d68a8))

## [6.0.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.16.1...v6.0.0) (2024-02-01)


### ⚠ BREAKING CHANGES

* Removed the unused getCoordinates API
* Changed arguments order for various gesture extensions
* Bumped WDA to ^6.0.0, which includes fixes for the active application detection
    * This change might require switching the active application to `com.apple.springboard` in order to interact with system dialogs, such as permission dialogs, while the current active application is not the springboard. Using `mobile:alert` or `acceptAlertButtonSelector`/`dismissAlertButtonSelector` also should help. See also [appium#19716](https://github.com/appium/appium/issues/19716).

### Features

* Unify gesture extensions ([#2317](https://github.com/appium/appium-xcuitest-driver/issues/2317)) ([11c9b3c](https://github.com/appium/appium-xcuitest-driver/commit/11c9b3c0320d795c36ea6b2ee9364ef85fad297c))

## [5.16.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.16.0...v5.16.1) (2024-02-01)


### Reverts

* Revert "feat: Unify gesture extensions (#2313)" ([00161d8](https://github.com/appium/appium-xcuitest-driver/commit/00161d8c71a25cdc9c34707b467f0737c2fcc2d3)), closes [#2313](https://github.com/appium/appium-xcuitest-driver/issues/2313)

## [5.16.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.15.1...v5.16.0) (2024-02-01)


### Features

* Unify gesture extensions ([#2313](https://github.com/appium/appium-xcuitest-driver/issues/2313)) ([50f38c1](https://github.com/appium/appium-xcuitest-driver/commit/50f38c156d1dca5036f4d3ed7951d7e5d463c6fd))

## [5.15.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.15.0...v5.15.1) (2024-01-31)


### Bug Fixes

* revert active application detection fix added in 5.14.1 ([#2314](https://github.com/appium/appium-xcuitest-driver/issues/2314)) ([b46243e](https://github.com/appium/appium-xcuitest-driver/commit/b46243e6276ce65bb25f6bd7650a25b935df955f))
    * Please see [appium#19716](https://github.com/appium/appium/issues/19716) for more details. The change addressed in the issue will come in a future release.

### Code Refactoring

* Unify devicectl usage ([#2310](https://github.com/appium/appium-xcuitest-driver/issues/2310)) ([b788c76](https://github.com/appium/appium-xcuitest-driver/commit/b788c76ef0f020adf5012d729013e7ed69508307))

## [5.15.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.14.2...v5.15.0) (2024-01-29)


### Features

* Add 'mobile: sendMemoryWarning' extension ([#2308](https://github.com/appium/appium-xcuitest-driver/issues/2308)) ([014952b](https://github.com/appium/appium-xcuitest-driver/commit/014952b6f98a35518d30d2e25f4809d85609b055))

## [5.14.2](https://github.com/appium/appium-xcuitest-driver/compare/v5.14.1...v5.14.2) (2024-01-27)


### Miscellaneous Chores

* Remove husky and commitlint ([#2307](https://github.com/appium/appium-xcuitest-driver/issues/2307)) ([8142e96](https://github.com/appium/appium-xcuitest-driver/commit/8142e96376630b3f5811532216a686eacc66495e))

## [5.14.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.14.0...v5.14.1) (2024-01-24)

### Miscellaneous Chores

* **deps-dev:** bump semantic-release from 22.0.12 to 23.0.0 ([#2300](https://github.com/appium/appium-xcuitest-driver/issues/2300)) ([f08270b](https://github.com/appium/appium-xcuitest-driver/commit/f08270b26cbd7ab840c5d6d7a29e24c556aca653))
* Sort files to push by size ([#2301](https://github.com/appium/appium-xcuitest-driver/issues/2301)) ([b23a972](https://github.com/appium/appium-xcuitest-driver/commit/b23a9724ad68dff4a796d9345696b2a5a888b136))

## [5.14.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.13.2...v5.14.0) (2024-01-13)


### Features

* use Menu button for tvOS in driver.back ([#2299](https://github.com/appium/appium-xcuitest-driver/issues/2299)) ([b649a96](https://github.com/appium/appium-xcuitest-driver/commit/b649a96e2fe60cba2c229f32155ed6bcfc21afd3))

## [5.13.2](https://github.com/appium/appium-xcuitest-driver/compare/v5.13.1...v5.13.2) (2024-01-09)


### Bug Fixes

* **docs:** adjust docs for @appium/docutils 1.0.2 ([#2293](https://github.com/appium/appium-xcuitest-driver/issues/2293)) ([e3312b4](https://github.com/appium/appium-xcuitest-driver/commit/e3312b404540f0bcfb324816d003a7c513720f7d))

## [5.13.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.13.0...v5.13.1) (2024-01-07)


### Bug Fixes

* Import the proper support module ([#2294](https://github.com/appium/appium-xcuitest-driver/issues/2294)) ([b74ca4a](https://github.com/appium/appium-xcuitest-driver/commit/b74ca4aa05a898599b994376cc755425b5307a0b))

## [5.13.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.12.2...v5.13.0) (2024-01-05)


### Features

* Add doctor checks ([#2292](https://github.com/appium/appium-xcuitest-driver/issues/2292)) ([804e50a](https://github.com/appium/appium-xcuitest-driver/commit/804e50aa94184061973f488f0cec8c059080d834))

## [5.12.2](https://github.com/appium/appium-xcuitest-driver/compare/v5.12.1...v5.12.2) (2023-12-14)


### Bug Fixes

* (dummy) ([88e1f8a](https://github.com/appium/appium-xcuitest-driver/commit/88e1f8aae8a8c13c674c1bef5f9c6d91ed588b13))


### Miscellaneous Chores

* use appearance for getAppearance ([#2285](https://github.com/appium/appium-xcuitest-driver/issues/2285)) ([1108e8c](https://github.com/appium/appium-xcuitest-driver/commit/1108e8cf3e86dab4f345429a30d5b466e43dd39b))

## [5.12.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.12.0...v5.12.1) (2023-12-07)


### Bug Fixes

* include a fix of setAppearance in iOS 17+ ([#2284](https://github.com/appium/appium-xcuitest-driver/issues/2284)) ([f89d4cc](https://github.com/appium/appium-xcuitest-driver/commit/f89d4ccc0c3e78bb53b0483ef367566222bc194a))

## [5.12.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.11.8...v5.12.0) (2023-12-06)


### Features

* use skipSyncUiDialogTranslation option for localization on simulators ([#2276](https://github.com/appium/appium-xcuitest-driver/issues/2276)) ([3f4898a](https://github.com/appium/appium-xcuitest-driver/commit/3f4898a13b22dd9ab5514ab20db9ecd274931018)), closes [/github.com/appium/appium/issues/19440#issuecomment-1823461012](https://github.com/appium//github.com/appium/appium/issues/19440/issues/issuecomment-1823461012)

## [5.11.8](https://github.com/appium/appium-xcuitest-driver/compare/v5.11.7...v5.11.8) (2023-12-04)


### Bug Fixes

* keep backward compatibility for the value of set location command via xcrun simctl privacy ([#2282](https://github.com/appium/appium-xcuitest-driver/issues/2282)) ([a1a7c48](https://github.com/appium/appium-xcuitest-driver/commit/a1a7c487b122708e218e9609e54162743bfeddb1))

## [5.11.7](https://github.com/appium/appium-xcuitest-driver/compare/v5.11.6...v5.11.7) (2023-12-02)


### Bug Fixes

* tune a bit more ([#2281](https://github.com/appium/appium-xcuitest-driver/issues/2281)) ([23d2f68](https://github.com/appium/appium-xcuitest-driver/commit/23d2f6803d77c08a7419c2feb291d50edc2c05ac))

## [5.11.6](https://github.com/appium/appium-xcuitest-driver/compare/v5.11.5...v5.11.6) (2023-12-02)


### Bug Fixes

* npm install dev after creating npm shrinkwrap ([148d3cd](https://github.com/appium/appium-xcuitest-driver/commit/148d3cd9bfa12c3caa158dd4083dd5e571261fe6))

## [5.11.5](https://github.com/appium/appium-xcuitest-driver/compare/v5.11.4...v5.11.5) (2023-12-02)


### Bug Fixes

* tune to minimize release module ([#2280](https://github.com/appium/appium-xcuitest-driver/issues/2280)) ([c82bafc](https://github.com/appium/appium-xcuitest-driver/commit/c82bafc5ce7e630f82dff49d314a6de7233b867d))

## [5.11.4](https://github.com/appium/appium-xcuitest-driver/compare/v5.11.3...v5.11.4) (2023-12-02)


### Bug Fixes

* tune publish.js.yml further ([077935d](https://github.com/appium/appium-xcuitest-driver/commit/077935db0d6795761d9b6498d4a0c346f0400ec1))
* tune publish.js.yml further again ([7fbada9](https://github.com/appium/appium-xcuitest-driver/commit/7fbada98971976183200c040945b3ae110ea948a))

## [5.11.3](https://github.com/appium/appium-xcuitest-driver/compare/v5.11.2...v5.11.3) (2023-12-02)


### Bug Fixes

* tune publish.js.yml further ([9108c75](https://github.com/appium/appium-xcuitest-driver/commit/9108c757c7b06b986bb75646b9af90d43ad8973f))

## [5.11.2](https://github.com/appium/appium-xcuitest-driver/compare/v5.11.1...v5.11.2) (2023-12-02)


### Bug Fixes

* tune release script ([#2278](https://github.com/appium/appium-xcuitest-driver/issues/2278)) ([b94cb19](https://github.com/appium/appium-xcuitest-driver/commit/b94cb19d5184e84cb572f07533eec7ddca6cad67))

## [5.11.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.11.0...v5.11.1) (2023-12-02)


### Bug Fixes

* tune shrinkwrap for a release ([#2277](https://github.com/appium/appium-xcuitest-driver/issues/2277)) ([33726f2](https://github.com/appium/appium-xcuitest-driver/commit/33726f20905c589ecf56faeae030eda8ce33e78f))

## [5.11.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.10.2...v5.11.0) (2023-11-26)


### Features

* set location permission via xcrun simctl privacy ([#2275](https://github.com/appium/appium-xcuitest-driver/issues/2275)) ([3f6979b](https://github.com/appium/appium-xcuitest-driver/commit/3f6979b6500f0a5b048b6fe642f9cbebb78e32ca))

## [5.10.2](https://github.com/appium/appium-xcuitest-driver/compare/v5.10.1...v5.10.2) (2023-11-24)


### Reverts

* Revert "fix: tune shrinkwrap" ([46fa202](https://github.com/appium/appium-xcuitest-driver/commit/46fa202af757a92a57c8eb913183b0329343660c))

## [5.10.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.10.0...v5.10.1) (2023-11-24)


### Bug Fixes

* tune shrinkwrap ([aca035a](https://github.com/appium/appium-xcuitest-driver/commit/aca035afaf3aac5402ddd2c82c9f9a915e49450d))

## [5.10.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.9.1...v5.10.0) (2023-11-24)


### Features

* elementAttributes added in [#2274](https://github.com/appium/appium-xcuitest-driver/issues/2274) ([1f46269](https://github.com/appium/appium-xcuitest-driver/commit/1f462697f7d5cab213f87244f7ddc00cfd2e2e98))


### Miscellaneous Chores

* Bump WDA version to 5.15.2 ([#2274](https://github.com/appium/appium-xcuitest-driver/issues/2274)) ([f6ff336](https://github.com/appium/appium-xcuitest-driver/commit/f6ff336e9093a8acffa03e6cbd8af94eacb1c0f3))
* **deps-dev:** bump @commitlint/cli from 18.4.2 to 18.4.3 ([#2265](https://github.com/appium/appium-xcuitest-driver/issues/2265)) ([87f15da](https://github.com/appium/appium-xcuitest-driver/commit/87f15da2a8e2eb0a69bd63c0f82c5f36566a8801))
* **deps-dev:** bump @types/chai from 4.3.10 to 4.3.11 ([02c96bb](https://github.com/appium/appium-xcuitest-driver/commit/02c96bb2182217fd12d93fc64168fdeae617ae2e))
* **deps-dev:** bump @types/mocha from 10.0.4 to 10.0.5 ([8eb4326](https://github.com/appium/appium-xcuitest-driver/commit/8eb432604f0350d866ab4d46acf09ff7b251ba52))
* **deps-dev:** bump @types/node from 20.9.2 to 20.9.3 ([3f75af0](https://github.com/appium/appium-xcuitest-driver/commit/3f75af09f7728d830070e0b7c97111cb78e6cfd6))
* **deps-dev:** bump @types/node from 20.9.3 to 20.9.4 ([#2264](https://github.com/appium/appium-xcuitest-driver/issues/2264)) ([ab03aa5](https://github.com/appium/appium-xcuitest-driver/commit/ab03aa5bef36ce0d263168383eacd77329988747))
* **deps-dev:** bump @typescript-eslint/eslint-plugin ([efee840](https://github.com/appium/appium-xcuitest-driver/commit/efee8409a420c156838aaff0e9c23d7d647e49a3))
* **deps-dev:** bump type-fest from 4.8.1 to 4.8.2 ([9a2cfca](https://github.com/appium/appium-xcuitest-driver/commit/9a2cfca66dfc6854b850c86dde3e816210634e61))
* **deps-dev:** bump webdriverio from 8.23.1 to 8.24.0 ([cd13fb9](https://github.com/appium/appium-xcuitest-driver/commit/cd13fb9aae1045916b13445b379e8b2e3ed4d54b))
* **deps:** bump appium-ios-device from 2.7.9 to 2.7.10 ([#2250](https://github.com/appium/appium-xcuitest-driver/issues/2250)) ([62a7baf](https://github.com/appium/appium-xcuitest-driver/commit/62a7baf30a7960d9f98bd6dba2155fd9382ffce6))
* **deps:** bump appium-webdriveragent from 5.14.0 to 5.15.2 ([64b14c9](https://github.com/appium/appium-xcuitest-driver/commit/64b14c93fcf07725e3c1e788eb708b5ab860a5a5))
* **deps:** bump css-selector-parser from 3.0.0 to 3.0.2 ([#2260](https://github.com/appium/appium-xcuitest-driver/issues/2260)) ([fcfb181](https://github.com/appium/appium-xcuitest-driver/commit/fcfb1818147c6b39869117125ab9c5627a954c5d))
* **deps:** bump lru-cache from 10.0.2 to 10.0.3 ([#2249](https://github.com/appium/appium-xcuitest-driver/issues/2249)) ([107a401](https://github.com/appium/appium-xcuitest-driver/commit/107a401d329d949e8519d6faabb8e7612a18d777))
* **deps:** bump teen_process and @types/teen_process ([#2258](https://github.com/appium/appium-xcuitest-driver/issues/2258)) ([da34751](https://github.com/appium/appium-xcuitest-driver/commit/da347517e4e749491d5b834565daba440a10ce6a))
* Disable package-lock creation ([#2273](https://github.com/appium/appium-xcuitest-driver/issues/2273)) ([c0b5cf8](https://github.com/appium/appium-xcuitest-driver/commit/c0b5cf84d6079b5fcf6f76869d7844a79f7feda3))
* lock typescript version ([5077e23](https://github.com/appium/appium-xcuitest-driver/commit/5077e232bc2369b7368057a33d7eb3a3a5fbb764))

## [5.9.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.9.0...v5.9.1) (2023-11-21)


### Bug Fixes

* assign deeply cloned processArguments for starting a WDA session ([#2245](https://github.com/appium/appium-xcuitest-driver/issues/2245)) ([2e6f273](https://github.com/appium/appium-xcuitest-driver/commit/2e6f273e8533cf02284079d1fea919a7062fd2cc))

## [5.9.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.8.2...v5.9.0) (2023-11-19)


### Features

* add * in additionalWebviewBundleIds cap ([#2244](https://github.com/appium/appium-xcuitest-driver/issues/2244)) ([74874f5](https://github.com/appium/appium-xcuitest-driver/commit/74874f536975337a6608633de8aa9435a0edd52a))

## [5.8.2](https://github.com/appium/appium-xcuitest-driver/compare/v5.8.1...v5.8.2) (2023-11-08)


### Bug Fixes

* to push a new release with updated npm-shrinkwrap ([b0dfc39](https://github.com/appium/appium-xcuitest-driver/commit/b0dfc393316b6573a7b15855d97d16f29570eb9b))

## [5.8.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.8.0...v5.8.1) (2023-11-01)


### Bug Fixes

* Sync package-lock ([09be06f](https://github.com/appium/appium-xcuitest-driver/commit/09be06f7c13f3aaba5a4f1b8552e0dbb356ec200))

## [5.8.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.7.0...v5.8.0) (2023-10-30)


### Features

* Add 'mobile: keys' extension ([#2156](https://github.com/appium/appium-xcuitest-driver/issues/2156)) ([db39d66](https://github.com/appium/appium-xcuitest-driver/commit/db39d66e6605d22d7b8d1150a9612b74cb962f79))

## [5.7.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.6.0...v5.7.0) (2023-10-13)


### Features

* Add 'mobile: calibrateWebToRealCoordinatesTranslation' API ([#2071](https://github.com/appium/appium-xcuitest-driver/issues/2071)) ([b3fa78d](https://github.com/appium/appium-xcuitest-driver/commit/b3fa78d69bdaec03435e02a7e4ffb0b80a9bbde3))

## [5.6.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.5.0...v5.6.0) (2023-10-03)


### Features

* use mobile:setSimulatedLocation in setGeoLocation for ios 17 ([#2062](https://github.com/appium/appium-xcuitest-driver/issues/2062)) ([69dfab9](https://github.com/appium/appium-xcuitest-driver/commit/69dfab95dc7ba1506e2c1fe2a59e4e4be6f7b113))

## [5.5.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.4.1...v5.5.0) (2023-10-02)


### Features

* uninstall the test app once and install that again when MismatchedApplicationIdentifierEntitlement installation error occurs ([#2050](https://github.com/appium/appium-xcuitest-driver/issues/2050)) ([0c561f5](https://github.com/appium/appium-xcuitest-driver/commit/0c561f514822965166e6f87ee9725ad28542f185))

## [5.4.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.4.0...v5.4.1) (2023-10-01)


### Bug Fixes

* get bundleId for other apps before calling installation ([#2054](https://github.com/appium/appium-xcuitest-driver/issues/2054)) ([4feaf33](https://github.com/appium/appium-xcuitest-driver/commit/4feaf336dae242605543fb84d5c7b40aa5103470))

## [5.4.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.3.3...v5.4.0) (2023-09-26)


### Features

* Add clearApp extension ([#2031](https://github.com/appium/appium-xcuitest-driver/issues/2031)) ([ae0afdc](https://github.com/appium/appium-xcuitest-driver/commit/ae0afdcafabbb8164b3996627c7c3fc0f788eaf3))

## [5.3.3](https://github.com/appium/appium-xcuitest-driver/compare/v5.3.2...v5.3.3) (2023-09-24)


### Bug Fixes

* try fix release to include npm-shrinkwrap.json ([#2023](https://github.com/appium/appium-xcuitest-driver/issues/2023)) ([57fc5b8](https://github.com/appium/appium-xcuitest-driver/commit/57fc5b8dca469887cd196aee95d4230c2e21e889)), closes [#2022](https://github.com/appium/appium-xcuitest-driver/issues/2022)

## [5.3.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.3.0...v5.3.1) (2023-09-23)


### Bug Fixes

* bump wda (5.9.0, 5.9.1) and simulator(5.3.2) ([#2021](https://github.com/appium/appium-xcuitest-driver/issues/2021)) ([f6f78f5](https://github.com/appium/appium-xcuitest-driver/commit/f6f78f579da4bf439a9a2011ab02c1f9a105a1f3))

## [5.3.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.2.1...v5.3.0) (2023-09-20)


### Features

* add capability to run special input event triggering after send keys ([d559803](https://github.com/appium/appium-xcuitest-driver/commit/d5598039b52dc6c475b2cbb3c5c5049cc673a866)), closes [appium/appium#19052](https://github.com/appium/appium/issues/19052)

## [5.2.1](https://github.com/appium/appium-xcuitest-driver/compare/v5.2.0...v5.2.1) (2023-09-19)


### Bug Fixes

* terminateApp with devicectl for iOS 17 ([#1997](https://github.com/appium/appium-xcuitest-driver/issues/1997)) ([16c7319](https://github.com/appium/appium-xcuitest-driver/commit/16c73198397495f235cc49f6fb978050a9e2f49d))

## [5.2.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.1.0...v5.2.0) (2023-09-16)


### Features

* support pageSourceExcludedAttributes ([#1996](https://github.com/appium/appium-xcuitest-driver/issues/1996)) ([4bcea84](https://github.com/appium/appium-xcuitest-driver/commit/4bcea840148aa126579603d8417f77e3437db312))

## [5.1.0](https://github.com/appium/appium-xcuitest-driver/compare/v5.0.0...v5.1.0) (2023-09-14)


### Features

* add autoFillPasswords capability ([#1972](https://github.com/appium/appium-xcuitest-driver/issues/1972)) ([85aaa7f](https://github.com/appium/appium-xcuitest-driver/commit/85aaa7f62a5f882ebcaabe1c2c2272d5c9217481))
* dummy feat commit to run the auto release ([#1983](https://github.com/appium/appium-xcuitest-driver/issues/1983)) ([5916712](https://github.com/appium/appium-xcuitest-driver/commit/59167127f618dc350c9bdcf414c23c008d17169f))

## [5.0.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.35.0...v5.0.0) (2023-09-05)

### Code Refactoring

* Deprecate obsolete endpoints ([#1955](https://github.com/appium/appium-xcuitest-driver/issues/1955))
    * The includeDeviceCapsToSessionInfo capability has no effect now
    * The obsolete getSession API does not return any extra driver-specific data anymore (e.g. statBarHeight, pixelRatio, viewportRect)
    * Obsolete reset, launchApp and closeApp APIs now throw errors on invocation

## [4.35.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.34.1...v4.35.0) (2023-08-25)


### Features

* Include 'hittable' attribute ([#1918](https://github.com/appium/appium-xcuitest-driver/issues/1918)) ([b56a3d4](https://github.com/appium/appium-xcuitest-driver/commit/b56a3d4e06e3a345cdcfee9c8d8b174e6063e3ca))

## [4.34.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.34.0...v4.34.1) (2023-08-21)


### Bug Fixes

* Update glob options ([4a7a963](https://github.com/appium/appium-xcuitest-driver/commit/4a7a96319c653350b21f1836cba8afce0290a983))

## [4.34.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.33.2...v4.34.0) (2023-08-16)


### Features

* use new selenium atoms from remote debugger ([2707c01](https://github.com/appium/appium-xcuitest-driver/commit/2707c015a8990f0d666b35fefcfe15b368f9c605))

## [4.33.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.33.1...v4.33.2) (2023-08-04)


### Bug Fixes

* Args sequence for mobileTapWithNumberOfTaps ([4cb7430](https://github.com/appium/appium-xcuitest-driver/commit/4cb7430afae40307601711907fee89afb459ee48))

## [4.33.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.33.0...v4.33.1) (2023-08-04)


### Bug Fixes

* Args order for mobileTapWithNumberOfTaps call ([#1854](https://github.com/appium/appium-xcuitest-driver/issues/1854)) ([27ec7b3](https://github.com/appium/appium-xcuitest-driver/commit/27ec7b38b0b509cbf83506d44cdc376c3d0bbf6a))

## [4.33.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.25...v4.33.0) (2023-08-02)


### Features

* Lock only major package versions ([#1835](https://github.com/appium/appium-xcuitest-driver/issues/1835)) ([d640d77](https://github.com/appium/appium-xcuitest-driver/commit/d640d770ac5d9899b22ce6f6a62222bff1d10111))

## [4.32.25](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.24...v4.32.25) (2023-08-02)


### Bug Fixes

* **deps:** update dependency lru-cache to v10 ([#1776](https://github.com/appium/appium-xcuitest-driver/issues/1776)) ([2079a56](https://github.com/appium/appium-xcuitest-driver/commit/2079a56578fbdd5a09220caff1c1f1e7f8ec4254))

## [4.32.24](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.23...v4.32.24) (2023-08-01)


### Bug Fixes

* **deps:** update dependency appium-ios-simulator to v5.1.3 ([#1830](https://github.com/appium/appium-xcuitest-driver/issues/1830)) ([f71f9a0](https://github.com/appium/appium-xcuitest-driver/commit/f71f9a00868d8a69657a8fb6340418f9c9ab2e4a))

## [4.32.23](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.22...v4.32.23) (2023-07-21)


### Bug Fixes

* isAppInstalled in Xcode 15 env for simulator ([#1822](https://github.com/appium/appium-xcuitest-driver/issues/1822)) ([78f2ef2](https://github.com/appium/appium-xcuitest-driver/commit/78f2ef2fe2b7ace3d6ddadb3157f338a0f6c4cb3))

## [4.32.22](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.21...v4.32.22) (2023-07-20)


### Bug Fixes

* **deps:** update dependency @xmldom/xmldom to v0.8.10 ([598aafe](https://github.com/appium/appium-xcuitest-driver/commit/598aafebd808c654ed182e52e4a09be193182554))

## [4.32.21](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.20...v4.32.21) (2023-07-16)


### Bug Fixes

* **deps:** update dependency appium-webdriveragent to v5.6.0 for waitForQuiescence in in /wda/apps/launch ([#1817](https://github.com/appium/appium-xcuitest-driver/issues/1817)) ([9e4ded1](https://github.com/appium/appium-xcuitest-driver/commit/9e4ded1fe475d7aa83c638b1d2ca3e79936e7fc5))

## [4.32.20](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.19...v4.32.20) (2023-07-13)


### Bug Fixes

* **deps:** update dependency @xmldom/xmldom to v0.8.9 ([a5312c6](https://github.com/appium/appium-xcuitest-driver/commit/a5312c6bf1fd4fe2a2f5722e776b4ac7f17248a8))

## [4.32.19](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.18...v4.32.19) (2023-07-09)


### Bug Fixes

* **deps:** update dependency semver to v7.5.4 ([a3bed9e](https://github.com/appium/appium-xcuitest-driver/commit/a3bed9e3a3fb3326556526e0046c6a67a9026ac8))

## [4.32.18](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.17...v4.32.18) (2023-07-09)


### Bug Fixes

* **deps:** update dependency node-simctl to v7.1.17 ([6d52868](https://github.com/appium/appium-xcuitest-driver/commit/6d52868be4d449a610a5ec86f3972a5736714d42))

## [4.32.17](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.16...v4.32.17) (2023-07-08)


### Bug Fixes

* **deps:** update dependency appium-xcode to v5.1.4 ([b2d0960](https://github.com/appium/appium-xcuitest-driver/commit/b2d0960d19757d72c48b6fe807181c9a4aa82cde))

## [4.32.16](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.15...v4.32.16) (2023-07-08)


### Bug Fixes

* **deps:** update dependency appium-webdriveragent to v5.5.2 ([cebc357](https://github.com/appium/appium-xcuitest-driver/commit/cebc357c6da924e9d440f85af0ad6dcfa4e3df1a))

## [4.32.15](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.14...v4.32.15) (2023-07-08)


### Bug Fixes

* **deps:** update dependency appium-remote-debugger to v9.1.17 ([519cc40](https://github.com/appium/appium-xcuitest-driver/commit/519cc40528c3bfc72e45b55d5210401db8fe609b))

## [4.32.14](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.13...v4.32.14) (2023-07-07)


### Bug Fixes

* **deps:** update dependency appium-ios-simulator to v5.1.1 ([ce0d917](https://github.com/appium/appium-xcuitest-driver/commit/ce0d91780003fa4dfd7231ff75fdc9178b804f30))

## [4.32.13](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.12...v4.32.13) (2023-07-07)


### Bug Fixes

* **deps:** update dependency appium-ios-device to v2.5.4 ([1b14568](https://github.com/appium/appium-xcuitest-driver/commit/1b145684920ab85c76b1808c5b293c6390a5f53c))

## [4.32.12](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.11...v4.32.12) (2023-07-07)


### Bug Fixes

* **deps:** update dependency appium-idb to v1.6.13 ([9f0f26c](https://github.com/appium/appium-xcuitest-driver/commit/9f0f26c7da9ea3ca6a099afa6e00d82cec3cb2d1))

## [4.32.11](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.10...v4.32.11) (2023-07-01)


### Reverts

* Revert "chore(workflows): pin dependencies (#1773)" (#1794) ([abb6de9](https://github.com/appium/appium-xcuitest-driver/commit/abb6de9e135cdc66878f61665ff9d2290e070666)), closes [#1773](https://github.com/appium/appium-xcuitest-driver/issues/1773) [#1794](https://github.com/appium/appium-xcuitest-driver/issues/1794)


### Code Refactoring

* Tune temporary simulator creation logic ([#1790](https://github.com/appium/appium-xcuitest-driver/issues/1790)) ([9ac2f6a](https://github.com/appium/appium-xcuitest-driver/commit/9ac2f6a52348230f7d4c425722a4ef07c8ac4043))

## [4.32.10](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.9...v4.32.10) (2023-06-27)


### Bug Fixes

* **deps:** update dependency css-selector-parser to v2.3.2 ([77dbcee](https://github.com/appium/appium-xcuitest-driver/commit/77dbceefbc10f44ab5bc0e9a50f5aa3c781064d4))

## [4.32.9](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.8...v4.32.9) (2023-06-24)


### Bug Fixes

* **deps:** update dependency appium-ios-simulator to v5.1.0 ([4810e6f](https://github.com/appium/appium-xcuitest-driver/commit/4810e6f853780ad195702b208169b6ad958f72ca))

## [4.32.8](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.7...v4.32.8) (2023-06-23)


### Bug Fixes

* Copypaste in mobile method names ([#1783](https://github.com/appium/appium-xcuitest-driver/issues/1783)) ([710d246](https://github.com/appium/appium-xcuitest-driver/commit/710d24631b052f9499573e65ca24b34e238b7c02))

## [4.32.7](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.6...v4.32.7) (2023-06-23)


### Bug Fixes

* **deps:** update dependency semver to v7.5.3 ([5f35e37](https://github.com/appium/appium-xcuitest-driver/commit/5f35e37946b8e0643b7fc5117858ee98f3219327))

## [4.32.6](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.5...v4.32.6) (2023-06-23)


### Bug Fixes

* trigger release based on package.json update ([b40c8f4](https://github.com/appium/appium-xcuitest-driver/commit/b40c8f45e4aa9ca4cc0da8ace0fc83f1c79b691a))

## [4.32.5](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.4...v4.32.5) (2023-06-17)


### Bug Fixes

* **deps:** update dependency semver to v7.5.2 ([d6c236d](https://github.com/appium/appium-xcuitest-driver/commit/d6c236da158dc6fe50a20e812917cc4dc132447b))

## [4.32.4](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.3...v4.32.4) (2023-06-16)


### Bug Fixes

* **deps:** update dependency css-selector-parser to v2 ([#1759](https://github.com/appium/appium-xcuitest-driver/issues/1759)) ([0426349](https://github.com/appium/appium-xcuitest-driver/commit/0426349da313127111c19d4de44151ab45ecb64f))

## [4.32.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.2...v4.32.3) (2023-06-16)


### Bug Fixes

* **deps:** update dependency appium-webdriveragent to v5.5.1 ([#1770](https://github.com/appium/appium-xcuitest-driver/issues/1770)) ([e1c1bc9](https://github.com/appium/appium-xcuitest-driver/commit/e1c1bc932c9d550d1aaa1e82b6638eea8952c616))

## [4.32.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.1...v4.32.2) (2023-06-14)


### Bug Fixes

* **deps:** update dependency node-simctl to v7.1.16 ([#1743](https://github.com/appium/appium-xcuitest-driver/issues/1743)) ([33eced1](https://github.com/appium/appium-xcuitest-driver/commit/33eced1a309091bc3c7826c5a2fce36c2c9e87dd))

## [4.32.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.32.0...v4.32.1) (2023-06-14)


### Bug Fixes

* **deps:** update dependency teen_process to v2.0.4 ([#1758](https://github.com/appium/appium-xcuitest-driver/issues/1758)) ([a95e08a](https://github.com/appium/appium-xcuitest-driver/commit/a95e08a40a2d8653b4bc2162102a681396f25eb5))

## [4.32.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.31.0...v4.32.0) (2023-06-13)


### Features

* Add 'mobile: performAccessibilityAudit' extension ([#1754](https://github.com/appium/appium-xcuitest-driver/issues/1754)) ([cf2bb1b](https://github.com/appium/appium-xcuitest-driver/commit/cf2bb1b70e11a23438526b62018c892c29123cc8))


### Bug Fixes

* Only request chosen application attributes ([#1753](https://github.com/appium/appium-xcuitest-driver/issues/1753)) ([a8caa79](https://github.com/appium/appium-xcuitest-driver/commit/a8caa79269dc525a80c70cdc58f21789f39e8eba))

## [4.31.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.9...v4.31.0) (2023-06-10)


### Features

* bump WDA for Xcode 15 ([#1747](https://github.com/appium/appium-xcuitest-driver/issues/1747)) ([cc4ccdd](https://github.com/appium/appium-xcuitest-driver/commit/cc4ccdd606dcf758d770c424a174e3545ef1170e))

## [4.30.9](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.8...v4.30.9) (2023-06-09)


### Bug Fixes

* **deps:** update dependency appium-webdriveragent to v5.3.2 ([#1737](https://github.com/appium/appium-xcuitest-driver/issues/1737)) ([77b61c6](https://github.com/appium/appium-xcuitest-driver/commit/77b61c60fbc1987abfaf61d170c8182a1396279a))

## [4.30.8](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.7...v4.30.8) (2023-06-09)


### Bug Fixes

* **deps:** update dependency appium-ios-simulator to v5.0.9 ([#1735](https://github.com/appium/appium-xcuitest-driver/issues/1735)) ([d6960ba](https://github.com/appium/appium-xcuitest-driver/commit/d6960ba5c3f0ce91aca4168abb59a03db990ba6a))

## [4.30.7](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.6...v4.30.7) (2023-06-08)


### Bug Fixes

* **deps:** update dependency appium-idb to v1.6.12 ([#1733](https://github.com/appium/appium-xcuitest-driver/issues/1733)) ([aa50371](https://github.com/appium/appium-xcuitest-driver/commit/aa50371fc17636e1b1cf0091fd13ebc74e88abb9))
* **deps:** update dependency appium-remote-debugger to v9.1.16 ([#1736](https://github.com/appium/appium-xcuitest-driver/issues/1736)) ([2657995](https://github.com/appium/appium-xcuitest-driver/commit/265799597fbe538e265f35e2729e1334c20f778b))
* **deps:** update dependency appium-xcode to v5.1.2 ([#1738](https://github.com/appium/appium-xcuitest-driver/issues/1738)) ([e315219](https://github.com/appium/appium-xcuitest-driver/commit/e315219cf29838fe8d8855d22ce4ba4a4449c3ba))

## [4.30.6](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.5...v4.30.6) (2023-06-08)


### Bug Fixes

* **deps:** update dependency appium-ios-device to v2.5.3 ([2ea3183](https://github.com/appium/appium-xcuitest-driver/commit/2ea31830fa7afca3f7d3f2953702f5d3f92946ca))

## [4.30.5](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.4...v4.30.5) (2023-06-06)


### Bug Fixes

* Support network devices with py-ios-device + add missing method map ([#1727](https://github.com/appium/appium-xcuitest-driver/issues/1727)) ([c81c606](https://github.com/appium/appium-xcuitest-driver/commit/c81c606a95274494dba4f27b9895f7192ddce3cc))

## [4.30.4](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.3...v4.30.4) (2023-06-06)


### Bug Fixes

* **deps:** update dependency appium-webdriveragent to v5.3.1 for Xcode 15 build ([#1729](https://github.com/appium/appium-xcuitest-driver/issues/1729)) ([629b971](https://github.com/appium/appium-xcuitest-driver/commit/629b9710d6e0d4fff86e4452630d80742911e7e5))

## [4.30.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.2...v4.30.3) (2023-06-03)


### Bug Fixes

* Align initial atom wait timeout with alerts check interval ([#1720](https://github.com/appium/appium-xcuitest-driver/issues/1720)) ([8177e4b](https://github.com/appium/appium-xcuitest-driver/commit/8177e4b06b36261eac551e1174f13859d66cf2c3))

## [4.30.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.1...v4.30.2) (2023-05-31)


### Bug Fixes

* **deps:** update dependency @xmldom/xmldom to v0.8.8 ([ae453ca](https://github.com/appium/appium-xcuitest-driver/commit/ae453cad884d4956c08f27781bf9c0eee9cd97c0))

## [4.30.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.30.0...v4.30.1) (2023-05-26)


### Bug Fixes

* tune usePreinstalledWDA to behave as similar to webDriverAgentUrl ([#1709](https://github.com/appium/appium-xcuitest-driver/issues/1709)) ([cb84925](https://github.com/appium/appium-xcuitest-driver/commit/cb8492538867374f9da5afc50f854d4624c1347a))

## [4.30.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.29.6...v4.30.0) (2023-05-26)


### Features

* otherApps for real devices ([#1700](https://github.com/appium/appium-xcuitest-driver/issues/1700)) ([ad2db26](https://github.com/appium/appium-xcuitest-driver/commit/ad2db267dbbefa4dadede302930360f375c0bd88))

## [4.29.6](https://github.com/appium/appium-xcuitest-driver/compare/v4.29.5...v4.29.6) (2023-05-25)


### Bug Fixes

* **deps:** update dependency appium-remote-debugger to v9.1.15 ([f8d8213](https://github.com/appium/appium-xcuitest-driver/commit/f8d82132106442df25a513f2b1d133ce58e22e67))

## [4.29.5](https://github.com/appium/appium-xcuitest-driver/compare/v4.29.4...v4.29.5) (2023-05-24)


### Bug Fixes

* **deps:** update dependency appium-ios-simulator to v5.0.8 ([#1695](https://github.com/appium/appium-xcuitest-driver/issues/1695)) ([ed448e6](https://github.com/appium/appium-xcuitest-driver/commit/ed448e60813e6d295bbe01d801eebf2ed8291fc1))
* **deps:** update dependency appium-xcode to v5.1.1 ([#1697](https://github.com/appium/appium-xcuitest-driver/issues/1697)) ([db78d3f](https://github.com/appium/appium-xcuitest-driver/commit/db78d3f8ffc2be45db303087d444355a0cbfb7e0))

## [4.29.4](https://github.com/appium/appium-xcuitest-driver/compare/v4.29.3...v4.29.4) (2023-05-23)


### Bug Fixes

* **deps:** update dependency appium-idb to v1.6.11 ([#1691](https://github.com/appium/appium-xcuitest-driver/issues/1691)) ([3c5b125](https://github.com/appium/appium-xcuitest-driver/commit/3c5b125504f822f1fe7af2b06c90a98230216f0e))

## [4.29.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.29.2...v4.29.3) (2023-05-22)


### Bug Fixes

* **deps:** update dependency appium-ios-device to v2.5.2 ([#1692](https://github.com/appium/appium-xcuitest-driver/issues/1692)) ([80cb9b1](https://github.com/appium/appium-xcuitest-driver/commit/80cb9b14f79db67a9ff32c3319f622ddcd3b2f05))

## [4.29.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.29.1...v4.29.2) (2023-05-16)


### Bug Fixes

* **deps:** update dependency appium-webdriveragent to v5.1.4 ([#1682](https://github.com/appium/appium-xcuitest-driver/issues/1682)) ([28026cf](https://github.com/appium/appium-xcuitest-driver/commit/28026cf6ec29e64c79c0efc75f5f0be603e70693))

## [4.29.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.29.0...v4.29.1) (2023-05-16)


### Bug Fixes

* Make terminateApp to return a boolean ([2481656](https://github.com/appium/appium-xcuitest-driver/commit/24816564af418843ed9f23f59c6128be86cee4a7))

## [4.29.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.28.0...v4.29.0) (2023-05-15)


### Features

* update docs and args for more execute methods ([5c4bd32](https://github.com/appium/appium-xcuitest-driver/commit/5c4bd3272701f191d5f1abd104deab31ed6b3595))


### Bug Fixes

* **deps:** appium upgrades ([70c13dc](https://github.com/appium/appium-xcuitest-driver/commit/70c13dc779c2423c3d726aa1dbf7fcedd496ca82))
* **execute-methods:** begin migration of docstrings to sources ([316c012](https://github.com/appium/appium-xcuitest-driver/commit/316c012fad7d9b3306cbbe767195b351f60aa26d))

## [4.28.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.27.2...v4.28.0) (2023-05-14)


### Features

* Bump WDA ([#1680](https://github.com/appium/appium-xcuitest-driver/issues/1680)) ([2c07021](https://github.com/appium/appium-xcuitest-driver/commit/2c07021753b6c9b3c62639c79bcd769b17329c5c))

## [4.27.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.27.1...v4.27.2) (2023-05-13)


### Bug Fixes

* **deps:** update dependency semver to v7.5.1 ([27a0a0e](https://github.com/appium/appium-xcuitest-driver/commit/27a0a0e2eb86e272eddf6c385a950a3e44b95d02))

## [4.27.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.27.0...v4.27.1) (2023-05-12)


### Bug Fixes

* Update package lock ([4836490](https://github.com/appium/appium-xcuitest-driver/commit/4836490a84a05a127040bf882c37f87fc75118ca))

## [4.27.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.26.0...v4.27.0) (2023-05-11)


### Features

* install prebuilt WDA as prebuiltWDAPath capability ([#1672](https://github.com/appium/appium-xcuitest-driver/issues/1672)) ([2226123](https://github.com/appium/appium-xcuitest-driver/commit/22261233114788663750713c1cbea65d25d2b525))

## [4.26.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.25.4...v4.26.0) (2023-05-06)


### Features

* launch preinstalled WDA process without xcodebuild for a real device with usePreinstalledWDA ([#1609](https://github.com/appium/appium-xcuitest-driver/issues/1609)) ([3c72b58](https://github.com/appium/appium-xcuitest-driver/commit/3c72b58e12eea6d331b3b4e86cd3546954f5111f))

## [4.25.4](https://github.com/appium/appium-xcuitest-driver/compare/v4.25.3...v4.25.4) (2023-05-06)


### Bug Fixes

* **deps:** update dependency appium-webdriveragent to v4.15.1 ([#1667](https://github.com/appium/appium-xcuitest-driver/issues/1667)) ([008d7ef](https://github.com/appium/appium-xcuitest-driver/commit/008d7efda992be1b5dcc42391cf6b3c07b6f68ae))

## [4.25.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.25.2...v4.25.3) (2023-05-04)


### Bug Fixes

* **deps:** update dependency node-simctl to v7.1.15 ([41ce19a](https://github.com/appium/appium-xcuitest-driver/commit/41ce19aca7c80c14285da6d4e6a053488fe295bf))

## [4.25.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.25.1...v4.25.2) (2023-05-02)


### Bug Fixes

* **deps:** update dependency appium-webdriveragent to v4.14.0 ([bbca5a7](https://github.com/appium/appium-xcuitest-driver/commit/bbca5a731f353263bf1c2450ab6ce9319b9284f8))


### Code Refactoring

* Replace pngjs with sharp ([#1653](https://github.com/appium/appium-xcuitest-driver/issues/1653)) ([73c2654](https://github.com/appium/appium-xcuitest-driver/commit/73c26546a0735f6a8da6da763efbed02d5490488))

## [4.25.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.25.0...v4.25.1) (2023-04-29)


### Bug Fixes

* **deps:** update dependency appium-webdriveragent to v4.13.2 ([531c8f4](https://github.com/appium/appium-xcuitest-driver/commit/531c8f43c9522372a86db23b20d29e5476020f3e))

## [4.25.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.24.3...v4.25.0) (2023-04-26)


### Features

* Add mobile wrapper for backgroundApp ([#1637](https://github.com/appium/appium-xcuitest-driver/issues/1637)) ([04397cf](https://github.com/appium/appium-xcuitest-driver/commit/04397cf5df6f40a9f32f3c5dab7f278f3fc1d9f0))

## [4.24.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.24.2...v4.24.3) (2023-04-22)


### Bug Fixes

* **deps:** update dependency semver to v7.5.0 ([c5e21dc](https://github.com/appium/appium-xcuitest-driver/commit/c5e21dc7e18d734a8c7b9bc48cbe2bb5f00dbf64))

## [4.24.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.24.1...v4.24.2) (2023-04-21)


### Bug Fixes

* make whitespace in execute methods insignificant ([#1628](https://github.com/appium/appium-xcuitest-driver/issues/1628)) ([1dc7777](https://github.com/appium/appium-xcuitest-driver/commit/1dc7777cc6c3cd23f75085967d193562b63e6562))

## [4.24.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.24.0...v4.24.1) (2023-04-20)


### Bug Fixes

* Add missing return to removeApp API ([#1623](https://github.com/appium/appium-xcuitest-driver/issues/1623)) ([af2db2e](https://github.com/appium/appium-xcuitest-driver/commit/af2db2e8a7694887f9f16da34d4d66c4f96ec8a5))

## [4.24.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.23.2...v4.24.0) (2023-04-19)


### Features

* Add mobile wrappers to lock/unlock the device ([#1624](https://github.com/appium/appium-xcuitest-driver/issues/1624)) ([eca9530](https://github.com/appium/appium-xcuitest-driver/commit/eca9530fb6f3aac049bf407a8433b71ed8664e76))

## [4.23.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.23.1...v4.23.2) (2023-04-19)


### Bug Fixes

* apply correct params to enableConditionInducer ([09c97b2](https://github.com/appium/appium-xcuitest-driver/commit/09c97b237b381398a7505bd094fb329ee847ea9a))

## [4.23.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.23.0...v4.23.1) (2023-04-18)


### Bug Fixes

* **command:** flip args for mobile: getPermission ([de44162](https://github.com/appium/appium-xcuitest-driver/commit/de44162820d28531faf631758916e9a704becf6b))


### Code Refactoring

* getCookies and deleteCookies ([#1538](https://github.com/appium/appium-xcuitest-driver/issues/1538)) ([14e70b7](https://github.com/appium/appium-xcuitest-driver/commit/14e70b716775207804b4e40bd5b5c82dba6eacca))

## [4.23.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.22.0...v4.23.0) (2023-04-18)


### Features

* Add 'mobile: hideKeyboard' and 'mobile: isKeyboardShown' extensions ([#1618](https://github.com/appium/appium-xcuitest-driver/issues/1618)) ([0050e5f](https://github.com/appium/appium-xcuitest-driver/commit/0050e5f66abc0558e0294ecc0267a279af6f5b8d))

## [4.22.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.35...v4.22.0) (2023-04-17)


### Features

* Add `mobile: getAppStrings` extension ([#1608](https://github.com/appium/appium-xcuitest-driver/issues/1608)) ([5445ebb](https://github.com/appium/appium-xcuitest-driver/commit/5445ebbab95da3874eb6f27e974c8a8a6828f914))

## [4.21.35](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.34...v4.21.35) (2023-04-16)


### Bug Fixes

* **deps:** update dependency appium-ios-device to v2.5.0 ([b208ce3](https://github.com/appium/appium-xcuitest-driver/commit/b208ce3d8ca26c13247c7a2a090ebf596615b296))

## [4.21.34](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.33...v4.21.34) (2023-04-16)


### Bug Fixes

* **deps:** update dependency semver to v7.4.0 ([cdecf15](https://github.com/appium/appium-xcuitest-driver/commit/cdecf150a8a33f5c741936d3bc042b52a9405b70))

## [4.21.33](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.32...v4.21.33) (2023-04-14)


### Bug Fixes

* Fix the return type of mobile: removeCertificate extension ([10cfce1](https://github.com/appium/appium-xcuitest-driver/commit/10cfce1308a22e47e823bbbe6affc116a743817b))

## [4.21.32](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.31...v4.21.32) (2023-04-14)


### Bug Fixes

* **commands:** fix "mobile: startPcap" execute method ([a761365](https://github.com/appium/appium-xcuitest-driver/commit/a761365a66506d9e15f6977ee41cf161f987cc04))
* **commands:** fix startAudioRecording and stopAudioRecording execute methods ([990547a](https://github.com/appium/appium-xcuitest-driver/commit/990547a9b671243b298c6318af1327f2e15315fa))

## [4.21.31](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.30...v4.21.31) (2023-04-13)


### Miscellaneous Chores

* **workflows:** update actions/checkout digest to 83b7061 ([5212653](https://github.com/appium/appium-xcuitest-driver/commit/5212653638ce2ccfb6cbb82fb1f8094551a56e09))

## [4.21.30](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.29...v4.21.30) (2023-04-13)


### Miscellaneous Chores

* **deps:** update dependency @appium/tsconfig to v0.3.0 ([ef1d08b](https://github.com/appium/appium-xcuitest-driver/commit/ef1d08be2b05c55691ac91600ab233da12bef22c))

## [4.21.29](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.28...v4.21.29) (2023-04-12)


### Miscellaneous Chores

* **deps:** update dependency webdriverio to v8.8.1 ([827ff21](https://github.com/appium/appium-xcuitest-driver/commit/827ff21f75f14c50121edc72b80e83022611be82))

## [4.21.28](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.27...v4.21.28) (2023-04-12)


### Bug Fixes

* **deps:** update dependency appium-xcode to v5.1.0 ([6f05ef2](https://github.com/appium/appium-xcuitest-driver/commit/6f05ef259a917bcb3c7653af733d1f28ebf13bdc))

## [4.21.27](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.26...v4.21.27) (2023-04-11)


### Bug Fixes

* add correct types for context objects ([928ffcc](https://github.com/appium/appium-xcuitest-driver/commit/928ffccfaca376fe875a0be5a5cb6e2f6b1cff87))
* lint, test fixes ([47a8174](https://github.com/appium/appium-xcuitest-driver/commit/47a81743a69de33922f58df2399736c2fbb9c2bb))
* **types:** fix mostly test types ([f1ec6d5](https://github.com/appium/appium-xcuitest-driver/commit/f1ec6d5e0b66fd41e6e9b93e9e409d725207424a))
* **web:** do not return `true` from deleteCookie() ([5dd66d5](https://github.com/appium/appium-xcuitest-driver/commit/5dd66d54e346dbf671e5c72a4bb84c4d03243eed))
* **xctest:** mobileRunXCTest param "args" is optional ([438671f](https://github.com/appium/appium-xcuitest-driver/commit/438671ff1a3501fb6265308c83344dcd9d3545e7))


### Miscellaneous Chores

* re-enable require-await rule ([1b8b533](https://github.com/appium/appium-xcuitest-driver/commit/1b8b533387e0acf9a4881871cd0be3411841a6f4))
* use execute methods & types ([f6f77d2](https://github.com/appium/appium-xcuitest-driver/commit/f6f77d2bd518c5ce625dd833748817e53f37b854))

## [4.21.26](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.25...v4.21.26) (2023-04-11)


### Miscellaneous Chores

* **deps:** update appium-related packages ([70b85b2](https://github.com/appium/appium-xcuitest-driver/commit/70b85b24135a7aa585818f5bb4b795ea9322d93e))
* **deps:** update dependency appium to v2.0.0-beta.62 ([ed37de3](https://github.com/appium/appium-xcuitest-driver/commit/ed37de3c74ed144656aa000ffbec783321f38c6a))

## [4.21.25](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.24...v4.21.25) (2023-04-11)


### Bug Fixes

* **deps:** update dependency lru-cache to v7.18.3 ([d6a2c3c](https://github.com/appium/appium-xcuitest-driver/commit/d6a2c3ca04bdccf6cf3308543fdd0f5316848066))


### Miscellaneous Chores

* **deps:** update dependency webdriverio to v8.7.0 ([dfc7b01](https://github.com/appium/appium-xcuitest-driver/commit/dfc7b01ad55384680d23172d3b741c0a80b63b29))

## [4.21.24](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.23...v4.21.24) (2023-04-10)


### Miscellaneous Chores

* **deps:** update dependency glob to v9.3.5 ([4105b6d](https://github.com/appium/appium-xcuitest-driver/commit/4105b6dfb597cb9fec7e3ed43f007f2e42acfa0d))

## [4.21.23](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.22...v4.21.23) (2023-04-10)


### Miscellaneous Chores

* **deps:** update dependency type-fest to v3.8.0 ([6327db2](https://github.com/appium/appium-xcuitest-driver/commit/6327db2bbb1550119896598427d85487086b7c0a))

## [4.21.22](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.21...v4.21.22) (2023-04-10)


### Miscellaneous Chores

* **deps:** update dependency eslint to v8.38.0 ([39ebc7d](https://github.com/appium/appium-xcuitest-driver/commit/39ebc7d2fe939f36facb37ad87fa9bc194d146c3))

## [4.21.21](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.20...v4.21.21) (2023-04-09)


### Bug Fixes

* **deps:** update dependency moment-timezone to v0.5.43 ([a9d57da](https://github.com/appium/appium-xcuitest-driver/commit/a9d57da88e8a45e9236ef35cc3e5f31e8016064b))

## [4.21.20](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.19...v4.21.20) (2023-04-09)


### Bug Fixes

* **deps:** update dependency appium-ios-device to v2.4.12 ([ddd20d8](https://github.com/appium/appium-xcuitest-driver/commit/ddd20d8ce7995b851e7526baeb16b5a94ac262bb))

## [4.21.19](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.18...v4.21.19) (2023-04-09)


### Bug Fixes

* **deps:** update dependency @xmldom/xmldom to v0.8.7 ([0c94161](https://github.com/appium/appium-xcuitest-driver/commit/0c94161368d177112d30e910e725c8cd30716742))

## [4.21.18](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.17...v4.21.18) (2023-04-09)


### Miscellaneous Chores

* **deps:** update eslint-related packages ([9e60d30](https://github.com/appium/appium-xcuitest-driver/commit/9e60d30489edf9bf2eda0ea180c77edfec3d2ed3))

## [4.21.17](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.16...v4.21.17) (2023-04-08)


### Miscellaneous Chores

* **deps:** update dependency semantic-release to v20.1.3 ([ef8056a](https://github.com/appium/appium-xcuitest-driver/commit/ef8056ada3da522c6b4f1e93b69e527a1fe4143d))

## [4.21.16](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.15...v4.21.16) (2023-04-08)


### Miscellaneous Chores

* **deps:** update dependency lint-staged to v13.2.1 ([d93296a](https://github.com/appium/appium-xcuitest-driver/commit/d93296a53d59eefe7397ab39893fe1f40b506b4b))

## [4.21.15](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.14...v4.21.15) (2023-04-08)


### Miscellaneous Chores

* **deps:** update dependency pem to v1.14.7 ([30618c9](https://github.com/appium/appium-xcuitest-driver/commit/30618c9ef5f61e3fd75bac88c31c7862e251f86c))

## [4.21.14](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.13...v4.21.14) (2023-04-07)


### Miscellaneous Chores

* **ci:** fix docs workflow ([102cd39](https://github.com/appium/appium-xcuitest-driver/commit/102cd39cf03bda25522e3e6a83104b71f8466a37))
* **ci:** remove dependabot config ([7c81e33](https://github.com/appium/appium-xcuitest-driver/commit/7c81e33d6c44b4edffe6494fc504d0a68c536ed8))
* update .gitattributes ([c71c043](https://github.com/appium/appium-xcuitest-driver/commit/c71c0432fbed74140102e0d97f5a321fae766acc))
* **workflows:** pin dependencies ([9d82149](https://github.com/appium/appium-xcuitest-driver/commit/9d8214962b5bb5469bc0f0ebd971b4bd9fa59189))

## [4.21.13](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.12...v4.21.13) (2023-04-07)


### Miscellaneous Chores

* **deps:** update dependency glob to v9.3.4 ([6da88cb](https://github.com/appium/appium-xcuitest-driver/commit/6da88cb519abe986f0bca09babdc3ca6f7645243))

## [4.21.12](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.11...v4.21.12) (2023-04-07)


### Miscellaneous Chores

* **deps:** update appium-related packages ([108cd56](https://github.com/appium/appium-xcuitest-driver/commit/108cd569a502f868c550748bb5db91188fb17e65))

## [4.21.11](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.10...v4.21.11) (2023-04-06)


### Miscellaneous Chores

* **ci:** attempt to get docs preview working ([8b0f34f](https://github.com/appium/appium-xcuitest-driver/commit/8b0f34fb8d2ae810db22fea7741935cee0d69c29))

## [4.21.10](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.9...v4.21.10) (2023-04-06)


### Miscellaneous Chores

* **deps:** update dependency axios to v1.3.5 ([38c1b04](https://github.com/appium/appium-xcuitest-driver/commit/38c1b0479426bb14f95022e1c43c98c4a9ed8629))

## [4.21.9](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.8...v4.21.9) (2023-04-06)


### Miscellaneous Chores

* **deps:** update dependency appium to v2.0.0-beta.61 ([9eb21a0](https://github.com/appium/appium-xcuitest-driver/commit/9eb21a06d2d9add933392947060c0868cc580d8d))

## [4.21.8](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.7...v4.21.8) (2023-04-05)


### Miscellaneous Chores

* add wallaby config ([0e42a45](https://github.com/appium/appium-xcuitest-driver/commit/0e42a45c623d33024f212d0437431e4cf77c48b7))
* pin all deps ([f0a54e5](https://github.com/appium/appium-xcuitest-driver/commit/f0a54e5a3f1e151084d23ae2f1bf2f3ac00f0f99))
* update GHA workflows to use "npm ci" ([b9083fc](https://github.com/appium/appium-xcuitest-driver/commit/b9083fc34dc3d45176ec67dc5c590b9dc6996046))
* update lint-staged config ([bb1af17](https://github.com/appium/appium-xcuitest-driver/commit/bb1af1793d7aa8400c67ca708e636b6c619abcf0))
* **utils:** lint ([039c3c0](https://github.com/appium/appium-xcuitest-driver/commit/039c3c083cdcb68d99b80585c2bb77836711fa0d))

## [4.21.7](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.6...v4.21.7) (2023-04-04)


### Miscellaneous Chores

* Bump WDA ([4c1b22d](https://github.com/appium/appium-xcuitest-driver/commit/4c1b22db30b154eddef889f59aa13a339a091149))

## [4.21.6](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.5...v4.21.6) (2023-04-03)


### Miscellaneous Chores

* **test:** clean up unit test ([794e09a](https://github.com/appium/appium-xcuitest-driver/commit/794e09ac6d25b486d1d2954ab2403192ee94c816))

## [4.21.5](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.4...v4.21.5) (2023-04-03)


### Bug Fixes

* revert "chore: Bump get-port from 5.1.1 to 6.1.2 ([#1535](https://github.com/appium/appium-xcuitest-driver/issues/1535))" ([4d6303e](https://github.com/appium/appium-xcuitest-driver/commit/4d6303ef7f9173485d0a8d3bb8ede1f18b625331))

## [4.21.4](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.3...v4.21.4) (2023-04-01)


### Miscellaneous Chores

* Bump get-port from 5.1.1 to 6.1.2 ([#1535](https://github.com/appium/appium-xcuitest-driver/issues/1535)) ([ff96d7c](https://github.com/appium/appium-xcuitest-driver/commit/ff96d7cfa209783f58fc053602b7e37889c6241f))
* Bump rimraf from 3.0.2 to 4.4.1 ([#1536](https://github.com/appium/appium-xcuitest-driver/issues/1536)) ([8dd4515](https://github.com/appium/appium-xcuitest-driver/commit/8dd4515a3f10a090cd49881217fb98903339a786))

## [4.21.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.2...v4.21.3) (2023-04-01)


### Bug Fixes

* cookies regression: send Page commands for cookies handling ([#1534](https://github.com/appium/appium-xcuitest-driver/issues/1534)) ([908ed1a](https://github.com/appium/appium-xcuitest-driver/commit/908ed1a6d64e4522d95502e125bde32032a3e686))

## [4.21.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.1...v4.21.2) (2023-03-31)


### Bug Fixes

* launchApp regression ([#1540](https://github.com/appium/appium-xcuitest-driver/issues/1540)) ([a66cb47](https://github.com/appium/appium-xcuitest-driver/commit/a66cb47f83ea9dd1ec70f227281957cd932cd037))

## [4.21.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.21.0...v4.21.1) (2023-03-29)


### Miscellaneous Chores

* **test:** fix a bunch of assertions ([a733d71](https://github.com/appium/appium-xcuitest-driver/commit/a733d7139050aca887766da81b5bba93f3f07f4c))

## [4.21.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.20.1...v4.21.0) (2023-03-29)


### Features

* build docs with typedoc ([ab354a5](https://github.com/appium/appium-xcuitest-driver/commit/ab354a57d8677b639949959f8a7112cb11cd9848))
* refactor to support automatic command docs ([9b9e6fa](https://github.com/appium/appium-xcuitest-driver/commit/9b9e6fa860425f3ed2a9130d088889c05e3e10a9))


### Bug Fixes

* **driver:** use correct method name ([45330bb](https://github.com/appium/appium-xcuitest-driver/commit/45330bbbdc8b1d28a3dd43ba8628e80a9f278160))
* **execute:** better validation of "mobile commands" ([0b9b9cb](https://github.com/appium/appium-xcuitest-driver/commit/0b9b9cb697d3c18e1d65a122ac5029ad6452c916))


### Miscellaneous Chores

* add wallaby config ([1915292](https://github.com/appium/appium-xcuitest-driver/commit/1915292b830d8f60a98af1b211f83d3982bfba7b))
* fixup ([4fb1e8a](https://github.com/appium/appium-xcuitest-driver/commit/4fb1e8a1d31f807c92550f0677bf4e36fefd9076))
* rename method installXCTestBundle => mobileInstallXCTestBundle for consistency ([11349cb](https://github.com/appium/appium-xcuitest-driver/commit/11349cb52bea66ee4b2d7f48aa81d8891e69641d))
* rename runXCTest => mobileRunXCTest ([621ef8c](https://github.com/appium/appium-xcuitest-driver/commit/621ef8c6020c67bbc95bb7a44bbdf8a32a1a61e2))
* try to skip problem tests ([3cfea5d](https://github.com/appium/appium-xcuitest-driver/commit/3cfea5d72984035c6ee84a06b019c4151017e34f))
* upgrade appium ([fb6ed96](https://github.com/appium/appium-xcuitest-driver/commit/fb6ed9664246e63b8a49c35f2ab8a3231627bfd9))
* use random port for phony https server ([382d296](https://github.com/appium/appium-xcuitest-driver/commit/382d2966d5043fe93e3646f88e7b0416f6e4d6f3))

## [4.20.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.20.0...v4.20.1) (2023-03-29)


### Bug Fixes

* Add missing --name option to removeProfile ([#1530](https://github.com/appium/appium-xcuitest-driver/issues/1530)) ([a930762](https://github.com/appium/appium-xcuitest-driver/commit/a930762933a7008caab4fe1549e64e4d340b6ede))

## [4.20.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.19.1...v4.20.0) (2023-03-28)


### Features

* Add command for mobileRemoveCertificate for real devices ([#1529](https://github.com/appium/appium-xcuitest-driver/issues/1529)) ([2255f31](https://github.com/appium/appium-xcuitest-driver/commit/2255f3129d952c804dde3c1328aaacceb1e7df79))

## [4.19.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.19.0...v4.19.1) (2023-03-12)


### Bug Fixes

* Make sure the app is not reinstalled if noReset is requested ([4e8ccba](https://github.com/appium/appium-xcuitest-driver/commit/4e8ccba99d5e7b491ecdca0d5e17188e76165223))
* Tune app install condition ([d64805b](https://github.com/appium/appium-xcuitest-driver/commit/d64805b80fb1f1ab4a13fa1ebcdbb8915548d883))

## [4.19.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.18.4...v4.19.0) (2023-03-03)


### Features

* Allow to skip app install if a newer/same app version is already installed ([#1514](https://github.com/appium/appium-xcuitest-driver/issues/1514)) ([a79cc4e](https://github.com/appium/appium-xcuitest-driver/commit/a79cc4e9f6e1c4e83cc2224a70381427ecc48329))


### Code Refactoring

* cleanup process.env.CLOUD and process.env.REAL_DEVICE ([#1513](https://github.com/appium/appium-xcuitest-driver/issues/1513)) ([579b1ee](https://github.com/appium/appium-xcuitest-driver/commit/579b1ee62288876d569cb6ae2c222a2658eb4c59))

## [4.18.4](https://github.com/appium/appium-xcuitest-driver/compare/v4.18.3...v4.18.4) (2023-02-28)


### Miscellaneous Chores

* Short circuit if the app under test crashes while checking for alerts ([#1510](https://github.com/appium/appium-xcuitest-driver/issues/1510)) ([5684cdf](https://github.com/appium/appium-xcuitest-driver/commit/5684cdf8c55a2d6a59d51e56c94bf0cec01f79a4))

## [4.18.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.18.2...v4.18.3) (2023-02-27)


### Miscellaneous Chores

* Bump @appium/docutils from 0.1.6 to 0.2.2 ([#1509](https://github.com/appium/appium-xcuitest-driver/issues/1509)) ([5e7c927](https://github.com/appium/appium-xcuitest-driver/commit/5e7c927353e38b096d0e7e82f52163e0e022e6bd))

## [4.18.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.18.1...v4.18.2) (2023-02-26)


### Miscellaneous Chores

* remove unused cookies code ([#1508](https://github.com/appium/appium-xcuitest-driver/issues/1508)) ([1f5e2c4](https://github.com/appium/appium-xcuitest-driver/commit/1f5e2c4ef17b2698a4f8a156fcccac7f3406b659))

## [4.18.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.18.0...v4.18.1) (2023-02-23)


### Bug Fixes

* Update WDA build scipt ([#1506](https://github.com/appium/appium-xcuitest-driver/issues/1506)) ([ad84172](https://github.com/appium/appium-xcuitest-driver/commit/ad841721549513ebcb1accc7840667d6898e023f))

## [4.18.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.17.1...v4.18.0) (2023-02-20)


### Features

* Add simulated geolocation extensions ([#1503](https://github.com/appium/appium-xcuitest-driver/issues/1503)) ([cfb149b](https://github.com/appium/appium-xcuitest-driver/commit/cfb149be26b6dfc55771e6b5159b14c127f88268))

## [4.17.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.17.0...v4.17.1) (2023-02-20)


### Miscellaneous Chores

* Bump pngjs from 6.0.0 to 7.0.0 ([#1504](https://github.com/appium/appium-xcuitest-driver/issues/1504)) ([e0bdc0b](https://github.com/appium/appium-xcuitest-driver/commit/e0bdc0b0ae18f6681ce9ca7f5328ec318061c724))

## [4.17.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.13...v4.17.0) (2023-02-20)


### Features

* Add deepLink extension ([#1502](https://github.com/appium/appium-xcuitest-driver/issues/1502)) ([067179b](https://github.com/appium/appium-xcuitest-driver/commit/067179beda19ca478d2d08b59ffb864ba6c9bbdb))

## [4.16.13](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.12...v4.16.13) (2023-02-17)


### Miscellaneous Chores

* Bump WDA ([d8994f9](https://github.com/appium/appium-xcuitest-driver/commit/d8994f9e807e893544ce0fcd42e63147fa1a1c5b))

## [4.16.12](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.11...v4.16.12) (2023-02-06)


### Bug Fixes

* Update NOTCHED_DEVICE_SIZES for nativeWebTapStrict (part of [#1490](https://github.com/appium/appium-xcuitest-driver/issues/1490)) ([#1497](https://github.com/appium/appium-xcuitest-driver/issues/1497)) ([e2bbd94](https://github.com/appium/appium-xcuitest-driver/commit/e2bbd94e27d402776de235ff53abd714b7ae6ef0))

## [4.16.11](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.10...v4.16.11) (2023-02-05)


### Bug Fixes

* update WDA to include snapshots/maxDepth fixes ([#1495](https://github.com/appium/appium-xcuitest-driver/issues/1495)) ([ccc30f8](https://github.com/appium/appium-xcuitest-driver/commit/ccc30f81329e149a6dc60c1c4b824052cdfb998d))

## [4.16.10](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.9...v4.16.10) (2023-01-17)


### Miscellaneous Chores

* Bump semantic-release from 19.0.5 to 20.0.2 ([#1485](https://github.com/appium/appium-xcuitest-driver/issues/1485)) ([bbe7366](https://github.com/appium/appium-xcuitest-driver/commit/bbe73661336671b2c189fd3a1af6ecf5873001e3))

## [4.16.9](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.8...v4.16.9) (2023-01-13)


### Miscellaneous Chores

* Bump appium-xcode from 4.0.5 to 5.0.0 ([#1488](https://github.com/appium/appium-xcuitest-driver/issues/1488)) ([e759033](https://github.com/appium/appium-xcuitest-driver/commit/e759033fdac8b05f4410fd77028c0f85cf22918d))

## [4.16.8](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.7...v4.16.8) (2023-01-12)


### Bug Fixes

* specify supported non-standard commands in newMethodMap ([503bd60](https://github.com/appium/appium-xcuitest-driver/commit/503bd60398155bf7e1d95346dad6258d120f0fb2))

## [4.16.7](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.6...v4.16.7) (2023-01-10)


### Bug Fixes

* mobile:getPermission for iOS 14+ ([#1486](https://github.com/appium/appium-xcuitest-driver/issues/1486)) ([803390c](https://github.com/appium/appium-xcuitest-driver/commit/803390cb3e5f0d3fc24d5278dd8c9af89e3f70e5))

## [4.16.6](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.5...v4.16.6) (2023-01-03)


### Bug Fixes

* Include scripts into the package ([f747865](https://github.com/appium/appium-xcuitest-driver/commit/f747865ca970c5480fb3602f8f3a35ecb2fa1a25))

## [4.16.5](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.4...v4.16.5) (2022-12-28)


### Miscellaneous Chores

* remove tapWithShortPressDuration cap ([#1481](https://github.com/appium/appium-xcuitest-driver/issues/1481)) ([5d64e3a](https://github.com/appium/appium-xcuitest-driver/commit/5d64e3aa32ef4eaaaadaeb1c799670622680b579))

## [4.16.4](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.3...v4.16.4) (2022-12-28)


### Bug Fixes

* releaseActions fails due to unhandled endpoint ([#1477](https://github.com/appium/appium-xcuitest-driver/issues/1477)) ([ff53b98](https://github.com/appium/appium-xcuitest-driver/commit/ff53b9890a04c4501762325d195815f52ce8a916))

## [4.16.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.2...v4.16.3) (2022-12-19)


### Bug Fixes

* set permissions for simulator ([#1473](https://github.com/appium/appium-xcuitest-driver/issues/1473)) ([a885628](https://github.com/appium/appium-xcuitest-driver/commit/a8856286ea7304a9c2ec3ed8c46a5c66526bc102))

## [4.16.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.1...v4.16.2) (2022-12-18)


### Bug Fixes

* XCTest command ([#1471](https://github.com/appium/appium-xcuitest-driver/issues/1471)) ([d176f45](https://github.com/appium/appium-xcuitest-driver/commit/d176f455c23b4c6b59ff72be36d3050c60bcf470))

## [4.16.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.16.0...v4.16.1) (2022-12-17)


### Bug Fixes

* /wda/device/appearance as withoutSession ([#1472](https://github.com/appium/appium-xcuitest-driver/issues/1472)) ([00eba1d](https://github.com/appium/appium-xcuitest-driver/commit/00eba1d9eb42c998ffe93d978cb9fb4c5f761b35))

## [4.16.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.15.2...v4.16.0) (2022-12-16)


### Features

* Bump the major version of appium-ios-simulator ([#1468](https://github.com/appium/appium-xcuitest-driver/issues/1468)) ([c9fc1dc](https://github.com/appium/appium-xcuitest-driver/commit/c9fc1dc7d70a2050435a651d77bc6e37253965cd))

## [4.15.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.15.1...v4.15.2) (2022-12-14)


### Miscellaneous Chores

* Bump @appium/test-support from 2.0.2 to 3.0.0 ([#1467](https://github.com/appium/appium-xcuitest-driver/issues/1467)) ([3149a15](https://github.com/appium/appium-xcuitest-driver/commit/3149a15240b4529085cbee8e015b8cedbf054179))

## [4.15.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.15.0...v4.15.1) (2022-12-13)


### Miscellaneous Chores

* Deprecate calendarAccessAuthorized capability ([#1465](https://github.com/appium/appium-xcuitest-driver/issues/1465)) ([2c63d9a](https://github.com/appium/appium-xcuitest-driver/commit/2c63d9a97ae4c420942e66f2a3bc1413535c7905))

## [4.15.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.14.0...v4.15.0) (2022-12-13)


### Features

* add reduceTransparency ([#1464](https://github.com/appium/appium-xcuitest-driver/issues/1464)) ([82e7c23](https://github.com/appium/appium-xcuitest-driver/commit/82e7c237dcf8dcd5ee23c2bd57c2f831f4083a03))

## [4.14.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.13.4...v4.14.0) (2022-12-13)


### Features

* Streamline changing of Simulator preferences ([#1463](https://github.com/appium/appium-xcuitest-driver/issues/1463)) ([79c2e36](https://github.com/appium/appium-xcuitest-driver/commit/79c2e3626d550a2d04ace00d840d7b8e4d14614b))

## [4.13.4](https://github.com/appium/appium-xcuitest-driver/compare/v4.13.3...v4.13.4) (2022-12-10)


### Miscellaneous Chores

* Only call appropriate setters if their capabilities are defined ([#1462](https://github.com/appium/appium-xcuitest-driver/issues/1462)) ([f633a51](https://github.com/appium/appium-xcuitest-driver/commit/f633a51981aab8d03c3a3cb173bea90b6f9178a1))

## [4.13.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.13.2...v4.13.3) (2022-12-08)


### Miscellaneous Chores

* Bump WDA ([b6f1658](https://github.com/appium/appium-xcuitest-driver/commit/b6f1658fa1920b3e52005be0f63f1e66c0723c1b))

## [4.13.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.13.1...v4.13.2) (2022-12-05)


### Miscellaneous Chores

* Bump webdriverio from 7.27.0 to 8.0.5 ([#1460](https://github.com/appium/appium-xcuitest-driver/issues/1460)) ([7f1c079](https://github.com/appium/appium-xcuitest-driver/commit/7f1c0793b83b6c41a71c848472e93de04eb1cb04))

## [4.13.1](https://github.com/appium/appium-xcuitest-driver/compare/v4.13.0...v4.13.1) (2022-12-01)


### Miscellaneous Chores

* update releaserc ([#1458](https://github.com/appium/appium-xcuitest-driver/issues/1458)) ([c818934](https://github.com/appium/appium-xcuitest-driver/commit/c81893450bdf48be8cb9406e06a3a99b6f826ba3))

# [4.13.0](https://github.com/appium/appium-xcuitest-driver/compare/v4.12.4...v4.13.0) (2022-12-01)


### Features

* Add a script to open WDA in Xcode ([#1457](https://github.com/appium/appium-xcuitest-driver/issues/1457)) ([e2255fe](https://github.com/appium/appium-xcuitest-driver/commit/e2255fe92d1a4e3bb129b840b06a61fc312d1a11))

## [4.12.4](https://github.com/appium/appium-xcuitest-driver/compare/v4.12.3...v4.12.4) (2022-11-29)

## [4.12.3](https://github.com/appium/appium-xcuitest-driver/compare/v4.12.2...v4.12.3) (2022-11-25)

## [4.12.2](https://github.com/appium/appium-xcuitest-driver/compare/v4.12.1...v4.12.2) (2022-11-06)
