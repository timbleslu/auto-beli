import type {Element, StringRecord} from '@appium/types';
import {errors} from 'appium/driver.js';
import {util} from 'appium/support.js';

import {XCUITestDriver} from '../driver.js';

type ExecuteMethodArgs = readonly any[] | readonly [StringRecord<unknown>] | Readonly<StringRecord<unknown>>;

/**
 * @template TReturn
 * @param script - Either a script to run, or in the case of an Execute Method, the name of the script to execute.
 * @param args
 */
export async function execute<TReturn = unknown>(
  this: XCUITestDriver,
  script: string,
  args?: ExecuteMethodArgs,
): Promise<TReturn> {
  // TODO: create a type that converts args to the parameters of the associated method using the `command` prop of `executeMethodMap`
  script = script.trim().replace(/^mobile:\s*/, 'mobile: ');
  if (isExecuteMethod(script)) {
    const executeMethodArgs = preprocessExecuteMethodArgs(script, args as ExecuteMethodArgs | undefined);
    return await this.executeMethod(script, [executeMethodArgs]);
  } else if (this.isWebContext()) {
    return await this._webExecutionBackend.executeScript<TReturn>(script, args as unknown[] | undefined);
  } else {
    throw new errors.NotImplementedError();
  }
}

/**
 * @group Mobile Web Only
 */
export async function executeAsync(this: XCUITestDriver, script: string, args?: readonly any[]): Promise<any> {
  if (!this.isWebContext()) {
    throw new errors.NotImplementedError();
  }

  return await this._webExecutionBackend.executeAsyncScript(script, args as unknown[] | undefined);
}

/**
 * Checks if script expects a particular parameter (either optional or required).
 * @template Script
 * @param script - Script name
 * @param param - Parameter name
 * @returns {boolean}
 */
function executeMethodExpectsParam<Script extends keyof typeof XCUITestDriver.executeMethodMap>(
  script: Script,
  param: string,
): boolean {
  let required: ReadonlyArray<string> | undefined;
  let optional: ReadonlyArray<string> | undefined;
  const execMethodDef = XCUITestDriver.executeMethodMap[script];
  if ('params' in execMethodDef) {
    if ('required' in execMethodDef.params) {
      required = execMethodDef.params.required;
    }
    if ('optional' in execMethodDef.params) {
      optional = execMethodDef.params.optional;
    }
  }
  const allParams = new Set([...(required ?? []), ...(optional ?? [])]);
  return allParams.has(param);
}

/**
 * @param script
 * @returns {script is keyof XCUITestDriver.executeMethodMap}
 */
function isExecuteMethod(script: string): script is keyof typeof XCUITestDriver.executeMethodMap {
  return script in XCUITestDriver.executeMethodMap;
}

/**
 * Massages the arguments going into an execute method.
 * @param script
 * @param args
 */
function preprocessExecuteMethodArgs(
  script: keyof typeof XCUITestDriver.executeMethodMap,
  args?: ExecuteMethodArgs,
): StringRecord<unknown> {
  if (Array.isArray(args)) {
    args = args[0];
  }
  const executeMethodArgs = (args ?? {}) as StringRecord<unknown>;
  /**
   * Renames the deprecated `element` key to `elementId`.  Historically,
   * all of the pre-Execute-Method-Map execute methods accepted an `element` _or_ and `elementId` param.
   * This assigns the `element` value to `elementId` if `elementId` is not already present.
   */
  if (!('elementId' in executeMethodArgs) && 'element' in executeMethodArgs) {
    executeMethodArgs.elementId = executeMethodArgs.element;
    delete executeMethodArgs.element;
  }

  /**
   * Automatically unwraps the `elementId` prop _if and only if_ the execute method expects it.
   *
   * Most of these Execute Methods (typically beginning with `mobile*`) will accept an `Element|string` for `elementId`, in practice they will only ever get a `string`. `Element|string` in the method's docstring is simply for documentation purposes.
   */
  if ('elementId' in executeMethodArgs && executeMethodExpectsParam(script, 'elementId')) {
    executeMethodArgs.elementId = util.unwrapElement(executeMethodArgs.elementId as Element<string> | string);
  }

  return executeMethodArgs;
}
