import {WDA_BASE_URL} from 'appium-webdriveragent';
import type {WDASettings} from 'appium-webdriveragent';
import {fs, tempDir, logger, util} from 'appium/support.js';
import {waitForCondition} from 'asyncbox';
import {exec, SubProcess} from 'teen_process';

import type {XCUITestDriver} from '../driver.js';
import {encodeBase64OrUpload} from './helpers/index.js';
import type {StartRecordingScreenOptions, StopRecordingScreenOptions} from './types.js';

/**
 * Optional execute-script keys for `mobile: startScreenRecording`, in Appium flattened-arg order.
 * Keep in sync with `lib/execute-method-map.ts` (`mobile: startScreenRecording` optional keys).
 */
export const START_SCREEN_RECORDING_EXECUTE_OPTIONALS = [
  'videoType',
  'videoQuality',
  'videoFps',
  'videoFilters',
  'videoScale',
  'pixelFormat',
  'forceRestart',
  'timeLimit',
  'hardwareAcceleration',
  'remotePath',
  'user',
  'pass',
  'headers',
  'fileFieldName',
  'formFields',
  'method',
] as const satisfies ReadonlyArray<keyof StartRecordingScreenOptions>;

/**
 * Optional execute-script keys for `mobile: stopScreenRecording`, in Appium flattened-arg order.
 * Keep in sync with `lib/execute-method-map.ts` (`mobile: stopScreenRecording` optional keys).
 */
export const STOP_SCREEN_RECORDING_EXECUTE_OPTIONALS = [
  'remotePath',
  'user',
  'pass',
  'headers',
  'fileFieldName',
  'formFields',
  'method',
] as const satisfies ReadonlyArray<keyof StopRecordingScreenOptions>;

/**
 * Set max timeout for 'reconnect_delay_max' ffmpeg argument usage.
 * It could have [0-4294] range limitation, thus this value should be less than that right now
 * to return a better error message.
 */
const MAX_RECORDING_TIME_SEC = 4200;
const DEFAULT_RECORDING_TIME_SEC = 60 * 3;
const DEFAULT_FPS = 10;
const DEFAULT_QUALITY = 'medium';
const DEFAULT_MJPEG_SERVER_PORT = 9100;
const DEFAULT_VCODEC = 'mjpeg';
const MP4_EXT = '.mp4';
const FFMPEG_BINARY = 'ffmpeg';
const ffmpegLogger = logger.getLogger(FFMPEG_BINARY);
const QUALITY_MAPPING: Record<string, number> = {
  low: 10,
  medium: 25,
  high: 75,
  photo: 100,
};

const HARDWARE_ACCELERATION_PARAMETERS: Record<
  string,
  {
    hwaccel: string;
    hwaccelOutputFormat: string;
    scaleFilterHWAccel: string;
    videoTypeHWAccel: string;
  }
> = {
  /* https://trac.ffmpeg.org/wiki/HWAccelIntro#VideoToolbox */
  videoToolbox: {
    hwaccel: 'videotoolbox',
    hwaccelOutputFormat: 'videotoolbox_vld',
    scaleFilterHWAccel: 'scale_vt',
    videoTypeHWAccel: 'h264_videotoolbox',
  },
  /* https://trac.ffmpeg.org/wiki/HWAccelIntro#CUDANVENCNVDEC */
  cuda: {
    hwaccel: 'cuda',
    hwaccelOutputFormat: 'cuda',
    scaleFilterHWAccel: 'scale_cuda',
    videoTypeHWAccel: 'h264_nvenc',
  },
  /* https://trac.ffmpeg.org/wiki/Hardware/AMF */
  amf_dx11: {
    hwaccel: 'd3d11va',
    hwaccelOutputFormat: 'd3d11',
    scaleFilterHWAccel: 'scale',
    videoTypeHWAccel: 'av1_amf',
  },
  /* https://trac.ffmpeg.org/wiki/Hardware/QuickSync */
  qsv: {
    hwaccel: 'qsv',
    hwaccelOutputFormat: '',
    scaleFilterHWAccel: 'scale_qsv',
    videoTypeHWAccel: 'h264_qsv',
  },
  /* https://trac.ffmpeg.org/wiki/Hardware/VAAPI */
  vaapi: {
    hwaccel: 'vaapi',
    hwaccelOutputFormat: 'vaapi',
    scaleFilterHWAccel: 'scale_vaapi',
    videoTypeHWAccel: 'h264_vaapi',
  },
};

const CAPTURE_START_MARKER = /^\s*frame=/;

interface ScreenRecorderOptions {
  hardwareAcceleration?: string;
  remotePort: number;
  remoteUrl: string;
  videoFps?: number;
  videoType?: string;
  videoScale?: string;
  videoFilters?: string;
  pixelFormat?: string;
}

export class ScreenRecorder {
  private readonly videoPath: string;
  private readonly log: any;
  private readonly opts: ScreenRecorderOptions;
  private readonly udid: string;
  private mainProcess: SubProcess | null;
  private timeoutHandler: NodeJS.Timeout | null;
  private stopFailed = false;

  constructor(udid: string, log: any, videoPath: string, opts: ScreenRecorderOptions) {
    this.videoPath = videoPath;
    this.log = log;
    this.opts = opts;
    this.udid = udid;
    this.mainProcess = null;
    this.timeoutHandler = null;
  }

  async start(timeoutMs: number): Promise<void> {
    try {
      await fs.which(FFMPEG_BINARY);
    } catch {
      throw new Error(
        `'${FFMPEG_BINARY}' binary is not found in PATH. Install it using 'brew install ffmpeg'. ` +
          `Check https://www.ffmpeg.org/download.html for more details.`,
      );
    }

    const {hardwareAcceleration, remotePort, remoteUrl, videoFps, videoType, videoScale, videoFilters, pixelFormat} =
      this.opts;

    const args: string[] = [
      '-f',
      'mjpeg',
      // https://github.com/appium/appium/issues/16294
      '-reconnect',
      '1',
      '-reconnect_at_eof',
      '1',
      '-reconnect_streamed',
      '1',
      '-reconnect_delay_max',
      `${timeoutMs / 1000 + 1}`,
    ];
    const {hwaccel, hwaccelOutputFormat, scaleFilterHWAccel, videoTypeHWAccel} =
      HARDWARE_ACCELERATION_PARAMETERS[hardwareAcceleration || ''] ?? {};

    if (hwaccel) {
      args.push('-hwaccel', hwaccel);
    }

    if (hwaccelOutputFormat) {
      args.push('-hwaccel_output_format', hwaccelOutputFormat);
    }

    // Raw MJPEG has no timestamps; override ffmpeg's 25 fps default for every codec.
    args.push('-r', String(videoFps || DEFAULT_FPS));
    const useAutomaticCanvas = !videoFilters && !videoScale && !hardwareAcceleration;
    const parsed = new URL(remoteUrl);
    const streamUrl = `${parsed.protocol}//${parsed.hostname}:${remotePort}`;
    let canvas: {width: number; height: number} | undefined;
    if (useAutomaticCanvas) {
      // pad must recalculate its offsets when frames change size, but its canvas
      // must remain fixed. Probe with ffmpeg itself to support raw and multipart
      // MJPEG without requiring ffprobe or an optional image library.
      const {stdout} = await exec(
        FFMPEG_BINARY,
        [
          '-v',
          'error',
          '-f',
          'mjpeg',
          '-probesize',
          '32',
          '-analyzeduration',
          '0',
          '-i',
          streamUrl,
          '-frames:v',
          '1',
          '-c:v',
          'png',
          '-f',
          'image2pipe',
          'pipe:1',
        ],
        {isBuffer: true, timeout: Math.min(timeoutMs, 10000), maxStdoutBufferSize: 32 * 1024 * 1024},
      );
      if (stdout.length < 24 || !stdout.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
        throw new Error('Cannot determine the recording canvas from the first MJPEG frame');
      }
      canvas = {
        width: Math.ceil(stdout.readUInt32BE(16) / 2) * 2,
        height: Math.ceil(stdout.readUInt32BE(20) / 2) * 2,
      };
      if (!canvas.width || !canvas.height) {
        throw new Error('The first MJPEG frame has invalid dimensions');
      }
      args.push('-reinit_filter', '0');
    }
    args.push('-i', streamUrl);

    if (videoFilters || videoScale) {
      args.push('-vf', videoFilters || `${scaleFilterHWAccel || 'scale'}=${videoScale}`);
    } else if (canvas) {
      args.push(
        '-vf',
        `scale=${canvas.width}:${canvas.height}:force_original_aspect_ratio=decrease:force_divisible_by=2:eval=frame,` +
          `pad=${canvas.width}:${canvas.height}:(ow-iw)/2:(oh-ih)/2:eval=frame,setsar=1`,
      );
    }

    // Quicktime compatibility via pixelFormat: 'yuv420p'
    if (pixelFormat) {
      args.push('-pix_fmt', pixelFormat);
    }
    args.push('-vcodec', videoTypeHWAccel || videoType || DEFAULT_VCODEC);
    args.push('-y');
    args.push(this.videoPath);

    this.mainProcess = new SubProcess(FFMPEG_BINARY, args);
    let isCaptureStarted = false;
    this.mainProcess.on('line-stderr', (line: string) => {
      if (CAPTURE_START_MARKER.test(line)) {
        if (!isCaptureStarted) {
          isCaptureStarted = true;
        }
      } else {
        ffmpegLogger.info(line);
      }
    });
    await this.mainProcess.start(0);
    const startupTimeout = 5000;
    try {
      await waitForCondition(() => isCaptureStarted, {
        waitMs: startupTimeout,
        intervalMs: 300,
      });
    } catch {
      this.log.warn(`Screen capture process did not start within ${startupTimeout}ms. Continuing anyway`);
    }
    if (!this.mainProcess.isRunning) {
      throw new Error(
        `The screen capture process '${FFMPEG_BINARY}' died unexpectedly. ` + `Check server logs for more details`,
      );
    }
    this.log.info(
      `Starting screen capture on the device '${this.udid}' with command: '${FFMPEG_BINARY} ${args.join(' ')}'. ` +
        `Will timeout in ${timeoutMs}ms`,
    );

    this.timeoutHandler = setTimeout(async () => {
      if (!(await this.interrupt())) {
        this.log.warn(
          `Cannot finish the active screen recording on the device '${this.udid}' after ${timeoutMs}ms timeout`,
        );
      }
    }, timeoutMs);
  }

  async interrupt(force = false): Promise<boolean> {
    let result = true;

    if (this.timeoutHandler) {
      clearTimeout(this.timeoutHandler);
      this.timeoutHandler = null;
    }

    const process = this.mainProcess;
    if (process?.isRunning) {
      try {
        await process.stop(force ? 'SIGTERM' : 'SIGINT');
      } catch (e: any) {
        // A disconnected MJPEG source can leave ffmpeg waiting to reconnect. Keep
        // its handle so cleanup can retry; its MP4 trailer may not be written.
        this.stopFailed = true;
        this.log.warn(
          `Cannot ${force ? 'terminate' : 'interrupt'} ${FFMPEG_BINARY}. ` + `Original error: ${e.message}`,
        );
        result = false;
        if (force && process.isRunning) {
          try {
            await process.stop('SIGKILL');
            result = true;
          } catch (killError: any) {
            this.log.warn(`Cannot kill ${FFMPEG_BINARY}. Original error: ${killError.message}`);
          }
        }
      } finally {
        if (!process.isRunning && this.mainProcess === process) {
          this.mainProcess = null;
        }
      }
    }

    return result;
  }

  async finish(): Promise<string> {
    const stopped = await this.interrupt();
    if (!stopped || this.stopFailed) {
      throw new Error(`Cannot finalize the screen recording because ${FFMPEG_BINARY} failed to stop gracefully`);
    }
    return this.videoPath;
  }

  async cleanup(): Promise<void> {
    if (await fs.exists(this.videoPath)) {
      await fs.rimraf(this.videoPath);
    }
  }
}

/**
 * Direct Appium to start recording the device screen
 *
 * Record the display of devices running iOS Simulator since Xcode 9 or real devices since iOS 11
 * (ffmpeg utility is required: 'brew install ffmpeg').
 * It records screen activity to a MPEG-4 file. Audio is not recorded with the video file.
 * If screen recording has been already started then the command will stop it forcefully and start a new one.
 * The previously recorded video file will be deleted.
 *
 * @param options - The available options.
 * @returns Base64-encoded content of the recorded media file if
 *                   any screen recording is currently running or an empty string.
 * @throws {Error} If screen recording has failed to start.
 */
export async function startRecordingScreen(
  this: XCUITestDriver,
  options: StartRecordingScreenOptions = {},
): Promise<string> {
  const {
    videoType = DEFAULT_VCODEC,
    timeLimit = DEFAULT_RECORDING_TIME_SEC,
    videoQuality = DEFAULT_QUALITY,
    videoFps = DEFAULT_FPS,
    videoFilters,
    videoScale,
    forceRestart,
    pixelFormat,
    hardwareAcceleration,
  } = options;

  let result = '';
  if (!forceRestart) {
    this.log.info(
      `Checking if there is/was a previous screen recording. ` +
        `Set 'forceRestart' option to 'true' if you'd like to skip this step.`,
    );
    result = (await this.stopRecordingScreen(options)) ?? result;
  }

  const videoPath = await tempDir.path({
    prefix: `appium_${Math.random().toString(16).substring(2, 8)}`,
    suffix: MP4_EXT,
  });

  const screenRecorder = new ScreenRecorder(this.device.udid, this.log, videoPath, {
    remotePort: this.opts.mjpegServerPort || DEFAULT_MJPEG_SERVER_PORT,
    remoteUrl: this.opts.wdaBaseUrl || WDA_BASE_URL,
    videoType,
    videoFilters,
    videoScale,
    videoFps: typeof videoFps === 'string' ? parseInt(videoFps, 10) : videoFps,
    pixelFormat,
    hardwareAcceleration,
  });
  if (!(await screenRecorder.interrupt(true))) {
    throw this.log.errorWithException('Unable to stop screen recording process');
  }
  if (this._recentScreenRecorder) {
    await this._recentScreenRecorder.cleanup();
    this._recentScreenRecorder = null;
  }

  const timeoutSeconds = parseFloat(String(timeLimit));
  if (isNaN(timeoutSeconds) || timeoutSeconds > MAX_RECORDING_TIME_SEC || timeoutSeconds <= 0) {
    throw this.log.errorWithException(
      `The timeLimit value must be in range [1, ${MAX_RECORDING_TIME_SEC}] seconds. ` +
        `The value of '${timeLimit}' has been passed instead.`,
    );
  }

  let {mjpegServerScreenshotQuality, mjpegServerFramerate} = (await this.proxyCommand(
    '/appium/settings',
    'GET',
  )) as WDASettings;
  if (videoQuality) {
    const quality = Number.isInteger(videoQuality) ? videoQuality : QUALITY_MAPPING[String(videoQuality).toLowerCase()];
    if (!quality) {
      throw new Error(
        `videoQuality value should be one of ${JSON.stringify(
          Object.keys(QUALITY_MAPPING),
        )} or a number in range 1..100. ` + `'${videoQuality}' is given instead`,
      );
    }
    mjpegServerScreenshotQuality = mjpegServerScreenshotQuality !== quality ? (quality as number) : undefined;
  } else {
    mjpegServerScreenshotQuality = undefined;
  }
  if (videoFps) {
    const fps = parseInt(String(videoFps), 10);
    if (isNaN(fps)) {
      throw new Error(`videoFps value should be a valid number in range 1..60. ` + `'${videoFps}' is given instead`);
    }
    mjpegServerFramerate = mjpegServerFramerate !== fps ? fps : undefined;
  } else {
    mjpegServerFramerate = undefined;
  }
  if (util.hasValue(mjpegServerScreenshotQuality) || util.hasValue(mjpegServerFramerate)) {
    await this.proxyCommand('/appium/settings', 'POST', {
      settings: {
        mjpegServerScreenshotQuality,
        mjpegServerFramerate,
      },
    });
  }

  try {
    await screenRecorder.start(timeoutSeconds * 1000);
  } catch (e) {
    await screenRecorder.interrupt(true);
    await screenRecorder.cleanup();
    throw e;
  }
  this._recentScreenRecorder = screenRecorder;

  return result;
}

/**
 * Direct Appium to stop screen recording and return the video
 *
 * If no screen recording process is running then the endpoint will try to get
 * the recently recorded file. If no previously recorded file is found and no
 * active screen recording processes are running then the method returns an
 * empty string.
 *
 * @param options - The available options.
 * @returns Base64-encoded content of the recorded media
 * file if `remotePath` parameter is empty or null or an empty string.
 * @throws {Error} If there was an error while getting the name of a media
 *                 file or the file content cannot be uploaded to the remote
 *                 location.
 */
export async function stopRecordingScreen(
  this: XCUITestDriver,
  options: StopRecordingScreenOptions = {},
): Promise<string | null> {
  if (!this._recentScreenRecorder) {
    this.log.info('Screen recording is not running. There is nothing to stop.');
    return '';
  }

  try {
    const videoPath = await this._recentScreenRecorder.finish();
    if (!(await fs.exists(videoPath))) {
      throw this.log.errorWithException(
        `The screen recorder utility has failed ` + `to store the actual screen recording at '${videoPath}'`,
      );
    }
    return await encodeBase64OrUpload(videoPath, options.remotePath, options);
  } finally {
    await this._recentScreenRecorder.interrupt(true);
    await this._recentScreenRecorder.cleanup();
    this._recentScreenRecorder = null;
  }
}

/**
 * Execute-script entry for `mobile: startScreenRecording`. Appium passes one positional argument
 * per optional key (see `START_SCREEN_RECORDING_EXECUTE_OPTIONALS`); this wrapper collapses
 * them into the options object for `startRecordingScreen`.
 */
export async function mobileStartScreenRecording(this: XCUITestDriver, ...args: unknown[]): Promise<string> {
  const options = optionsFromFlattenedExecuteArgs<StartRecordingScreenOptions>(
    [...START_SCREEN_RECORDING_EXECUTE_OPTIONALS],
    args,
  );
  return await this.startRecordingScreen(options);
}

/**
 * Execute-script entry for `mobile: stopScreenRecording`. Collapses flattened args into the
 * options object for `stopRecordingScreen`.
 */
export async function mobileStopScreenRecording(this: XCUITestDriver, ...args: unknown[]): Promise<string | null> {
  const options = optionsFromFlattenedExecuteArgs<StopRecordingScreenOptions>(
    [...STOP_SCREEN_RECORDING_EXECUTE_OPTIONALS],
    args,
  );
  return await this.stopRecordingScreen(options);
}

function optionsFromFlattenedExecuteArgs<T extends object>(keys: readonly string[], args: readonly unknown[]): T {
  const out: Record<string, unknown> = {};
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (key !== undefined && args[i] !== undefined) {
      out[key] = args[i];
    }
  }
  return out as T;
}
