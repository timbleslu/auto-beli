import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';

import type {Element} from '@appium/types';
import type {Simulator} from 'appium-ios-simulator';
import {fs, plist, tempDir, util} from 'appium/support.js';
import {retryInterval, retry, waitForCondition} from 'asyncbox';
import {findAPortNotInUse, checkPortStatus} from 'portscanner';
import {exec} from 'teen_process';

import {CertificateClient} from '../device/certificate-client.js';
import type {XCUITestDriver} from '../driver.js';
import {isEmpty} from '../utils/index.js';
import {requireRealDevice} from './helpers/index.js';
import type {CertificateList} from './types.js';

const CONFIG_EXTENSION = 'mobileconfig';
const HOST_PORT_RANGE = [38200, 38299];
const TMPSERVER_STARTUP_TIMEOUT = 5000;
const Settings = /** @type {const} */ {
  General: {
    type: 'accessibility id',
    value: 'General',
  },
  Profile: {
    type: '-ios predicate string',
    value: `name BEGINSWITH 'Profile'`,
  },
  About: {
    type: 'accessibility id',
    value: 'About',
  },
  Certificate_Trust_Settings: {
    type: 'accessibility id',
    value: 'Certificate Trust Settings',
  },
};
const Button = /** @type {const} */ {
  Install: {
    type: 'accessibility id',
    value: 'Install',
  },
  Allow: {
    type: 'accessibility id',
    value: 'Allow',
  },
  Done: {
    type: 'accessibility id',
    value: 'Done',
  },
  Return_to_Settings: {
    type: 'accessibility id',
    value: 'Return to Settings',
  },
};
const Alert = /** @type {const} */ {
  Install: {
    type: '-ios class chain',
    value:
      "**/XCUIElementTypeAny[`type == 'XCUIElementTypeAlert' OR type == 'XCUIElementTypeSheet'`]/**/XCUIElementTypeButton[`label == 'Install'`]",
  },
};

const LIBRE_SSL_PATTERN = /\/CN=([^\/]+)/; // eslint-disable-line no-useless-escape
const OPEN_SSL_PATTERN = /,\sCN\s=\s([^,]+)/;

/**
 * Parses the common name of the certificate from the given string.
 */
export function parseCommonName(stringCertificate: string): string {
  for (const r of [LIBRE_SSL_PATTERN, OPEN_SSL_PATTERN]) {
    const match = r.exec(stringCertificate);
    if (match?.[1]) {
      return match[1];
    }
  }
  throw new Error(`There is no common name value in '${stringCertificate}' output`);
}

/**
 * Installs a custom certificate onto the device.
 *
 * Since Xcode SDK 11.4, Apple has added a dedicated `simctl` subcommand to quickly handle
 * certificates on Simulator over CLI.
 *
 * On real devices (or simulators before Xcode SDK 11.4), Apple provides no "official" way to do this via the command line.  In such a case (and also as a fallback if CLI setup fails), this method tries to wrap the certificate into `.mobileconfig` format, then deploys the wrapped file to the internal HTTP server so that it can be opened via mobile Safari. This command then goes through the profile installation procedure by clicking the necessary buttons using WebDriverAgent.
 * @param content - Base64-encoded content of the public certificate in [PEM](https://knowledge.digicert.com/quovadis/ssl-certificates/ssl-general-topics/what-is-pem-format.html) format
 * @param commonName - Common name of the certificate. If this is not set, the command will try to parse it from the provided `content`.
 * @param isRoot - Defines where the certificate should be installed; either the Trusted Root Store (`true`) or the Keychain (`false`). On environments other than Xcode 11.4+ Simulator, this option is ignored.
 * @returns The content of the generated `.mobileconfig` file as
 * a base64-encoded string. This config might be useful for debugging purposes.  If the certificate has been successfully set via CLI, then nothing is returned.
 */
export async function mobileInstallCertificate(
  this: XCUITestDriver,
  content: string,
  commonName?: string,
  isRoot = true,
): Promise<string | void> {
  if (isEmpty(content)) {
    throw new Error('Certificate content should not be empty');
  }

  if (this.isSimulator()) {
    try {
      await (this.device as Simulator).addCertificate(Buffer.from(content, 'base64').toString(), {isRoot});
      return;
    } catch (e) {
      this.log.debug(e);
      this.log.info(`The certificate cannot be installed via CLI. ` + `Falling back to UI-based deployment`);
    }
  } else {
    try {
      await withCertificateClient(this, async (client) => {
        await client.installCertificate({payload: Buffer.from(content, 'base64')});
      });
      return;
    } catch (err) {
      this.log.error(`Failed to install the certificate: ${(err as Error).message}`);
      this.log.info('Falling back to the (slow) UI-based installation');
    }
  }

  const tmpRoot = await tempDir.openDir();
  const tmpPort = await findAPortNotInUse(HOST_PORT_RANGE[0], HOST_PORT_RANGE[1]);
  const configName = `appium.${CONFIG_EXTENSION}`;
  const configPath = path.resolve(tmpRoot, configName);
  const tmpServer = http.createServer(async function (_, res) {
    const configFile = await fs.readFile(configPath);
    res.end(configFile);
  });
  try {
    const certBuffer = Buffer.from(content, 'base64');
    const cn = commonName || (await extractCommonName(certBuffer));
    const mobileConfig = toMobileConfig(certBuffer, cn);
    try {
      await plist.updatePlistFile(configPath, mobileConfig, false, false);
    } catch (err) {
      throw new Error(
        `Cannot store the generated config as '${configPath}'. ` + `Original error: ${(err as Error).message}`,
        {
          cause: err,
        },
      );
    }

    try {
      const host = os.hostname();
      const certUrl = `http://${host}:${tmpPort}/${configName}`;
      tmpServer.listen(tmpPort);
      try {
        await waitForCondition(
          async () => {
            try {
              return (await checkPortStatus(tmpPort, host)) === 'open';
            } catch {
              return false;
            }
          },
          {
            waitMs: TMPSERVER_STARTUP_TIMEOUT,
            intervalMs: 300,
          },
        );
        this.log.debug(`The temporary web server is running at http://${host}:${tmpPort}`);
      } catch {
        throw new Error(`The temporary web server cannot be started at http://${host}:${tmpPort}.`);
      }
      if (this.isRealDevice()) {
        try {
          await this.proxyCommand('/url', 'POST', {url: certUrl});
        } catch (err) {
          if (this.isWebContext()) {
            // The command above does not always work on real devices
            await this.setUrl(certUrl);
          } else {
            throw err;
          }
        }
      } else {
        await (this.device as Simulator).openUrl(certUrl);
      }

      let isCertAlreadyInstalled = false;
      const platformVersion = this.opts.platformVersion ?? '';
      if (util.compareVersions(platformVersion, '>=', '12.2')) {
        if (await installPost122Certificate(this, cn)) {
          await clickElement(this, Settings.Profile);
          await trustCertificateInPreferences(this, cn);
        } else {
          isCertAlreadyInstalled = true;
        }
      } else {
        if (await installPre122Certificate(this)) {
          await clickElement(this, Button.Return_to_Settings);
          await trustCertificateInPreferences(this, cn);
        } else {
          isCertAlreadyInstalled = true;
        }
      }
      if (isCertAlreadyInstalled) {
        this.log.info(`It looks like the '${cn}' certificate has been already added to the CA root`);
      }
    } finally {
      if (this.opts.bundleId) {
        try {
          await this.activateApp(this.opts.bundleId);
        } catch (e) {
          this.log.warn(
            `Cannot restore the application '${this.opts.bundleId}'. Original error: ${(e as Error).message}`,
          );
        }
      }
    }

    return (await util.toInMemoryBase64(configPath)).toString();
  } finally {
    tmpServer.close();
    await fs.rimraf(tmpRoot);
  }
}

/**
 * Removes installed certificates.
 *
 * Requires a real device running iOS/tvOS 18+ with the optional appium-ios-remotexpc package.
 *
 * @since 4.19.2
 * @param name - Name of the profile
 * @returns Status acknowledgment when the certificate is successfully removed
 * @throws {Error} If attempting to remove certificates for a simulated device or if RemoteXPC setup fails
 * @group Real Device Only
 */
export async function mobileRemoveCertificate(this: XCUITestDriver, name: string): Promise<string> {
  requireRealDevice(this, 'Removing certificate');
  return await withCertificateClient(this, async (client) => client.removeCertificate(name));
}

/**
 * Returns map of certificates installed on the real device.
 *
 * Requires a real device running iOS/tvOS 18+ with the optional appium-ios-remotexpc package.
 * @since 4.10.0
 * @returns An object describing the certificates installed on the real device.
 * @throws {Error} If attempting to list certificates for a simulated device or if RemoteXPC setup fails
 */
export async function mobileListCertificates(this: XCUITestDriver): Promise<CertificateList> {
  requireRealDevice(this, 'Listing certificates');
  return await withCertificateClient(this, async (client) => client.listCertificates());
}

/**
 * Installs PEM content from `appium:customSSLCert` on the paired real device (session startup).
 * On iOS/tvOS 18+ this requires `appium-ios-remotexpc` (same RemoteXPC certificate client as mobile
 * certificate commands); setup throws if RemoteXPC is unavailable or iOS version is less than 18.
 * `start()` has already set `platformVersion` from the device when the capability was omitted.
 */
export async function installCustomSslCertFromCapability(this: XCUITestDriver): Promise<void> {
  const pem = this.opts.customSSLCert;
  if (!pem) {
    return;
  }
  requireRealDevice(this, 'install customSSLCert capability');
  await withCertificateClient(this, async (client) => {
    await client.installCertificate({
      payload: Buffer.from(pem, 'utf8'),
    });
  });
}

/**
 * Helper function to create a CertificateClient, execute an operation, and ensure cleanup.
 *
 * @param driver - The XCUITestDriver instance
 * @param operation - A callback function that receives the client and performs the operation
 * @returns The result of the operation callback
 */
async function withCertificateClient<T>(
  driver: XCUITestDriver,
  operation: (client: CertificateClient) => Promise<T>,
): Promise<T> {
  let client: CertificateClient | null = null;
  try {
    if (!driver.opts.udid) {
      throw new Error('udid capability is required');
    }
    client = await CertificateClient.create(driver.opts.udid, driver.log, driver.remoteXPCFacade);
    return await operation(client);
  } finally {
    if (client) {
      await client.close();
    }
  }
}

/**
 * Extracts the common name of the certificate from the given buffer.
 *
 * @param {Buffer} certBuffer
 * @returns The common name of the certificate
 */
async function extractCommonName(certBuffer: Buffer): Promise<string> {
  const tempCert = await tempDir.open({
    prefix: 'cert',
    suffix: '.cer',
  });
  try {
    await fs.writeFile(tempCert.path, certBuffer);
    const {stdout} = await exec('openssl', ['x509', '-noout', '-subject', '-in', tempCert.path]);
    return parseCommonName(stdout);
  } catch (err) {
    throw new Error(
      `Cannot parse common name value from the certificate. Is it valid and base64-encoded? ` +
        `Original error: ${(err as Error).message}`,
      {cause: err},
    );
  } finally {
    await fs.rimraf(tempCert.path);
  }
}

/**
 * Generates Apple's over-the-air configuration profile
 * for certificate deployment based on the given PEM certificate content.
 * Read https://developer.apple.com/library/content/documentation/NetworkingInternet/Conceptual/iPhoneOTAConfiguration/Introduction/Introduction.html
 * for more details on such profiles.
 *
 * @param {Buffer} certBuffer - The actual content of PEM certificate encoded into NodeJS buffer
 * @param commonName - Certificate's common name
 * @returns {Object} The encoded structure of the given certificate, which is ready to be passed
 * as an argument to plist builder
 * @throws {Error} If the given certificate cannot be parsed
 */
function toMobileConfig(certBuffer: Buffer, commonName: string): Record<string, any> {
  const getUUID = () => util.uuidV4().toUpperCase();
  const contentUuid = getUUID();
  return {
    PayloadContent: [
      {
        PayloadCertificateFileName: `${commonName}.cer`,
        PayloadContent: certBuffer,
        PayloadDescription: 'Adds a CA root certificate',
        PayloadDisplayName: commonName,
        PayloadIdentifier: `com.apple.security.root.${contentUuid}`,
        PayloadType: 'com.apple.security.root',
        PayloadUUID: contentUuid,
        PayloadVersion: 1,
      },
    ],
    PayloadDisplayName: commonName,
    PayloadIdentifier: `${os.hostname().split('.')[0]}.${getUUID()}`,
    PayloadRemovalDisallowed: false,
    PayloadType: 'Configuration',
    PayloadUUID: getUUID(),
    PayloadVersion: 1,
  };
}

async function clickElement(
  driver: XCUITestDriver,
  locator: {type: string; value: string},
  options: {timeout?: number; skipIfInvisible?: boolean} = {},
): Promise<boolean> {
  const {timeout = 5000, skipIfInvisible = false} = options;
  const lookupDelay = 500;
  let element: Element | null;
  try {
    element = await retryInterval(timeout < lookupDelay ? 1 : timeout / lookupDelay, lookupDelay, () =>
      driver.findNativeElementOrElements(locator.type, locator.value, false),
    );
  } catch {
    if (skipIfInvisible) {
      return false;
    }
    throw new Error(`Cannot find ${JSON.stringify(locator)} within ${timeout}ms timeout`);
  }
  if (!element) {
    if (skipIfInvisible) {
      return false;
    }
    throw new Error(`Cannot find ${JSON.stringify(locator)} within ${timeout}ms timeout`);
  }
  await driver.nativeClick(element);
  return true;
}

async function installPre122Certificate(driver: XCUITestDriver): Promise<boolean> {
  // Accept Safari alert
  await clickElement(driver, Button.Allow, {
    // certificate load might take some time on slow machines
    timeout: 15000,
  });
  // Wait until Preferences are opened
  await delay(2000);

  // Go through Preferences wizard
  if (
    !(await clickElement(driver, Button.Install, {
      skipIfInvisible: true,
    }))
  ) {
    return false;
  }
  // We need to click Install button on two different tabs
  // The second one confirms the previous
  await delay(1500);
  await clickElement(driver, Button.Install);
  // Accept alert
  await clickElement(driver, Alert.Install);
  // Finish adding certificate
  await clickElement(driver, Button.Done);
  return true;
}

async function trustCertificateInPreferences(driver: XCUITestDriver, name: string): Promise<void> {
  await clickElement(driver, Settings.General);
  await clickElement(driver, Settings.About);
  const switchLocator = {
    type: '-ios class chain',
    value: `**/XCUIElementTypeCell[\`label == '${name}'\`]/**/XCUIElementTypeSwitch`,
  };
  await retry(5, async () => {
    const tableEl = await driver.findNativeElementOrElements('class name', 'XCUIElementTypeTable', false);
    await driver.mobileSwipe('up', undefined, tableEl);
    await clickElement(driver, Settings.Certificate_Trust_Settings, {
      timeout: 500,
    });

    await driver.findNativeElementOrElements(switchLocator.type, switchLocator.value, false);
  });
  // Only click the switch if it is set to Off
  if (
    await clickElement(
      driver,
      {
        type: switchLocator.type,
        value: `${switchLocator.value}[\`value == '0'\`]`,
      },
      {
        timeout: 1000,
        skipIfInvisible: true,
      },
    )
  ) {
    await driver.postAcceptAlert();
  }
}

async function installPost122Certificate(driver: XCUITestDriver, name: string): Promise<boolean> {
  // Accept Safari alert
  await clickElement(driver, Button.Allow, {
    // certificate load might take some time on slow machines
    timeout: 15000,
  });
  // Wait for the second alert
  await delay(2000);

  await driver.postAcceptAlert();
  await driver.activateApp('com.apple.Preferences');
  await clickElement(driver, Settings.General);
  await clickElement(driver, Settings.Profile);
  // Select the target cert
  let isCertFound = false;
  for (let swipeNum = 0; swipeNum < 5; ++swipeNum) {
    if (
      await clickElement(
        driver,
        {
          type: '-ios class chain',
          value: `**/XCUIElementTypeCell[\`label == '${name}'\`]`,
        },
        {
          timeout: 500,
          skipIfInvisible: true,
        },
      )
    ) {
      isCertFound = true;
      break;
    }

    const tableEl = await driver.findNativeElementOrElements('class name', 'XCUIElementTypeTable', false);
    await driver.mobileSwipe('up', undefined, tableEl);
  }
  if (!isCertFound) {
    throw new Error(`'${name}' cannot be found in the certificates list`);
  }

  // Install option is only visible if the cert is not installed yet
  if (
    !(await clickElement(driver, Button.Install, {
      skipIfInvisible: true,
    }))
  ) {
    return false;
  }
  await delay(1500);
  // Confirm untrusted cert install
  await clickElement(driver, Button.Install);
  // Accept alert
  await clickElement(driver, Alert.Install);
  // Finish adding certificate
  await clickElement(driver, Button.Done);

  return true;
}
