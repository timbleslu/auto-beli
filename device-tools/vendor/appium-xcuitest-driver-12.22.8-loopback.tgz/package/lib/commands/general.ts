import type {Simulator} from 'appium-ios-simulator';
import {errors} from 'appium/driver.js';
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';

import {getDuoSimulator, withDuoArgumentErrors} from './helpers/duo.js';
import {HIDPageEvent, HIDUsageConsumerEvent} from './hid-event.js';

dayjs.extend(utc);

import {LockdownClient} from '../device/lockdown-client.js';
import type {XCUITestDriver} from '../driver.js';
import type {ButtonName, PressableButtonsInfo} from './types.js';

const DATETIME_FORMAT_ISO8601 = 'YYYY-MM-DDTHH:mm:ssZ';
const DUO_BUTTON_USAGES = new Map<string, HIDUsageConsumerEvent>([
  ['home', HIDUsageConsumerEvent.kHIDUsage_Csmr_Menu],
  ['volumeup', HIDUsageConsumerEvent.kHIDUsage_Csmr_VolumeIncrement],
  ['volumedown', HIDUsageConsumerEvent.kHIDUsage_Csmr_VolumeDecrement],
]);

/**
 * Trigger a touch/fingerprint match or match failure.
 *
 * @param match - Whether the match should be a success or failure
 */
export async function touchId(this: XCUITestDriver, match = true): Promise<void> {
  await this.mobileSendBiometricMatch('touchId', match);
}

/**
 * Toggle whether the device is enrolled in the touch ID program.
 *
 * @param isEnabled - Whether to enable or disable the touch ID program
 */
export async function toggleEnrollTouchId(this: XCUITestDriver, isEnabled = true): Promise<void> {
  await this.mobileEnrollBiometric(isEnabled);
}

/**
 * Retrieves the actual device time.
 *
 * @param format - The format specifier string. Read the [DayJS documentation](https://day.js.org/docs/en/display/format)
 * to get the full list of supported datetime format
 * specifiers. The default format is `YYYY-MM-DDTHH:mm:ssZ`, which complies to ISO-8601.
 * @returns Formatted datetime string or the raw command output (if formatting fails)
 */
export async function getDeviceTime(this: XCUITestDriver, format = DATETIME_FORMAT_ISO8601): Promise<string> {
  const formatDateTime = (utcTimestamp: number, utcOffset: number): string => {
    const utcDateTime = dayjs.unix(utcTimestamp).utc();
    return utcDateTime.utcOffset(utcOffset).format(format);
  };

  this.log.debug('Attempting to capture iOS device date and time');
  if (!this.isRealDevice()) {
    this.log.debug('On simulator. Assuming device time is the same as host time');
    const hostNow = dayjs();
    return formatDateTime(hostNow.unix(), hostNow.utcOffset());
  }

  const udid = this.opts.udid;
  if (!udid) {
    throw new errors.UnknownError('Device UDID is required to read time on a real device');
  }

  const lockdown = await LockdownClient.createForDevice(udid, {
    facade: this.remoteXPCFacade,
    logger: this.log,
  });
  let timestamp: number;
  let utcOffset: number;
  try {
    ({timestamp, utcOffset} = await lockdown.getDeviceTimeFields());
  } finally {
    await lockdown.close();
  }
  this.log.debug(`timestamp: ${timestamp}, utcOffset: ${utcOffset}`);
  return formatDateTime(timestamp, utcOffset);
}

/**
 * Retrieves the current device time.
 *
 * This is a wrapper around {@linkcode getDeviceTime}.
 *
 * @param format - See {@linkcode getDeviceTime.format}
 * @returns Formatted datetime string or the raw command output if formatting fails
 */
export async function mobileGetDeviceTime(this: XCUITestDriver, format = DATETIME_FORMAT_ISO8601): Promise<string> {
  return await this.getDeviceTime(format);
}

/**
 * Removes/uninstalls the given application from the device under test.
 *
 * This is a wrapper around {@linkcode mobileRemoveApp mobile: removeApp}.
 *
 * @param bundleId - The bundle identifier of the application to be removed
 * @returns `true` if the application has been removed successfully; `false` otherwise
 */
export async function removeApp(this: XCUITestDriver, bundleId: string): Promise<boolean> {
  return await this.mobileRemoveApp(bundleId);
}

/**
 * Launches the app.
 *
 * @deprecated This API has been deprecated and is not supported anymore.
 * Consider using corresponding 'mobile:' extensions to manage the state of the app under test.
 * @throws {Error} Always throws an error indicating the API is deprecated
 */
export async function launchApp(this: XCUITestDriver): Promise<void> {
  throw new Error(
    `The launchApp API has been deprecated and is not supported anymore. ` +
      `Consider using corresponding 'mobile:' extensions to manage the state of the app under test.`,
  );
}

/**
 * Closes the app.
 *
 * @deprecated This API has been deprecated and is not supported anymore.
 * Consider using corresponding 'mobile:' extensions to manage the state of the app under test.
 * @throws {Error} Always throws an error indicating the API is deprecated
 */
export async function closeApp(this: XCUITestDriver): Promise<void> {
  throw new Error(
    `The closeApp API has been deprecated and is not supported anymore. ` +
      `Consider using corresponding 'mobile:' extensions to manage the state of the app under test.`,
  );
}

/**
 * Sets the URL for the current session.
 *
 * In web context, navigates to the URL using the remote debugger.
 * In native context on real devices, uses the proxy command.
 * In native context on simulators, uses simctl to open the URL.
 *
 * @param url - The URL to navigate to
 */
export async function setUrl(this: XCUITestDriver, url: string): Promise<void> {
  this.log.debug(`Attempting to set url '${url}'`);

  if (this.isWebContext()) {
    this.setCurrentUrl(url);
    // make sure to clear out any leftover web frames
    this.curWebFrames = [];
    await this._webExecutionBackend.navigate(url);
    return;
  }

  if (this.isRealDevice()) {
    await this.proxyCommand('/url', 'POST', {url});
  } else {
    await (this.device as Simulator).openUrl(url);
  }
}

/**
 * Retrieves values for all pressable button names supported in this session,
 * that can be passed to {@link mobilePressButton}.
 *
 * @returns Object containing one or more arrays of button names
 */
export async function mobileGetPressableButtons(this: XCUITestDriver): Promise<PressableButtonsInfo> {
  return await this.proxyCommand('/wda/pressableButtons', 'GET');
}

/**
 * Emulates press action on the given physical device button.
 *
 * This executes different methods based on the platform:
 *
 * - Duo simulator Home and volume buttons: host CoreSimulator HID.
 * - Other iOS buttons/devices: [`pressButton:`](https://developer.apple.com/documentation/xctest/xcuidevice/1619052-pressbutton)
 * - tvOS: [`pressButton:`](https://developer.apple.com/documentation/xctest/xcuiremote/1627475-pressbutton) or [`pressButton:forDuration:`](https://developer.apple.com/documentation/xctest/xcuiremote/1627476-pressbutton)
 *
 * Use {@linkcode mobilePerformIoHidEvent} to call a more universal API to perform a button press with duration on any supported device.
 *
 * @param name - The name of the button to be pressed
 * @param durationSeconds - The duration of the button press in seconds (float)
 */
export async function mobilePressButton(
  this: XCUITestDriver,
  name: ButtonName,
  durationSeconds?: number,
): Promise<void> {
  if (!name) {
    throw new errors.InvalidArgumentError('Button name is mandatory');
  }
  if (durationSeconds != null && typeof durationSeconds !== 'number') {
    throw new errors.InvalidArgumentError('durationSeconds should be a number');
  }
  const simulator = await getDuoSimulator(this);
  if (simulator) {
    const usage = DUO_BUTTON_USAGES.get(name.toLowerCase());
    if (usage === undefined) {
      throw new errors.UnsupportedOperationError(`Button '${name}' has no supported Duo simulator HID mapping`);
    }
    // Preserve iOS pressButton semantics: durationSeconds is a tvOS-only option.
    return await withDuoArgumentErrors(() => simulator.pressHidButton(HIDPageEvent.kHIDPage_Consumer, usage));
  }
  return await this.proxyCommand('/wda/pressButton', 'POST', {name, duration: durationSeconds});
}

/**
 * Process a string as speech and send it to Siri.
 *
 * Presents the Siri UI, if it is not currently active, and accepts a string which is then processed as if it were recognized speech. See [the documentation of `activateWithVoiceRecognitionText`](https://developer.apple.com/documentation/xctest/xcuisiriservice/2852140-activatewithvoicerecognitiontext?language=objc) for more details.
 *
 * @param text - Text to be sent to Siri
 */
export async function mobileSiriCommand(this: XCUITestDriver, text: string): Promise<void> {
  if (!text) {
    throw new errors.InvalidArgumentError('"text" argument is mandatory');
  }
  await this.proxyCommand('/wda/siri/activate', 'POST', {text});
}
