import {errors} from 'appium/driver.js';

import type {XCUITestDriver} from '../driver.js';
import {isPlainObject} from '../utils/index.js';
import {requireSimulator} from './helpers/index.js';
import type {PushPayload, NotificationType} from './types.js';

/**
 * Simulates push notification delivery to a simulated device.
 *
 * **Only "remote" push notifications are supported.** VoIP, Complication, File Provider, and other types are unsupported.
 *
 * Supported in Xcode SDK 11.4+.
 *
 * @param bundleId - The bundle identifier of the target application
 * @param payload - Valid push payload.
 * @group Simulator Only
 */
export async function mobilePushNotification(
  this: XCUITestDriver,
  bundleId: string,
  payload: PushPayload,
): Promise<void> {
  const simulator = requireSimulator(this, 'Push notification');

  if (!bundleId) {
    throw new errors.InvalidArgumentError(`'bundleId' argument must be a valid bundle identifier string`);
  }
  if (!isPlainObject(payload)) {
    throw new errors.InvalidArgumentError(
      `The 'payload' argument value must be a valid dictionary. ` + `Got ${JSON.stringify(payload)} instead`,
    );
  }
  if (!isPlainObject(payload.aps)) {
    throw new errors.InvalidArgumentError(
      `The 'payload.aps' value must be a valid dictionary. ` + `Got ${JSON.stringify(payload.aps)} instead`,
    );
  }
  await simulator.pushNotification({
    ...payload,
    'Simulator Target Bundle': bundleId,
  });
}

/**
 * Blocks until the expected notification is delivered.
 *
 * This method is a thin wrapper over the
 * [`XCTNSNotificationExpectation`](https://developer.apple.com/documentation/xctest/xctnsnotificationexpectation?language=objc) and
 * [`XCTDarwinNotificationExpectation`](https://developer.apple.com/documentation/xctest/xctdarwinnotificationexpectation?language=objc) entities.
 *
 * @param name - The name of the notification to expect
 * @param type - Which notification type to expect.
 * @param timeoutSeconds - For how long to wait until the notification is delivered (in float seconds).
 * @throws A [`TimeoutError`](https://www.selenium.dev/selenium/docs/api/javascript/module/selenium-webdriver/lib/error_exports_TimeoutError.html) if the expected notification has not been delivered within the given timeout.
 */
export async function mobileExpectNotification(
  this: XCUITestDriver,
  name: string,
  type: NotificationType = 'plain',
  timeoutSeconds: number = 60,
): Promise<void> {
  await this.proxyCommand('/wda/expectNotification', 'POST', {
    name,
    type,
    timeout: timeoutSeconds,
  });
}
