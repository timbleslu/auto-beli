import type {Element} from '@appium/types';
import type {Simulator} from 'appium-ios-simulator';
import {errors} from 'appium/driver.js';
import {util} from 'appium/support.js';
import {retryInterval} from 'asyncbox';

import type {XCUITestDriver} from '../driver.js';
import {capitalize, cropBase64Image, requireSharp} from '../utils/index.js';

/**
 * Takes a screenshot of the current screen.
 *
 * @returns Base64-encoded screenshot data
 */
export async function getScreenshot(this: XCUITestDriver): Promise<string> {
  if (this.isWebContext()) {
    const webScreenshotMode = (await this.settings.getSettings()).webScreenshotMode;
    switch (String(webScreenshotMode).toLowerCase()) {
      case 'page':
      case 'viewport':
        return await this._webExecutionBackend.screenshot(capitalize(String(webScreenshotMode)) as 'Viewport' | 'Page');
      case 'native':
      case undefined:
      case null:
        break;
      default:
        this.log.warn(
          `The webScreenshotMode setting value '${webScreenshotMode}' is not known. ` +
            `Supported values are: page, viewport and native. Falling back to the native mode.`,
        );
        break;
    }
  }

  const getScreenshotFromWDA = async (): Promise<string> => {
    this.log.debug(`Taking screenshot with WDA`);
    const data = await this.proxyCommand('/screenshot', 'GET');
    if (typeof data !== 'string') {
      throw new Error(`Unable to take screenshot. WDA returned '${JSON.stringify(data)}'`);
    }
    return data;
  };

  const {currentDisplayId} = await this.settings.getSettings();
  const hasSelectedDisplay = currentDisplayId !== undefined && currentDisplayId !== null;

  // Frames carry no display identity. Once selection changes, even resetting to
  // the main display cannot safely reuse this stream (old frames may be queued).
  if (this.mjpegStream && !hasSelectedDisplay && !this._hasUpdatedDisplaySelection) {
    this.log.info(`mjpeg video stream provided, returning latest frame as screenshot`);
    // Preserve legacy conversion unless orientation correction was explicitly enabled.
    const fixOrientation = this.settings.getSettings().mjpegFixOrientation === true;
    const data = await this.mjpegStream.lastChunkPNGBase64(fixOrientation);
    if (data) {
      return data;
    }
    this.log.warn(
      'Tried to get screenshot from active MJPEG stream, but there ' +
        'was no data yet. Falling back to regular screenshot methods.',
    );
  }

  let wdaError: unknown;
  try {
    return await getScreenshotFromWDA();
  } catch (err: any) {
    wdaError = err;
    this.log.warn(`Error getting screenshot: ${err.message}`);
  }

  if (this.isSimulator()) {
    this.log.info('Falling back to CoreSimulator screenshot capture');
    const payload = await (this.device as Simulator).getScreenshot({
      displayId: currentDisplayId ?? undefined,
    });
    if (!payload || payload.length === 0) {
      throw new errors.UnableToCaptureScreen();
    }
    return payload.toString('base64');
  }

  if (hasSelectedDisplay) {
    throw wdaError;
  }

  // Retry for real devices only.
  return (await retryInterval(2, 1000, getScreenshotFromWDA)) as string;
}

/**
 * Takes a screenshot of a specific element.
 *
 * @param el - Element to capture
 * @returns Base64-encoded screenshot data
 */
export async function getElementScreenshot(this: XCUITestDriver, el: Element<string> | string): Promise<string> {
  el = util.unwrapElement(el);
  if (this.isWebContext()) {
    return await this._webExecutionBackend.elementScreenshot(el);
  }

  const data = await this.proxyCommand(`/element/${el}/screenshot`, 'GET');
  if (typeof data !== 'string') {
    throw new errors.UnableToCaptureScreen(
      `Unable to take an element screenshot. WDA returned: ${JSON.stringify(data)}`,
    );
  }
  return data;
}

/**
 * Takes a screenshot of the current viewport.
 *
 * @returns Base64-encoded screenshot data
 */
export async function getViewportScreenshot(this: XCUITestDriver): Promise<string> {
  if (this.isWebContext()) {
    return await this._webExecutionBackend.screenshot();
  }

  const screenshot = await this.getScreenshot();
  // if we don't have a status bar, there's nothing to crop, so we can avoid
  // extra calls and return straight away
  const {scale, statusBarSize} = await this.getScreenInfo();
  if (statusBarSize.height === 0) {
    return screenshot;
  }

  const sharp = await requireSharp();
  const {width, height} = await sharp(Buffer.from(screenshot, 'base64')).metadata();
  if (!width || !height) {
    throw new errors.UnableToCaptureScreen('The device screenshot is empty');
  }
  this.log.debug(`Screenshot dimensions: ${width}x${height}`);
  // A screenshot covers the selected display, which need not have the same
  // dimensions as the active app window. Preserve its full width and bottom edge,
  // including fractional-scale rounding in the captured image.
  const cropHeight = statusBarSize.height * scale;
  if (!Number.isFinite(cropHeight) || cropHeight < 0 || cropHeight >= height) {
    this.log.info(
      `Status bar height ${cropHeight} is outside the screenshot bounds (${width}x${height}); returning the uncropped screenshot`,
    );
    return screenshot;
  }
  const top = Math.trunc(cropHeight);
  const region = {left: 0, top, width, height: height - top};
  this.log.debug(`Calculated viewport rect: ${JSON.stringify(region)}`);
  return await cropBase64Image(screenshot, region);
}
