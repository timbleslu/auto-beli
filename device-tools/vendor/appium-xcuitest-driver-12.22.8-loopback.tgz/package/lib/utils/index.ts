export {
  assignDefaults,
  capitalize,
  escapeRegExp,
  isEmpty,
  isPlainObject,
  mergeDeep,
  toErrorMessage,
  truncateString,
  upperFirst,
} from './lang.js';
export {hasElementId, hasWebElementId} from './element.js';
export {cropBase64Image, requireSharp} from './image.js';
export {memoize} from './memoize.js';
export {withoutImplicitWait} from './implicit-wait.js';
export {
  toApiLevelRequirementText,
  isTvOs,
  isWatchOs,
  normalizePlatformName,
  normalizePlatformVersion,
  supportsApiLevel17,
  supportsApiLevel18,
  supportsApiLevel27,
} from './platform.js';
