import {once} from 'node:events';
import fs from 'node:fs/promises';
import {createInterface} from 'node:readline';

import type {AppiumLogger} from '@appium/types';
import type {Simulator, SpawnedProcess} from 'appium-ios-simulator';
import {util} from 'appium/support.js';
import {exec} from 'teen_process';
import {transports, createLogger, format} from 'winston';
import type {Logger} from 'winston';

import {isEmpty} from '../../utils/index.js';
import {LineConsumingLog} from './line-consuming-log.js';

const LOG_STREAMING_PROCESS_NAME_PATTERN = /^com\.apple\.xpc\.launchd\.oneshot\.0x[0-f]+\.log$/;
const LOG_BINARY_PATH = '/usr/bin/log';
const STOP_TIMEOUT_MS = 1000;
const START_GRACE_MS = 1000;

export interface IOSSimulatorLogOptions {
  sim: Simulator;
  showLogs?: boolean;
  iosSimulatorLogsPredicate?: string;
  simulatorLogLevel?: string;
  log: AppiumLogger;
  iosSyslogFile?: string;
}

export class IOSSimulatorLog extends LineConsumingLog {
  private readonly sim: Simulator;
  private readonly showLogs: boolean;
  private readonly predicate?: string;
  private readonly logLevel?: string;
  private proc: SpawnedProcess | null;
  private readonly iosSyslogFile?: string;
  private syslogLogger: Logger | null;

  constructor(opts: IOSSimulatorLogOptions) {
    super({log: opts.log});
    this.sim = opts.sim;
    this.showLogs = !!opts.showLogs;
    this.predicate = opts.iosSimulatorLogsPredicate;
    this.logLevel = opts.simulatorLogLevel;
    this.proc = null;
    this.iosSyslogFile = opts.iosSyslogFile;
    this.syslogLogger = null;
  }

  override get isCapturing(): boolean {
    return Boolean(this.proc?.running);
  }

  override async startCapture(): Promise<void> {
    if (this.sim.udid === undefined) {
      throw new Error(`Log capture requires a sim udid`);
    }
    if (!(await this.sim.isRunning())) {
      throw new Error(`iOS Simulator with udid '${this.sim.udid}' is not running`);
    }
    if (this.iosSyslogFile && this.showLogs) {
      await this.clearExistingSyslog();
      try {
        this.syslogLogger = createLogger({
          level: 'info',
          format: format.combine(format.timestamp(), format.simple()),
          transports: [new transports.File({filename: this.iosSyslogFile})],
          exitOnError: false,
        });
        this.log.debug(`iOS syslog will be written to: '${this.iosSyslogFile}'`);
      } catch (e) {
        this.log.warn(`Could not set up iOS syslog logger for '${this.iosSyslogFile}': ${(e as Error).message}`);
        this.syslogLogger = null;
      }
    }
    const spawnArgs = ['stream', '--style', 'compact'];
    if (this.predicate) {
      spawnArgs.push('--predicate', this.predicate);
    }
    if (this.logLevel) {
      spawnArgs.push('--level', this.logLevel);
    }
    this.log.debug(
      `Starting log capture for iOS Simulator with udid '${this.sim.udid}' ` +
        `via '${LOG_BINARY_PATH}' using the following arguments '${util.quote(spawnArgs)}'`,
    );
    await this.cleanupObsoleteLogStreams();
    try {
      this.proc = await this.sim.spawnProcess(LOG_BINARY_PATH, {arguments: [LOG_BINARY_PATH, ...spawnArgs]});
      this.wireOutputListeners(this.proc);
      await this.assertStarted(this.proc);
    } catch (e) {
      this.shutdownSyslogger();
      throw new Error(`Simulator log capture failed. Original error: ${(e as Error).message}`, {cause: e});
    }
  }

  /**
   * `spawnProcess()` can resolve with a live pid for a process that crashes moments later (e.g. a
   * dyld failure) - briefly race an early exit against a grace period so such a crash surfaces as
   * a startup failure instead of a silently inactive capture.
   */
  private async assertStarted(proc: SpawnedProcess): Promise<void> {
    // `exited` outlives the grace window if `proc` keeps running - `pastGrace` keeps its eventual
    // (normal, e.g. SIGTERM-stopped) exit from throwing as an unhandled rejection long after this
    // method has already returned successfully.
    let pastGrace = false;
    let timer!: NodeJS.Timeout;
    const settled = new Promise<void>((resolve) => {
      timer = setTimeout(() => {
        pastGrace = true;
        resolve();
      }, START_GRACE_MS);
    });
    const exited = once(proc, 'exit').then((args: unknown[]) => {
      if (pastGrace) {
        return;
      }
      const [code, signal] = args as [number | null, NodeJS.Signals | null];
      if (code !== 0 || signal !== null) {
        throw new Error(`'${LOG_BINARY_PATH}' exited immediately with ${signal ? `signal ${signal}` : `code ${code}`}`);
      }
    });
    try {
      await Promise.race([settled, exited]);
    } finally {
      clearTimeout(timer);
    }
  }

  override async stopCapture(): Promise<void> {
    if (!this.proc) {
      return;
    }
    await this.killLogSubProcess();
    this.proc = null;
    this.shutdownSyslogger();
  }

  private async clearExistingSyslog(): Promise<void> {
    if (this.iosSyslogFile === undefined) {
      this.log.debug('iOS Syslog file path is not defined, skipping deletion.');
      return;
    }
    try {
      await fs.unlink(this.iosSyslogFile);
      this.log.debug(`Existing iOS Syslog file: '${this.iosSyslogFile}' deleted.`);
    } catch (unlinkErr) {
      if ((unlinkErr as any).code !== 'ENOENT') {
        this.log.warn(`Could not delete existing syslog file '${this.iosSyslogFile}': ${(unlinkErr as Error).message}`);
      }
    }
  }

  private shutdownSyslogger(): void {
    if (this.syslogLogger) {
      this.log.debug(`Closing iOS syslog file: '${this.iosSyslogFile}'`);
      const fileTransport = this.syslogLogger.transports.find(
        (t) => t instanceof transports.File && t.filename === this.iosSyslogFile,
      );
      if (fileTransport) {
        fileTransport.end?.();
        this.syslogLogger.remove(fileTransport);
      }
      this.syslogLogger = null;
    }
  }

  private onOutput(logRow: string, prefix: string = ''): void {
    this.broadcast(logRow);
    const space = prefix.length > 0 ? ' ' : '';
    if (this.showLogs && !this.iosSyslogFile) {
      this.log.info(`[IOS_SYSLOG_ROW${space}${prefix}] ${logRow}`);
    } else if (this.iosSyslogFile && this.showLogs) {
      this.writeToSyslogFile(`[IOS_SYSLOG_ROW${space}${prefix}] ${logRow}`);
    }
  }

  /**
   * Writes the given log row to the dedicated iOS syslog file if the logger is active.
   * @param {string} logRow - The log line to write.
   * @private
   */
  private writeToSyslogFile(logRow: string): void {
    if (this.syslogLogger && this.showLogs) {
      this.syslogLogger.info(logRow);
    }
  }

  private async killLogSubProcess(): Promise<void> {
    if (!this.proc?.running) {
      return;
    }
    this.log.debug('Stopping iOS log capture');
    const proc = this.proc;
    proc.kill('SIGTERM');
    if (await this.waitForProcExit(proc, STOP_TIMEOUT_MS)) {
      return;
    }
    if (!proc.running) {
      return;
    }
    this.log.warn('Cannot stop log capture process. Sending SIGKILL');
    proc.kill('SIGKILL');
    await this.waitForProcExit(proc, STOP_TIMEOUT_MS);
  }

  private async waitForProcExit(proc: SpawnedProcess, timeoutMs: number): Promise<boolean> {
    if (!proc.running) {
      return true;
    }
    let timer!: NodeJS.Timeout;
    const timedOut = new Promise<false>((resolve) => {
      timer = setTimeout(() => resolve(false), timeoutMs);
    });
    try {
      return await Promise.race([once(proc, 'exit').then(() => true), timedOut]);
    } finally {
      clearTimeout(timer);
    }
  }

  private wireOutputListeners(proc: SpawnedProcess): void {
    proc.on('error', (e: Error) => this.log.debug(`iOS log capture process error: ${e.message}`));
    for (const [stream, prefix] of [
      [proc.stdout, ''],
      [proc.stderr, 'STDERR'],
    ] as const) {
      stream.on('error', (e: Error) => this.log.debug(`iOS log capture stream error: ${e.message}`));
      createInterface({input: stream}).on('line', (line) => this.onOutput(line, prefix));
    }
  }

  private async cleanupObsoleteLogStreams(): Promise<void> {
    const processes = await this.sim.ps();
    const pids = processes.filter(({name}) => LOG_STREAMING_PROCESS_NAME_PATTERN.test(name)).map(({pid}) => pid);
    if (isEmpty(pids)) {
      return;
    }
    try {
      await exec('kill', pids.map(String));
    } catch (e) {
      this.log.warn(
        `Could not terminate one or more obsolete log streams: ${(e as any).stderr || (e as Error).message}`,
      );
    }
  }
}

export default IOSSimulatorLog;
