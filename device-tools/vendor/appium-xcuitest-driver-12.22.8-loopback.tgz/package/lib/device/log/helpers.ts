import {createInterface} from 'node:readline';

import {fs} from 'appium/support.js';

import type {LogEntry} from '../../commands/types.js';

export const DEFAULT_LOG_LEVEL = 'ALL';
export const MAX_JSON_LOG_LENGTH = 200;
export const MAX_BUFFERED_EVENTS_COUNT = 5000;

export interface GrepOptions {
  caseInsensitive?: boolean;
}

/** Converts raw log message fields into a WebDriver-style log entry. */
export function toLogEntry(message: string, timestamp: number, level: string = DEFAULT_LOG_LEVEL): LogEntry {
  return {
    timestamp,
    level,
    message,
  };
}

/** Returns true if the file contains the provided string. */
export async function grepFile(fullPath: string, str: string, opts: GrepOptions = {}): Promise<boolean> {
  const input = fs.createReadStream(fullPath);
  const rl = createInterface({input});
  return await new Promise((resolve, reject) => {
    input.once('error', reject);
    rl.once('error', reject);
    rl.on('line', (line) => {
      if (
        (opts.caseInsensitive && line.toLowerCase().includes(String(str).toLowerCase())) ||
        (!opts.caseInsensitive && line.includes(str))
      ) {
        resolve(true);
        input.close();
      }
    });
    input.once('end', () => resolve(false));
  });
}
