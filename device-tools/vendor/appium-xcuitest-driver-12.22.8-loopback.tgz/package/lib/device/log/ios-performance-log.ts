import type {AppiumLogger} from '@appium/types';

import {truncateString} from '../../utils/index.js';
import {MAX_JSON_LOG_LENGTH, MAX_BUFFERED_EVENTS_COUNT} from './helpers.js';
import {LineConsumingLog} from './line-consuming-log.js';

export interface IOSPerformanceLogOptions {
  remoteDebugger: any;
  maxEvents?: number;
  log: AppiumLogger;
}
type PerformanceLogEntry = object;

export class IOSPerformanceLog extends LineConsumingLog {
  private readonly remoteDebugger: any;
  private _started: boolean;

  constructor(opts: IOSPerformanceLogOptions) {
    super({
      maxBufferSize: opts.maxEvents ?? MAX_BUFFERED_EVENTS_COUNT,
      log: opts.log,
    });
    this.remoteDebugger = opts.remoteDebugger;
    this._started = false;
  }

  override get isCapturing(): boolean {
    return this._started;
  }

  override async startCapture(): Promise<void> {
    this.log.debug('Starting performance (Timeline) log capture');
    this._clearEntries();
    await this.remoteDebugger.startTimeline(this.onTimelineEvent.bind(this));
    this._started = true;
  }

  override async stopCapture(): Promise<void> {
    this.log.debug('Stopping performance (Timeline) log capture');
    await this.remoteDebugger.stopTimeline();
    this._started = false;
  }

  private onTimelineEvent(event: PerformanceLogEntry): void {
    const serializedEntry = JSON.stringify(event);
    this.broadcast(serializedEntry);
    this.log.debug(`Received Timeline event: ${truncateString(serializedEntry, {length: MAX_JSON_LOG_LENGTH})}`);
  }
}

export default IOSPerformanceLog;
