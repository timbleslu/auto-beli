import {
  createSimulator,
  listSimulators,
  getSimulator,
  type SimulatorListEntry,
  type Simulator,
  type LocalizationOptions,
} from 'appium-ios-simulator';
import {resetTestProcesses} from 'appium-webdriveragent';
import {util, timing} from 'appium/support.js';

import {buildSafariPreferences} from '../commands/helpers/index.js';
import {UDID_AUTO} from '../constants.js';
import type {XCUITestDriver, XCUITestDriverOpts} from '../driver.js';
import {isEmpty, normalizePlatformName} from '../utils/index.js';

const APPIUM_SIM_PREFIX = 'appiumTest';

export interface SimulatorLookupOptions {
  /** The name of the device to lookup */
  deviceName?: string;
  /** The platform version string */
  platformVersion: string;
  /** The full path to the simulator devices set */
  simulatorDevicesSetPath?: string;
  /** Simulator udid */
  udid?: string;
  /** The name of the current platform */
  platformName?: string;
}

export interface SimulatorInstallOptions {
  /** Whether to skip app uninstall before installing it */
  skipUninstall?: boolean;
  /** Whether the simulator is brand new */
  newSimulator?: boolean;
}

/**
 * Create a new simulator with `appiumTest-` prefix and return the object.
 *
 * @returns Simulator object associated with the udid passed in.
 */
export async function createSim(this: XCUITestDriver, opts: XCUITestDriverOpts = this.opts): Promise<Simulator> {
  const {simulatorDevicesSetPath: devicesSetPath, deviceName, platformVersion} = opts;
  const platform = normalizePlatformName(opts.platformName);
  if (!deviceName) {
    let deviceNames: string[] = [];
    try {
      const devices = await listSimulators({devicesSetPath});
      deviceNames = devices
        .filter((d) => d.platform === platform && (!platformVersion || d.sdk === platformVersion))
        .map((d) => d.name);
    } catch {}
    throw new Error(
      `'deviceName' must be provided in order to create a new Simulator for ${platform} platform. ` +
        `Currently available device names: ${deviceNames}`,
    );
  }

  if (!platformVersion) {
    throw new Error(`'platformVersion' is required.`);
  }

  const simName = `${APPIUM_SIM_PREFIX}-${util.uuidV4().toUpperCase()}-${deviceName}`;
  this.log.debug(`Creating a temporary Simulator device '${simName}'`);
  const udid = await createSimulator(simName, deviceName, platformVersion, {platform, devicesSetPath});
  return await getSimulator(udid, {
    platform,
    checkExistence: false,
    devicesSetPath,
    logger: this.log,
  });
}

/**
 * Case-insensitively resolves a simulator udid to the exact case `simctl` reports it in.
 * Different callers (a user-supplied capability vs. simctl's own CoreSimulator-reported
 * list) do not necessarily agree on letter case.
 *
 * @returns The matching device's canonical udid, or `undefined` if no device matches.
 */
export async function findSimulatorUdidCase(
  udid: string,
  devicesSetPath: string | undefined,
  platform: string,
): Promise<string | undefined> {
  const devices = await listSimulators({devicesSetPath});
  return devices.find((d) => d.platform === platform && d.udid.toLowerCase() === udid.toLowerCase())?.udid;
}

/**
 * Get an existing simulator matching the provided capabilities.
 *
 * @returns The matched Simulator instance or `null` if no matching device is found.
 */
export async function getExistingSim(
  this: XCUITestDriver,
  opts: XCUITestDriverOpts = this.opts,
): Promise<Simulator | null> {
  const {platformVersion, deviceName, udid, simulatorDevicesSetPath: devicesSetPath, platformName} = opts;

  const platform = normalizePlatformName(platformName);
  const selectSim = async (dev: Pick<SimulatorListEntry, 'udid'>): Promise<Simulator> =>
    await getSimulator(dev.udid, {
      platform,
      checkExistence: false,
      devicesSetPath,
      logger: this.log,
    });

  if (udid && String(udid).toLowerCase() !== UDID_AUTO) {
    this.log.debug(`Looking for an existing Simulator with UDID '${udid}'`);
    const canonicalUdid = await findSimulatorUdidCase(String(udid), devicesSetPath, platform);
    return canonicalUdid ? await selectSim({udid: canonicalUdid}) : null;
  }

  if (!platformVersion) {
    this.log.debug(`Provide 'platformVersion' capability if you prefer an existing Simulator to be selected`);
    return null;
  }

  const devices = (await listSimulators({devicesSetPath})).filter(
    (d) => d.platform === platform && d.sdk === platformVersion,
  );
  this.log.debug(
    `Looking for an existing Simulator with platformName: ${platform}, ` +
      `platformVersion: ${platformVersion}, deviceName: ${deviceName}`,
  );
  for (const device of devices) {
    if ((deviceName && device.name === deviceName) || !deviceName) {
      if (!deviceName) {
        this.log.debug(
          `The 'deviceName' capability value is empty. ` +
            `Selecting the first matching device '${device.name}' having the ` +
            `'platformVersion' set to ${platformVersion}`,
        );
      }
      return await selectSim(device);
    }
  }
  return null;
}

/**
 * Shutdown simulator
 */
export async function shutdownSimulator(this: XCUITestDriver): Promise<void> {
  const device = this.device as Simulator;
  // stop XCTest processes if running to avoid unexpected side effects
  await resetTestProcesses(device.udid, true);
  await device.shutdown();
}

/**
 * Run simulator reset
 * @param enforceSimulatorShutdown Whether to enforce simulator shutdown
 */
export async function runSimulatorReset(
  this: XCUITestDriver,
  enforceSimulatorShutdown: boolean = false,
): Promise<void> {
  const {noReset, fullReset, keychainsExcludePatterns, keepKeyChains, bundleId, app, browserName} = this.opts;
  if (noReset && !fullReset) {
    // noReset === true && fullReset === false
    this.log.debug('Reset: noReset is on. Leaving simulator as is');
    return;
  }
  const device = this.device as Simulator;

  if (!this.device) {
    this.log.debug('Reset: no device available. Skipping');
    return;
  }

  if (fullReset) {
    this.log.debug('Reset: fullReset is on. Cleaning simulator');
    await shutdownSimulator.bind(this)();
    const isKeychainsBackupSuccessful = (keychainsExcludePatterns || keepKeyChains) && (await device.backupKeychains());
    await device.clean();
    if (isKeychainsBackupSuccessful) {
      await device.restoreKeychains(keychainsExcludePatterns?.split(',')?.map((x) => x.trim()) || []);
      this.log.info(`Successfully restored keychains after full reset`);
    } else if (keychainsExcludePatterns || keepKeyChains) {
      this.log.warn('Cannot restore keychains after full reset, because ' + 'the backup operation did not succeed');
    }
  } else if (bundleId) {
    // fastReset or noReset

    // Terminate the app under test if it is still running on Simulator
    try {
      await device.terminateApp(bundleId);
    } catch {
      this.log.warn(`Reset: failed to terminate Simulator application with id "${bundleId}"`);
    }

    if (app) {
      this.log.info('Not scrubbing third party app in anticipation of uninstall');
    } else {
      const isSafari = String(browserName).toLowerCase() === 'safari';
      try {
        if (isSafari) {
          await device.scrubSafari(true);
        } else {
          await device.scrubApp(bundleId);
        }
      } catch (err) {
        this.log.debug((err as Error).stack);
        this.log.warn((err as Error).message);
        this.log.warn(
          `Reset: could not scrub ${
            isSafari ? 'Safari browser' : 'application with id "' + this.opts.bundleId + '"'
          }. ` + `Leaving as is.`,
        );
      }
    }

    if (enforceSimulatorShutdown && (await device.isRunning())) {
      await shutdownSimulator.bind(this)();
    }
  }
}

/**
 * Install app to simulator
 * @param app The app to the path
 * @param bundleId The bundle id to ensure it is already installed and uninstall it
 * @param opts Install options
 */
export async function installToSimulator(
  this: XCUITestDriver,
  app: string,
  bundleId?: string,
  opts: SimulatorInstallOptions = {},
): Promise<void> {
  if (!app) {
    this.log.debug('No app path is given. Nothing to install.');
    return;
  }

  const {skipUninstall, newSimulator = false} = opts;
  const device = this.device as Simulator;

  if (!skipUninstall && !newSimulator && bundleId && (await device.isAppInstalled(bundleId))) {
    this.log.debug(`Reset requested. Removing app with id '${bundleId}' from the device`);
    await device.removeApp(bundleId);
  }

  this.log.debug(`Installing '${app}' on Simulator with UUID '${device.udid}'...`);
  const timer = new timing.Timer().start();
  await device.installApp(app);
  this.log.info(`The app has been successfully installed in ${timer.getDuration().asMilliSeconds.toFixed(0)}ms`);
}

/**
 * Shutdown other simulators
 */
export async function shutdownOtherSimulators(this: XCUITestDriver): Promise<void> {
  const device = this.device as Simulator;
  const devicesSetPath = device.devicesSetPath ?? undefined;
  const allDevices = await listSimulators({devicesSetPath});
  const otherBootedDevices = allDevices.filter(({udid, state}) => udid !== device.udid && state === 'Booted');
  if (isEmpty(otherBootedDevices)) {
    this.log.info('No other running simulators have been detected');
    return;
  }
  this.log.info(
    `Detected ${util.pluralize('other running Simulator', otherBootedDevices.length, true)}. Shutting them down...`,
  );
  for (const {udid, platform} of otherBootedDevices) {
    // It is necessary to stop the corresponding xcodebuild process before killing
    // the simulator, otherwise it will be automatically restarted
    await resetTestProcesses(udid, true);
    const otherSim = await getSimulator(udid, {platform, checkExistence: false, devicesSetPath, logger: this.log});
    await otherSim.shutdown();
  }
}

/**
 * Configures Safari options based on the given session capabilities
 *
 * @returns true if any preferences have been updated
 */
export async function setSafariPrefs(this: XCUITestDriver): Promise<boolean> {
  const prefs = buildSafariPreferences(this.opts);
  if (isEmpty(prefs)) {
    return false;
  }

  this.log.debug(`About to update Safari preferences: ${JSON.stringify(prefs)}`);
  await (this.device as Simulator).updateSafariSettings(prefs);
  return true;
}

/**
 * Changes Simulator localization preferences
 *
 * @returns True if preferences were changed
 */
export async function setLocalizationPrefs(this: XCUITestDriver): Promise<boolean> {
  const {language, locale, calendarFormat, skipSyncUiDialogTranslation} = this.opts;
  const l10nConfig: LocalizationOptions = {};
  if (language) {
    l10nConfig.language = {name: language, skipSyncUiDialogTranslation};
  }
  if (locale) {
    l10nConfig.locale = {name: locale};
    if (calendarFormat) {
      l10nConfig.locale.calendar = calendarFormat;
    }
  }
  if (isEmpty(l10nConfig)) {
    return false;
  }

  this.log.debug(`About to update localization preferences: ${JSON.stringify(l10nConfig)}`);
  await (this.device as Simulator).configureLocalization(l10nConfig);
  return true;
}
